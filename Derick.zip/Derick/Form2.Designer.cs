﻿namespace Derick
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dinheirototal2 = new Label();
            label1 = new Label();
            label2 = new Label();
            dinheiroDoGoverno2 = new Label();
            label3 = new Label();
            dinheiroDosCidadaos2 = new Label();
            MaisUmaCasa = new Button();
            label44 = new Label();
            MenosUmaCasa = new Button();
            d480 = new Label();
            label4 = new Label();
            label5 = new Label();
            PrecoCasa = new Label();
            PrecoPredio = new Label();
            label7 = new Label();
            label8 = new Label();
            LabelPredio = new Label();
            label10 = new Label();
            BotaoDoPredio = new Button();
            label6 = new Label();
            TerrasDisponiveis2 = new Label();
            MenosUmPredio = new Button();
            label9 = new Label();
            PopulacaoSemResidencia = new Label();
            PrecoEscola = new Label();
            label12 = new Label();
            label13 = new Label();
            QuantiadeEscola = new Label();
            MenosEscolas = new Button();
            label15 = new Label();
            MaisEscolas = new Button();
            PopulacaoTotal = new Label();
            label11 = new Label();
            PrecoHospital = new Label();
            label16 = new Label();
            label17 = new Label();
            QuantiadeHospital = new Label();
            MenosHospital = new Button();
            label19 = new Label();
            MaisHospital = new Button();
            PrecoFazenda = new Label();
            label18 = new Label();
            label20 = new Label();
            QuantiadeFazenda = new Label();
            MenosFazendas = new Button();
            label22 = new Label();
            MaisFazendas = new Button();
            PrecoCentrosEnergia = new Label();
            label21 = new Label();
            label23 = new Label();
            QuantiadeCentrosEnergia = new Label();
            MenosCentrosEnergia = new Button();
            label25 = new Label();
            MaisCentrosEnergia = new Button();
            PrecoReservatorioAgua = new Label();
            label24 = new Label();
            label26 = new Label();
            QuantiadeReservatorioAgua = new Label();
            MenosReservatorioAgua = new Button();
            label28 = new Label();
            MaisReservatorioAgua = new Button();
            PrecoQuartel = new Label();
            label27 = new Label();
            label29 = new Label();
            QuantiadeQuartel = new Label();
            MenosQuartel = new Button();
            label31 = new Label();
            MaisQuartel = new Button();
            PrecoDelegacia = new Label();
            label30 = new Label();
            label32 = new Label();
            QuantiadeDelegacia = new Label();
            MenosDelegacia = new Button();
            label34 = new Label();
            MaisDelegacia = new Button();
            PrecoIndustriaFerro = new Label();
            label33 = new Label();
            label35 = new Label();
            QuantiadeIndustriaFerro = new Label();
            MenosIndustriaFerro = new Button();
            label37 = new Label();
            MaisIndustriaFerro = new Button();
            PrecoIndustriaCombustivel = new Label();
            label36 = new Label();
            label38 = new Label();
            QuantiadeIndustriaCombustivel = new Label();
            MenosIndustriaCombustivel = new Button();
            label40 = new Label();
            MaisIndustriaCombustivel = new Button();
            SuspendLayout();
            // 
            // dinheirototal2
            // 
            dinheirototal2.AutoSize = true;
            dinheirototal2.Location = new Point(144, 0);
            dinheirototal2.Name = "dinheirototal2";
            dinheirototal2.Size = new Size(13, 15);
            dinheirototal2.TabIndex = 0;
            dinheirototal2.Text = "0";
            dinheirototal2.Click += dinheirototal2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1, 0);
            label1.Name = "label1";
            label1.Size = new Size(137, 15);
            label1.TabIndex = 1;
            label1.Text = "Dinheiro Total Impresso: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(195, 0);
            label2.Name = "label2";
            label2.Size = new Size(55, 15);
            label2.TabIndex = 2;
            label2.Text = "Governo:";
            // 
            // dinheiroDoGoverno2
            // 
            dinheiroDoGoverno2.AutoSize = true;
            dinheiroDoGoverno2.Location = new Point(256, 0);
            dinheiroDoGoverno2.Name = "dinheiroDoGoverno2";
            dinheiroDoGoverno2.Size = new Size(13, 15);
            dinheiroDoGoverno2.TabIndex = 3;
            dinheiroDoGoverno2.Text = "0";
            dinheiroDoGoverno2.TextAlign = ContentAlignment.BottomLeft;
            dinheiroDoGoverno2.Click += dinheiroDoGoverno2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(303, 0);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 4;
            label3.Text = "Cidadãos:";
            // 
            // dinheiroDosCidadaos2
            // 
            dinheiroDosCidadaos2.AutoSize = true;
            dinheiroDosCidadaos2.Location = new Point(368, 0);
            dinheiroDosCidadaos2.Name = "dinheiroDosCidadaos2";
            dinheiroDosCidadaos2.Size = new Size(13, 15);
            dinheiroDosCidadaos2.TabIndex = 5;
            dinheiroDosCidadaos2.Text = "0";
            dinheiroDosCidadaos2.Click += dinheiroDosCidadaos2_Click;
            // 
            // MaisUmaCasa
            // 
            MaisUmaCasa.Location = new Point(171, 102);
            MaisUmaCasa.Name = "MaisUmaCasa";
            MaisUmaCasa.Size = new Size(106, 23);
            MaisUmaCasa.TabIndex = 6;
            MaisUmaCasa.Text = "+";
            MaisUmaCasa.UseVisualStyleBackColor = true;
            MaisUmaCasa.Click += MaisUmaCasa_Click;
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Location = new Point(50, 69);
            label44.Name = "label44";
            label44.Size = new Size(192, 15);
            label44.TabIndex = 7;
            label44.Text = "Construir/Destruir Casa Residencial";
            // 
            // MenosUmaCasa
            // 
            MenosUmaCasa.Location = new Point(29, 101);
            MenosUmaCasa.Name = "MenosUmaCasa";
            MenosUmaCasa.Size = new Size(105, 23);
            MenosUmaCasa.TabIndex = 8;
            MenosUmaCasa.Text = "-";
            MenosUmaCasa.UseVisualStyleBackColor = true;
            MenosUmaCasa.Click += MenosUmaCasa_Click;
            // 
            // d480
            // 
            d480.AutoSize = true;
            d480.Location = new Point(224, 83);
            d480.Name = "d480";
            d480.Size = new Size(13, 15);
            d480.TabIndex = 9;
            d480.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(29, 83);
            label4.Name = "label4";
            label4.Size = new Size(71, 15);
            label4.TabIndex = 10;
            label4.Text = "Preço Atual:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(171, 83);
            label5.Name = "label5";
            label5.Size = new Size(35, 15);
            label5.TabIndex = 11;
            label5.Text = "Total:";
            // 
            // PrecoCasa
            // 
            PrecoCasa.AutoSize = true;
            PrecoCasa.Location = new Point(106, 84);
            PrecoCasa.Name = "PrecoCasa";
            PrecoCasa.Size = new Size(13, 15);
            PrecoCasa.TabIndex = 12;
            PrecoCasa.Text = "0";
            // 
            // PrecoPredio
            // 
            PrecoPredio.AutoSize = true;
            PrecoPredio.Location = new Point(395, 84);
            PrecoPredio.Name = "PrecoPredio";
            PrecoPredio.Size = new Size(13, 15);
            PrecoPredio.TabIndex = 19;
            PrecoPredio.Text = "0";
            PrecoPredio.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(460, 84);
            label7.Name = "label7";
            label7.Size = new Size(35, 15);
            label7.TabIndex = 18;
            label7.Text = "Total:";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(318, 83);
            label8.Name = "label8";
            label8.Size = new Size(71, 15);
            label8.TabIndex = 17;
            label8.Text = "Preço Atual:";
            label8.Click += label8_Click;
            // 
            // LabelPredio
            // 
            LabelPredio.AutoSize = true;
            LabelPredio.Location = new Point(509, 84);
            LabelPredio.Name = "LabelPredio";
            LabelPredio.Size = new Size(13, 15);
            LabelPredio.TabIndex = 16;
            LabelPredio.Text = "0";
            LabelPredio.Click += label9_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(346, 68);
            label10.Name = "label10";
            label10.Size = new Size(201, 15);
            label10.TabIndex = 14;
            label10.Text = "Construir/Destruir Prédio Residencial";
            label10.Click += label10_Click;
            // 
            // BotaoDoPredio
            // 
            BotaoDoPredio.Location = new Point(460, 102);
            BotaoDoPredio.Name = "BotaoDoPredio";
            BotaoDoPredio.Size = new Size(106, 23);
            BotaoDoPredio.TabIndex = 13;
            BotaoDoPredio.Text = "+";
            BotaoDoPredio.UseVisualStyleBackColor = true;
            BotaoDoPredio.Click += button2_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(417, 0);
            label6.Name = "label6";
            label6.Size = new Size(122, 15);
            label6.TabIndex = 20;
            label6.Text = "Territórios Disponíves:";
            // 
            // TerrasDisponiveis2
            // 
            TerrasDisponiveis2.AutoSize = true;
            TerrasDisponiveis2.Location = new Point(545, 0);
            TerrasDisponiveis2.Name = "TerrasDisponiveis2";
            TerrasDisponiveis2.Size = new Size(13, 15);
            TerrasDisponiveis2.TabIndex = 21;
            TerrasDisponiveis2.Text = "0";
            // 
            // MenosUmPredio
            // 
            MenosUmPredio.Location = new Point(318, 102);
            MenosUmPredio.Name = "MenosUmPredio";
            MenosUmPredio.Size = new Size(105, 23);
            MenosUmPredio.TabIndex = 22;
            MenosUmPredio.Text = "-";
            MenosUmPredio.UseVisualStyleBackColor = true;
            MenosUmPredio.Click += MenosUmPredio_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(1, 27);
            label9.Name = "label9";
            label9.Size = new Size(150, 15);
            label9.TabIndex = 23;
            label9.Text = "População sem Residência:";
            // 
            // PopulacaoSemResidencia
            // 
            PopulacaoSemResidencia.AutoSize = true;
            PopulacaoSemResidencia.Location = new Point(157, 27);
            PopulacaoSemResidencia.Name = "PopulacaoSemResidencia";
            PopulacaoSemResidencia.Size = new Size(13, 15);
            PopulacaoSemResidencia.TabIndex = 24;
            PopulacaoSemResidencia.Text = "0";
            // 
            // PrecoEscola
            // 
            PrecoEscola.AutoSize = true;
            PrecoEscola.Location = new Point(106, 187);
            PrecoEscola.Name = "PrecoEscola";
            PrecoEscola.Size = new Size(13, 15);
            PrecoEscola.TabIndex = 31;
            PrecoEscola.Text = "0";
            PrecoEscola.Click += PrecoEscola_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(171, 186);
            label12.Name = "label12";
            label12.Size = new Size(35, 15);
            label12.TabIndex = 30;
            label12.Text = "Total:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(29, 186);
            label13.Name = "label13";
            label13.Size = new Size(71, 15);
            label13.TabIndex = 29;
            label13.Text = "Preço Atual:";
            // 
            // QuantiadeEscola
            // 
            QuantiadeEscola.AutoSize = true;
            QuantiadeEscola.Location = new Point(224, 187);
            QuantiadeEscola.Name = "QuantiadeEscola";
            QuantiadeEscola.Size = new Size(13, 15);
            QuantiadeEscola.TabIndex = 28;
            QuantiadeEscola.Text = "0";
            // 
            // MenosEscolas
            // 
            MenosEscolas.Location = new Point(29, 204);
            MenosEscolas.Name = "MenosEscolas";
            MenosEscolas.Size = new Size(105, 23);
            MenosEscolas.TabIndex = 27;
            MenosEscolas.Text = "-";
            MenosEscolas.UseVisualStyleBackColor = true;
            MenosEscolas.Click += MenosEscolas_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(41, 172);
            label15.Name = "label15";
            label15.Size = new Size(219, 15);
            label15.TabIndex = 26;
            label15.Text = "Construir/Destruir Instituições de Ensino";
            // 
            // MaisEscolas
            // 
            MaisEscolas.Location = new Point(171, 205);
            MaisEscolas.Name = "MaisEscolas";
            MaisEscolas.Size = new Size(106, 23);
            MaisEscolas.TabIndex = 25;
            MaisEscolas.Text = "+";
            MaisEscolas.UseVisualStyleBackColor = true;
            MaisEscolas.Click += MaisEscolas_Click;
            // 
            // PopulacaoTotal
            // 
            PopulacaoTotal.AutoSize = true;
            PopulacaoTotal.Location = new Point(293, 27);
            PopulacaoTotal.Name = "PopulacaoTotal";
            PopulacaoTotal.Size = new Size(13, 15);
            PopulacaoTotal.TabIndex = 32;
            PopulacaoTotal.Text = "0";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(193, 27);
            label11.Name = "label11";
            label11.Size = new Size(94, 15);
            label11.TabIndex = 33;
            label11.Text = "População Total:";
            // 
            // PrecoHospital
            // 
            PrecoHospital.AutoSize = true;
            PrecoHospital.Location = new Point(395, 187);
            PrecoHospital.Name = "PrecoHospital";
            PrecoHospital.Size = new Size(13, 15);
            PrecoHospital.TabIndex = 40;
            PrecoHospital.Text = "0";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(460, 187);
            label16.Name = "label16";
            label16.Size = new Size(35, 15);
            label16.TabIndex = 39;
            label16.Text = "Total:";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(317, 186);
            label17.Name = "label17";
            label17.Size = new Size(71, 15);
            label17.TabIndex = 38;
            label17.Text = "Preço Atual:";
            // 
            // QuantiadeHospital
            // 
            QuantiadeHospital.AutoSize = true;
            QuantiadeHospital.Location = new Point(509, 187);
            QuantiadeHospital.Name = "QuantiadeHospital";
            QuantiadeHospital.Size = new Size(13, 15);
            QuantiadeHospital.TabIndex = 37;
            QuantiadeHospital.Text = "0";
            // 
            // MenosHospital
            // 
            MenosHospital.Location = new Point(317, 204);
            MenosHospital.Name = "MenosHospital";
            MenosHospital.Size = new Size(105, 23);
            MenosHospital.TabIndex = 36;
            MenosHospital.Text = "-";
            MenosHospital.UseVisualStyleBackColor = true;
            MenosHospital.Click += MenosHospital_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(368, 171);
            label19.Name = "label19";
            label19.Size = new Size(154, 15);
            label19.TabIndex = 35;
            label19.Text = "Construir/Destruir Hospitais";
            // 
            // MaisHospital
            // 
            MaisHospital.Location = new Point(459, 205);
            MaisHospital.Name = "MaisHospital";
            MaisHospital.Size = new Size(106, 23);
            MaisHospital.TabIndex = 34;
            MaisHospital.Text = "+";
            MaisHospital.UseVisualStyleBackColor = true;
            MaisHospital.Click += MaisHospital_Click;
            // 
            // PrecoFazenda
            // 
            PrecoFazenda.AutoSize = true;
            PrecoFazenda.Location = new Point(110, 291);
            PrecoFazenda.Name = "PrecoFazenda";
            PrecoFazenda.Size = new Size(13, 15);
            PrecoFazenda.TabIndex = 47;
            PrecoFazenda.Text = "0";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(175, 289);
            label18.Name = "label18";
            label18.Size = new Size(35, 15);
            label18.TabIndex = 46;
            label18.Text = "Total:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(33, 290);
            label20.Name = "label20";
            label20.Size = new Size(71, 15);
            label20.TabIndex = 45;
            label20.Text = "Preço Atual:";
            // 
            // QuantiadeFazenda
            // 
            QuantiadeFazenda.AutoSize = true;
            QuantiadeFazenda.Location = new Point(224, 291);
            QuantiadeFazenda.Name = "QuantiadeFazenda";
            QuantiadeFazenda.Size = new Size(13, 15);
            QuantiadeFazenda.TabIndex = 44;
            QuantiadeFazenda.Text = "0";
            // 
            // MenosFazendas
            // 
            MenosFazendas.Location = new Point(33, 308);
            MenosFazendas.Name = "MenosFazendas";
            MenosFazendas.Size = new Size(105, 23);
            MenosFazendas.TabIndex = 43;
            MenosFazendas.Text = "-";
            MenosFazendas.UseVisualStyleBackColor = true;
            MenosFazendas.Click += MenosFazendas_Click;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(84, 275);
            label22.Name = "label22";
            label22.Size = new Size(153, 15);
            label22.TabIndex = 42;
            label22.Text = "Construir/Destruir Fazendas";
            // 
            // MaisFazendas
            // 
            MaisFazendas.Location = new Point(175, 309);
            MaisFazendas.Name = "MaisFazendas";
            MaisFazendas.Size = new Size(106, 23);
            MaisFazendas.TabIndex = 41;
            MaisFazendas.Text = "+";
            MaisFazendas.UseVisualStyleBackColor = true;
            MaisFazendas.Click += MaisFazendas_Click;
            // 
            // PrecoCentrosEnergia
            // 
            PrecoCentrosEnergia.AutoSize = true;
            PrecoCentrosEnergia.Location = new Point(395, 291);
            PrecoCentrosEnergia.Name = "PrecoCentrosEnergia";
            PrecoCentrosEnergia.Size = new Size(13, 15);
            PrecoCentrosEnergia.TabIndex = 54;
            PrecoCentrosEnergia.Text = "0";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(460, 289);
            label21.Name = "label21";
            label21.Size = new Size(35, 15);
            label21.TabIndex = 53;
            label21.Text = "Total:";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(318, 289);
            label23.Name = "label23";
            label23.Size = new Size(71, 15);
            label23.TabIndex = 52;
            label23.Text = "Preço Atual:";
            // 
            // QuantiadeCentrosEnergia
            // 
            QuantiadeCentrosEnergia.AutoSize = true;
            QuantiadeCentrosEnergia.Location = new Point(509, 290);
            QuantiadeCentrosEnergia.Name = "QuantiadeCentrosEnergia";
            QuantiadeCentrosEnergia.Size = new Size(13, 15);
            QuantiadeCentrosEnergia.TabIndex = 51;
            QuantiadeCentrosEnergia.Text = "0";
            // 
            // MenosCentrosEnergia
            // 
            MenosCentrosEnergia.Location = new Point(318, 309);
            MenosCentrosEnergia.Name = "MenosCentrosEnergia";
            MenosCentrosEnergia.Size = new Size(105, 23);
            MenosCentrosEnergia.TabIndex = 50;
            MenosCentrosEnergia.Text = "-";
            MenosCentrosEnergia.UseVisualStyleBackColor = true;
            MenosCentrosEnergia.Click += MenosCentrosEnergia_Click;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(343, 274);
            label25.Name = "label25";
            label25.Size = new Size(204, 15);
            label25.TabIndex = 49;
            label25.Text = "Construir/Destruir Centros de Energia";
            // 
            // MaisCentrosEnergia
            // 
            MaisCentrosEnergia.Location = new Point(460, 308);
            MaisCentrosEnergia.Name = "MaisCentrosEnergia";
            MaisCentrosEnergia.Size = new Size(106, 23);
            MaisCentrosEnergia.TabIndex = 48;
            MaisCentrosEnergia.Text = "+";
            MaisCentrosEnergia.UseVisualStyleBackColor = true;
            MaisCentrosEnergia.Click += MaisCentrosEnergia_Click;
            // 
            // PrecoReservatorioAgua
            // 
            PrecoReservatorioAgua.AutoSize = true;
            PrecoReservatorioAgua.Location = new Point(110, 395);
            PrecoReservatorioAgua.Name = "PrecoReservatorioAgua";
            PrecoReservatorioAgua.Size = new Size(13, 15);
            PrecoReservatorioAgua.TabIndex = 61;
            PrecoReservatorioAgua.Text = "0";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(175, 393);
            label24.Name = "label24";
            label24.Size = new Size(35, 15);
            label24.TabIndex = 60;
            label24.Text = "Total:";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(33, 393);
            label26.Name = "label26";
            label26.Size = new Size(71, 15);
            label26.TabIndex = 59;
            label26.Text = "Preço Atual:";
            // 
            // QuantiadeReservatorioAgua
            // 
            QuantiadeReservatorioAgua.AutoSize = true;
            QuantiadeReservatorioAgua.Location = new Point(224, 394);
            QuantiadeReservatorioAgua.Name = "QuantiadeReservatorioAgua";
            QuantiadeReservatorioAgua.Size = new Size(13, 15);
            QuantiadeReservatorioAgua.TabIndex = 58;
            QuantiadeReservatorioAgua.Text = "0";
            // 
            // MenosReservatorioAgua
            // 
            MenosReservatorioAgua.Location = new Point(33, 413);
            MenosReservatorioAgua.Name = "MenosReservatorioAgua";
            MenosReservatorioAgua.Size = new Size(105, 23);
            MenosReservatorioAgua.TabIndex = 57;
            MenosReservatorioAgua.Text = "-";
            MenosReservatorioAgua.UseVisualStyleBackColor = true;
            MenosReservatorioAgua.Click += MenosReservatorioAgua_Click;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(50, 378);
            label28.Name = "label28";
            label28.Size = new Size(217, 15);
            label28.TabIndex = 56;
            label28.Text = "Construir/Destruir Reservatório de Água";
            // 
            // MaisReservatorioAgua
            // 
            MaisReservatorioAgua.Location = new Point(175, 412);
            MaisReservatorioAgua.Name = "MaisReservatorioAgua";
            MaisReservatorioAgua.Size = new Size(106, 23);
            MaisReservatorioAgua.TabIndex = 55;
            MaisReservatorioAgua.Text = "+";
            MaisReservatorioAgua.UseVisualStyleBackColor = true;
            MaisReservatorioAgua.Click += MaisReservatorioAgua_Click;
            // 
            // PrecoQuartel
            // 
            PrecoQuartel.AutoSize = true;
            PrecoQuartel.Location = new Point(395, 394);
            PrecoQuartel.Name = "PrecoQuartel";
            PrecoQuartel.Size = new Size(13, 15);
            PrecoQuartel.TabIndex = 68;
            PrecoQuartel.Text = "0";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(460, 392);
            label27.Name = "label27";
            label27.Size = new Size(35, 15);
            label27.TabIndex = 67;
            label27.Text = "Total:";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(318, 392);
            label29.Name = "label29";
            label29.Size = new Size(71, 15);
            label29.TabIndex = 66;
            label29.Text = "Preço Atual:";
            // 
            // QuantiadeQuartel
            // 
            QuantiadeQuartel.AutoSize = true;
            QuantiadeQuartel.Location = new Point(509, 393);
            QuantiadeQuartel.Name = "QuantiadeQuartel";
            QuantiadeQuartel.Size = new Size(13, 15);
            QuantiadeQuartel.TabIndex = 65;
            QuantiadeQuartel.Text = "0";
            // 
            // MenosQuartel
            // 
            MenosQuartel.Location = new Point(318, 412);
            MenosQuartel.Name = "MenosQuartel";
            MenosQuartel.Size = new Size(105, 23);
            MenosQuartel.TabIndex = 64;
            MenosQuartel.Text = "-";
            MenosQuartel.UseVisualStyleBackColor = true;
            MenosQuartel.Click += MenosQuartel_Click;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(368, 377);
            label31.Name = "label31";
            label31.Size = new Size(144, 15);
            label31.TabIndex = 63;
            label31.Text = "Construir/Destruir Quartel";
            // 
            // MaisQuartel
            // 
            MaisQuartel.Location = new Point(460, 411);
            MaisQuartel.Name = "MaisQuartel";
            MaisQuartel.Size = new Size(106, 23);
            MaisQuartel.TabIndex = 62;
            MaisQuartel.Text = "+";
            MaisQuartel.UseVisualStyleBackColor = true;
            MaisQuartel.Click += MaisQuartel_Click;
            // 
            // PrecoDelegacia
            // 
            PrecoDelegacia.AutoSize = true;
            PrecoDelegacia.Location = new Point(111, 493);
            PrecoDelegacia.Name = "PrecoDelegacia";
            PrecoDelegacia.Size = new Size(13, 15);
            PrecoDelegacia.TabIndex = 75;
            PrecoDelegacia.Text = "0";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(176, 491);
            label30.Name = "label30";
            label30.Size = new Size(35, 15);
            label30.TabIndex = 74;
            label30.Text = "Total:";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(34, 491);
            label32.Name = "label32";
            label32.Size = new Size(71, 15);
            label32.TabIndex = 73;
            label32.Text = "Preço Atual:";
            // 
            // QuantiadeDelegacia
            // 
            QuantiadeDelegacia.AutoSize = true;
            QuantiadeDelegacia.Location = new Point(225, 492);
            QuantiadeDelegacia.Name = "QuantiadeDelegacia";
            QuantiadeDelegacia.Size = new Size(13, 15);
            QuantiadeDelegacia.TabIndex = 72;
            QuantiadeDelegacia.Text = "0";
            // 
            // MenosDelegacia
            // 
            MenosDelegacia.Location = new Point(34, 511);
            MenosDelegacia.Name = "MenosDelegacia";
            MenosDelegacia.Size = new Size(105, 23);
            MenosDelegacia.TabIndex = 71;
            MenosDelegacia.Text = "-";
            MenosDelegacia.UseVisualStyleBackColor = true;
            MenosDelegacia.Click += MenosDelegacia_Click;
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(84, 476);
            label34.Name = "label34";
            label34.Size = new Size(156, 15);
            label34.TabIndex = 70;
            label34.Text = "Construir/Destruir Delegacia";
            // 
            // MaisDelegacia
            // 
            MaisDelegacia.Location = new Point(176, 510);
            MaisDelegacia.Name = "MaisDelegacia";
            MaisDelegacia.Size = new Size(106, 23);
            MaisDelegacia.TabIndex = 69;
            MaisDelegacia.Text = "+";
            MaisDelegacia.UseVisualStyleBackColor = true;
            MaisDelegacia.Click += MaisDelegacia_Click;
            // 
            // PrecoIndustriaFerro
            // 
            PrecoIndustriaFerro.AutoSize = true;
            PrecoIndustriaFerro.Location = new Point(695, 85);
            PrecoIndustriaFerro.Name = "PrecoIndustriaFerro";
            PrecoIndustriaFerro.Size = new Size(13, 15);
            PrecoIndustriaFerro.TabIndex = 82;
            PrecoIndustriaFerro.Text = "0";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(760, 85);
            label33.Name = "label33";
            label33.Size = new Size(35, 15);
            label33.TabIndex = 81;
            label33.Text = "Total:";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(618, 85);
            label35.Name = "label35";
            label35.Size = new Size(71, 15);
            label35.TabIndex = 80;
            label35.Text = "Preço Atual:";
            // 
            // QuantiadeIndustriaFerro
            // 
            QuantiadeIndustriaFerro.AutoSize = true;
            QuantiadeIndustriaFerro.Location = new Point(809, 84);
            QuantiadeIndustriaFerro.Name = "QuantiadeIndustriaFerro";
            QuantiadeIndustriaFerro.Size = new Size(13, 15);
            QuantiadeIndustriaFerro.TabIndex = 79;
            QuantiadeIndustriaFerro.Text = "0";
            // 
            // MenosIndustriaFerro
            // 
            MenosIndustriaFerro.Location = new Point(618, 103);
            MenosIndustriaFerro.Name = "MenosIndustriaFerro";
            MenosIndustriaFerro.Size = new Size(105, 23);
            MenosIndustriaFerro.TabIndex = 78;
            MenosIndustriaFerro.Text = "-";
            MenosIndustriaFerro.UseVisualStyleBackColor = true;
            MenosIndustriaFerro.Click += MenosIndustriaFerro_Click_1;
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new Point(650, 69);
            label37.Name = "label37";
            label37.Size = new Size(197, 15);
            label37.TabIndex = 77;
            label37.Text = "Construir/Destruir Indústria de Ferro";
            // 
            // MaisIndustriaFerro
            // 
            MaisIndustriaFerro.Location = new Point(760, 102);
            MaisIndustriaFerro.Name = "MaisIndustriaFerro";
            MaisIndustriaFerro.Size = new Size(106, 23);
            MaisIndustriaFerro.TabIndex = 76;
            MaisIndustriaFerro.Text = "+";
            MaisIndustriaFerro.UseVisualStyleBackColor = true;
            MaisIndustriaFerro.Click += MaisIndustriaFerro_Click;
            // 
            // PrecoIndustriaCombustivel
            // 
            PrecoIndustriaCombustivel.AutoSize = true;
            PrecoIndustriaCombustivel.Location = new Point(695, 174);
            PrecoIndustriaCombustivel.Name = "PrecoIndustriaCombustivel";
            PrecoIndustriaCombustivel.Size = new Size(13, 15);
            PrecoIndustriaCombustivel.TabIndex = 89;
            PrecoIndustriaCombustivel.Text = "0";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(769, 174);
            label36.Name = "label36";
            label36.Size = new Size(35, 15);
            label36.TabIndex = 88;
            label36.Text = "Total:";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(618, 173);
            label38.Name = "label38";
            label38.Size = new Size(71, 15);
            label38.TabIndex = 87;
            label38.Text = "Preço Atual:";
            // 
            // QuantiadeIndustriaCombustivel
            // 
            QuantiadeIndustriaCombustivel.AutoSize = true;
            QuantiadeIndustriaCombustivel.Location = new Point(818, 174);
            QuantiadeIndustriaCombustivel.Name = "QuantiadeIndustriaCombustivel";
            QuantiadeIndustriaCombustivel.Size = new Size(13, 15);
            QuantiadeIndustriaCombustivel.TabIndex = 86;
            QuantiadeIndustriaCombustivel.Text = "0";
            // 
            // MenosIndustriaCombustivel
            // 
            MenosIndustriaCombustivel.Location = new Point(618, 192);
            MenosIndustriaCombustivel.Name = "MenosIndustriaCombustivel";
            MenosIndustriaCombustivel.Size = new Size(105, 23);
            MenosIndustriaCombustivel.TabIndex = 85;
            MenosIndustriaCombustivel.Text = "-";
            MenosIndustriaCombustivel.UseVisualStyleBackColor = true;
            MenosIndustriaCombustivel.Click += MenosIndustriaCombustivel_Click;
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(629, 159);
            label40.Name = "label40";
            label40.Size = new Size(237, 15);
            label40.TabIndex = 84;
            label40.Text = "Construir/Destruir Indústria de Combustível";
            // 
            // MaisIndustriaCombustivel
            // 
            MaisIndustriaCombustivel.Location = new Point(760, 192);
            MaisIndustriaCombustivel.Name = "MaisIndustriaCombustivel";
            MaisIndustriaCombustivel.Size = new Size(106, 23);
            MaisIndustriaCombustivel.TabIndex = 90;
            MaisIndustriaCombustivel.Text = "+";
            MaisIndustriaCombustivel.UseVisualStyleBackColor = true;
            MaisIndustriaCombustivel.Click += MaisIndustriaCombustivel_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1224, 567);
            Controls.Add(MaisIndustriaCombustivel);
            Controls.Add(PrecoIndustriaCombustivel);
            Controls.Add(label36);
            Controls.Add(label38);
            Controls.Add(QuantiadeIndustriaCombustivel);
            Controls.Add(MenosIndustriaCombustivel);
            Controls.Add(label40);
            Controls.Add(PrecoIndustriaFerro);
            Controls.Add(label33);
            Controls.Add(label35);
            Controls.Add(QuantiadeIndustriaFerro);
            Controls.Add(MenosIndustriaFerro);
            Controls.Add(label37);
            Controls.Add(MaisIndustriaFerro);
            Controls.Add(PrecoDelegacia);
            Controls.Add(label30);
            Controls.Add(label32);
            Controls.Add(QuantiadeDelegacia);
            Controls.Add(MenosDelegacia);
            Controls.Add(label34);
            Controls.Add(MaisDelegacia);
            Controls.Add(PrecoQuartel);
            Controls.Add(label27);
            Controls.Add(label29);
            Controls.Add(QuantiadeQuartel);
            Controls.Add(MenosQuartel);
            Controls.Add(label31);
            Controls.Add(MaisQuartel);
            Controls.Add(PrecoReservatorioAgua);
            Controls.Add(label24);
            Controls.Add(label26);
            Controls.Add(QuantiadeReservatorioAgua);
            Controls.Add(MenosReservatorioAgua);
            Controls.Add(label28);
            Controls.Add(MaisReservatorioAgua);
            Controls.Add(PrecoCentrosEnergia);
            Controls.Add(label21);
            Controls.Add(label23);
            Controls.Add(QuantiadeCentrosEnergia);
            Controls.Add(MenosCentrosEnergia);
            Controls.Add(label25);
            Controls.Add(MaisCentrosEnergia);
            Controls.Add(PrecoFazenda);
            Controls.Add(label18);
            Controls.Add(label20);
            Controls.Add(QuantiadeFazenda);
            Controls.Add(MenosFazendas);
            Controls.Add(label22);
            Controls.Add(MaisFazendas);
            Controls.Add(PrecoHospital);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(QuantiadeHospital);
            Controls.Add(MenosHospital);
            Controls.Add(label19);
            Controls.Add(MaisHospital);
            Controls.Add(label11);
            Controls.Add(PopulacaoTotal);
            Controls.Add(PrecoEscola);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(QuantiadeEscola);
            Controls.Add(MenosEscolas);
            Controls.Add(label15);
            Controls.Add(MaisEscolas);
            Controls.Add(PopulacaoSemResidencia);
            Controls.Add(label9);
            Controls.Add(MenosUmPredio);
            Controls.Add(TerrasDisponiveis2);
            Controls.Add(label6);
            Controls.Add(PrecoPredio);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(LabelPredio);
            Controls.Add(label10);
            Controls.Add(BotaoDoPredio);
            Controls.Add(PrecoCasa);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(d480);
            Controls.Add(MenosUmaCasa);
            Controls.Add(label44);
            Controls.Add(MaisUmaCasa);
            Controls.Add(dinheiroDosCidadaos2);
            Controls.Add(label3);
            Controls.Add(dinheiroDoGoverno2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dinheirototal2);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label dinheirototal2;
        private Label label1;
        private Label label2;
        private Label dinheiroDoGoverno2;
        private Label label3;
        private Label dinheiroDosCidadaos2;
        private Button MaisUmaCasa;
        private Label label44;
        private Button MenosUmaCasa;
        private Label d480;
        private Label label4;
        private Label label5;
        private Label PrecoCasa;
        private Label PrecoPredio;
        private Label label7;
        private Label label8;
        private Label LabelPredio;
        private Label label10;
        private Button BotaoDoPredio;
        private Label label6;
        private Label TerrasDisponiveis2;
        private Button MenosUmPredio;
        private Label label9;
        private Label PopulacaoSemResidencia;
        private Label PrecoEscola;
        private Label label12;
        private Label label13;
        private Label QuantiadeEscola;
        private Button MenosEscolas;
        private Label label15;
        private Button MaisEscolas;
        private Label PopulacaoTotal;
        private Label label11;
        private Label PrecoHospital;
        private Label label16;
        private Label label17;
        private Label QuantiadeHospital;
        private Button MenosHospital;
        private Label label19;
        private Button MaisHospital;
        private Label PrecoFazenda;
        private Label label18;
        private Label label20;
        private Label QuantiadeFazenda;
        private Button MenosFazendas;
        private Label label22;
        private Button MaisFazendas;
        private Label PrecoCentrosEnergia;
        private Label label21;
        private Label label23;
        private Label QuantiadeCentrosEnergia;
        private Button MenosCentrosEnergia;
        private Label label25;
        private Button MaisCentrosEnergia;
        private Label PrecoReservatorioAgua;
        private Label label24;
        private Label label26;
        private Label QuantiadeReservatorioAgua;
        private Button MenosReservatorioAgua;
        private Label label28;
        private Button MaisReservatorioAgua;
        private Label PrecoQuartel;
        private Label label27;
        private Label label29;
        private Label QuantiadeQuartel;
        private Button MenosQuartel;
        private Label label31;
        private Button MaisQuartel;
        private Label PrecoDelegacia;
        private Label label30;
        private Label label32;
        private Label QuantiadeDelegacia;
        private Button MenosDelegacia;
        private Label label34;
        private Button MaisDelegacia;
        private Label PrecoIndustriaFerro;
        private Label label33;
        private Label label35;
        private Label QuantiadeIndustriaFerro;
        private Button MenosIndustriaFerro;
        private Label label37;
        private Button MaisIndustriaFerro;
        private Label PrecoIndustriaCombustivel;
        private Label label36;
        private Label label38;
        private Label QuantiadeIndustriaCombustivel;
        private Button MenosIndustriaCombustivel;
        private Label label40;
        private Button MaisIndustriaCombustivel;
    }
}