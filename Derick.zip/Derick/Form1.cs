using System;
using System.Drawing;
using System.Reflection;
using System.Collections.Generic;
using System.Runtime.Intrinsics.Arm;
using System.Text.RegularExpressions;

namespace Derick
{
    public partial class Form1 : Form

    {

        private Form2 form2;
        public int A = 0;
        int B = 0;
        public int DinheiroTotal = 20000;
        public int dinheiroDoGoverno = 0;
        public int dinheiroDosCidadaos = 20000;
        int turno;
        public int PovoSemResidencia;
        public int QuantidadedeHospitais;

        public int SalarioMinimoProfessores = 0;
        public int SalarioMinimoProfessoresEstatal;

        public int SalarioMinimoMedicos = 0;
        public int SalarioMinimoMedicosEstatal;

        public int SalarioMinimoAgricultores = 0;
        public int SalarioMinimoAgricultoresEstatal;

        public int SalarioMinimoPoliciaisEstatal;
        public int SalarioMinimoSoldadosEstatal;
        public int SalarioMinimoEletrecistasEstatal;
        public int SalarioMinimoEncanadoresEstatal;

        public int SalarioMinimoMineradorFerro = 0;
        public int SalarioMinimoTecnicoCombustivel = 0;

        public int SalarioMinimoMineradorFerroEstatal;
        public int SalarioMinimoTecnicoCombustivelEstatal;
        public double Pibreal;
        public double Pibnominal;

        public double Inflacaodecusto;
        public double InflacaopontosFerro;
        public double InflacaopontosCombustivel;
        public double InflacaopontosAlimento;
        public double InflacaopontosSaude;
        public double InflacaopontosEducacao;
        public double InflacaoDeMoeda;
        public double InflacaoAgregadaTurno;


        public double Deflacaodecusto;
        public double DeflacaopontosFerro;
        public double DeflacaopontosCombustivel;
        public double DeflacaopontosAlimento;
        public double DeflacaopontosSaude;
        public double DeflacaopontosEducacao;
        public double DeflacaoDeMoeda;
        public double DeflacaoAgregadaTurno;

        public double InflacaodecustoPorCausaDeEmprego;
        public double DeflacaodecustoPorCausaDeEmprego;

        public double Poderdecompra;

        public double SalarioEsperado;

        //Abaixo � o consumo do povo de recursos do pa�s

        //public int ConsumoEducacaoEstatal;
        //public int ConsumoEducacaoPrivado;


        Random random = new Random();
        Random AleatorioEdificiosPrivados = new Random();






        public void SetorEstatalDinheiroMovimentado()
        {
            double nadahaver = 0;
            //Aqui eu criei uma condicao no IF nada haver s� pra poder reutilizar as mesmas variaveis no mesmo construtor s� copiando e colando
            if (nadahaver == 0)
            {
                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalHospitais.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {

                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;
                    decimal DinheiroQueOSetorMovimenta1 = Math.Round(DinheiroQueOSetorMovimenta);
                    SetorSaudeEstatal.Text = DinheiroQueOSetorMovimenta1.ToString();

                }
            }


            if (nadahaver == 0)
            {
                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalEscolas.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {
                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;
                    decimal DinheiroQueOSetorMovimenta1 = Math.Round(DinheiroQueOSetorMovimenta);
                    SetorEducacaoEstatal.Text = DinheiroQueOSetorMovimenta1.ToString();

                }

            }




            if (nadahaver == 0)
            {
                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalFazendas.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {
                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;
                    decimal DinheiroQueOSetorMovimenta1 = Math.Round(DinheiroQueOSetorMovimenta);
                    SetorAgriculturaEstatal.Text = DinheiroQueOSetorMovimenta1.ToString();

                }

            }


            if (nadahaver == 0)
            {
                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalIndustriaCombustivel.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {
                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;
                    decimal DinheiroQueOSetorMovimenta1 = Math.Round(DinheiroQueOSetorMovimenta);
                    SetorCombustivelEstatal.Text = DinheiroQueOSetorMovimenta1.ToString();

                }

            }


            if (nadahaver == 0)
            {
                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalIndustriaFerro.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {
                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;
                    decimal DinheiroQueOSetorMovimenta1 = Math.Round(DinheiroQueOSetorMovimenta);
                    SetorFerroEstatal.Text = DinheiroQueOSetorMovimenta1.ToString();

                }

            }





        }
    

        public void PrecoRecursosEstatal()
        {
            double Demandaagregada = double.Parse(demandaagregada.Text);



        }

        public void CobrarImpostoFerro()
        {
            //Percentual = (Valor / Valor_total) * 100       Esta fun��o serve para saber por exemplo quantos por cento 30 � de 100
            // Valor = (Percentual / 100) * Valor_total      Esta fun��o serve para saber a porcentagem de um numero, por exemplo 15% de 1000, que ser� 150.


            decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
            decimal total = int.Parse(TotalIndustriaFerroPrivado.Text);
            decimal totalEdificios = int.Parse(TotalEdificios.Text);


            if (totalEdificios == 0)
            {
                return;
            }
            else
            {
                decimal Percentual = total / totalEdificios;
                decimal Percentual1 = Percentual * 100;
                decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                decimal arredondado = Math.Round(DinheiroQueOSetorMovimenta);
                SetorFerroPrivado.Text = arredondado.ToString();


                decimal taxa = int.Parse(TaxaFerro.Text);
                decimal impostosobresetor = (taxa / 100) * DinheiroQueOSetorMovimenta;

                decimal Label2 = decimal.Parse(label2.Text);
                decimal Label4 = decimal.Parse(label4.Text);


                Label2 = Label2 + impostosobresetor;
                decimal LABEL2 = Math.Round(Label2);
                label2.Text = LABEL2.ToString();
                dinheiroDoGoverno = int.Parse(label2.Text);

                Label4 = Label4 - impostosobresetor;
                decimal LABEL4 = Math.Round(Label4);
                label4.Text = LABEL4.ToString();
                dinheiroDosCidadaos = int.Parse(label4.Text);
            }



        }

        public void CobrarImpostoCombustivel()
        {
            //Percentual = (Valor / Valor_total) * 100       Esta fun��o serve para saber por exemplo quantos por cento 30 � de 100
            // Valor = (Percentual / 100) * Valor_total      Esta fun��o serve para saber a porcentagem de um numero, por exemplo 15% de 1000, que ser� 150.


            decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
            decimal total = int.Parse(TotalIndustriaCombustivelPrivada.Text);
            decimal totalEdificios = int.Parse(TotalEdificios.Text);


            if (totalEdificios == 0)
            {
                return;
            }
            else
            {
                decimal Percentual = total / totalEdificios;
                decimal Percentual1 = Percentual * 100;
                decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                decimal arredondado = Math.Round(DinheiroQueOSetorMovimenta);
                SetorCombustivelPrivado.Text = arredondado.ToString();


                decimal taxa = int.Parse(TaxaCombustivel.Text);
                decimal impostosobresetor = (taxa / 100) * DinheiroQueOSetorMovimenta;

                decimal Label2 = decimal.Parse(label2.Text);
                decimal Label4 = decimal.Parse(label4.Text);


                Label2 = Label2 + impostosobresetor;
                decimal LABEL2 = Math.Round(Label2);
                label2.Text = LABEL2.ToString();
                dinheiroDoGoverno = int.Parse(label2.Text);

                Label4 = Label4 - impostosobresetor;
                decimal LABEL4 = Math.Round(Label4);
                label4.Text = LABEL4.ToString();
                dinheiroDosCidadaos = int.Parse(label4.Text);
            }



        }

        public void CobrarImpostoAgricultura()
        {
            //Percentual = (Valor / Valor_total) * 100       Esta fun��o serve para saber por exemplo quantos por cento 30 � de 100
            // Valor = (Percentual / 100) * Valor_total      Esta fun��o serve para saber a porcentagem de um numero, por exemplo 15% de 1000, que ser� 150.


            decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
            decimal total = int.Parse(TotalFazendasPrivadas.Text);
            decimal totalEdificios = int.Parse(TotalEdificios.Text);


            if (totalEdificios == 0)
            {
                return;
            }
            else
            {
                decimal Percentual = total / totalEdificios;
                decimal Percentual1 = Percentual * 100;
                decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                decimal arredondado = Math.Round(DinheiroQueOSetorMovimenta);
                SetorAgriculturaPrivado.Text = arredondado.ToString();


                decimal taxa = int.Parse(TaxaAgricultura.Text);
                decimal impostosobresetor = (taxa / 100) * DinheiroQueOSetorMovimenta;

                decimal Label2 = decimal.Parse(label2.Text);
                decimal Label4 = decimal.Parse(label4.Text);


                Label2 = Label2 + impostosobresetor;
                decimal LABEL2 = Math.Round(Label2);
                label2.Text = LABEL2.ToString();
                dinheiroDoGoverno = int.Parse(label2.Text);

                Label4 = Label4 - impostosobresetor;
                decimal LABEL4 = Math.Round(Label4);
                label4.Text = LABEL4.ToString();
                dinheiroDosCidadaos = int.Parse(label4.Text);
            }



        }

        public void CobrarImpostoSaude()
        {
            //Percentual = (Valor / Valor_total) * 100       Esta fun��o serve para saber por exemplo quantos por cento 30 � de 100
            // Valor = (Percentual / 100) * Valor_total      Esta fun��o serve para saber a porcentagem de um numero, por exemplo 15% de 1000, que ser� 150.


            decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
            decimal total = int.Parse(TotalHospitaisPrivados.Text);
            decimal totalEdificios = int.Parse(TotalEdificios.Text);
            if (totalEdificios == 0)
            {
                return;
            }
            else
            {
                decimal Percentual = total / totalEdificios;
                decimal Percentual1 = Percentual * 100;
                decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                decimal arredondado = Math.Round(DinheiroQueOSetorMovimenta);
                SetorSaudePrivado.Text = arredondado.ToString();


                decimal taxa = int.Parse(TaxaSaude.Text);
                decimal impostosobresetor = (taxa / 100) * DinheiroQueOSetorMovimenta;

                decimal Label2 = decimal.Parse(label2.Text);
                decimal Label4 = decimal.Parse(label4.Text);


                Label2 = Label2 + impostosobresetor;
                decimal LABEL2 = Math.Round(Label2);
                label2.Text = LABEL2.ToString();
                dinheiroDoGoverno = int.Parse(label2.Text);

                Label4 = Label4 - impostosobresetor;
                decimal LABEL4 = Math.Round(Label4);
                label4.Text = LABEL4.ToString();
                dinheiroDosCidadaos = int.Parse(label4.Text);
            }



        }


        public void CobrarImpostoEducacao()
        {
            //Percentual = (Valor / Valor_total) * 100       Esta fun��o serve para saber por exemplo quantos por cento 30 � de 100
            // Valor = (Percentual / 100) * Valor_total      Esta fun��o serve para saber a porcentagem de um numero, por exemplo 15% de 1000, que ser� 150.


            decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
            decimal total = int.Parse(TotalEscolasPrivadas.Text);
            decimal totalEdificios = int.Parse(TotalEdificios.Text);
            if (totalEdificios == 0)
            {
                return;
            }
            else
            {
                decimal Percentual = total / totalEdificios;
                decimal Percentual1 = Percentual * 100;
                decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada; // Aqui � calculado a quantia de dinheiro que pertence ao setro da educacao do total que foi demandado em consumo;

                decimal arredondado = Math.Round(DinheiroQueOSetorMovimenta);
                SetorEducacaoPrivado.Text = arredondado.ToString();

                decimal taxa = int.Parse(TaxaEducacao.Text);
                decimal impostosobresetor = (taxa / 100) * DinheiroQueOSetorMovimenta;

                decimal Label2 = decimal.Parse(label2.Text);
                decimal Label4 = decimal.Parse(label4.Text);


                Label2 = Label2 + impostosobresetor;
                decimal LABEL2 = Math.Round(Label2);
                label2.Text = LABEL2.ToString();
                dinheiroDoGoverno = int.Parse(label2.Text);

                Label4 = Label4 - impostosobresetor;
                decimal LABEL4 = Math.Round(Label4);
                label4.Text = LABEL4.ToString();
                dinheiroDosCidadaos = int.Parse(label4.Text);
            }



        }

        public void DemandaAgregada()
        {

            double consumofamilias = double.Parse(SalarioMedioNacional.Text) * double.Parse(Povo.Text);
            double taxaimpostodireto = dinheiroDosCidadaos * (double.Parse(Taxa.Text) / 100);
            double DemandaAgregada = consumofamilias + taxaimpostodireto;
            double demanda = Math.Round(DemandaAgregada);
            demandaagregada.Text = demanda.ToString("N0");


            if (demanda > dinheiroDosCidadaos)
            {
                demandaagregada.Text = dinheiroDosCidadaos.ToString();
            }
        }

        public void TAXAdeDESEMPREGO()
        {
            // Queda_percentual = ((Valor_inicial - Valor_final) / Valor_inicial) * 100
            double povo = double.Parse(Povo.Text);
            double desempregados = double.Parse(PopulacaoDesempregada.Text);

            double taxadesemprego = (desempregados / povo) * 100;
            double taxadesemprego1 = Math.Round(taxadesemprego);
            TaxaDesemprego.Text = taxadesemprego1.ToString() + "%";


        }

        public void ProtestoDoPovoEEmpresarios()
        {

            if (Poderdecompra > 210 && Poderdecompra < 220)
            {
                MessageBox.Show("Empres�rios protestam contra o poder de compra que ultrapassou mais de 200%. Isso gerou uma demanda muito grande e os custos devido aos altos sal�rios esta tornando invi�vel continuar sendo empres�rio. Alguns donos de neg�cio j� comecaram a abandonar seus negocios ou faliram.");
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); }

            }
            if (Poderdecompra > 210)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); }

            }

            if (Poderdecompra > 280 && Poderdecompra < 290)
            {
                MessageBox.Show("Empres�rios protestam contra o poder de compra que ultrapassou mais de 200%. Isso gerou uma demanda muito grande e os custos devido aos altos sal�rios esta tornando invi�vel continuar sendo empres�rio. Alguns donos de neg�cio j� comecaram a abandonar seus negocios ou faliram.");
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); }

            }



        }

        public void CorrigindoSalarioMinimoZero()
        {

            if (SalarioMinimoMedicos == 0)
            {
                SalarioMinimoMedicos = int.Parse(SalarioMinimoEsperado.Text);
            }

            if (SalarioMinimoProfessores == 0)
            {
                SalarioMinimoProfessores = int.Parse(SalarioMinimoEsperado.Text);
            }


            if (SalarioMinimoTecnicoCombustivel == 0)
            {
                SalarioMinimoTecnicoCombustivel = int.Parse(SalarioMinimoEsperado.Text);
            }

            if (SalarioMinimoAgricultores == 0)
            {
                SalarioMinimoAgricultores = int.Parse(SalarioMinimoEsperado.Text);
            }

            if (SalarioMinimoMineradorFerro == 0)
            {
                SalarioMinimoMineradorFerro = int.Parse(SalarioMinimoEsperado.Text);
            }


        }
        public void ProtestoDeEmpresas()
        {
            double salariominimoesperado = double.Parse(SalarioMinimoEsperado.Text);
            //Resultado = Valor + (Valor * (Porcentagem / 100))
            double salariominimoacima = salariominimoesperado * 2;
            //Aqui calcula se o salario minimo esta muito acima(no caso o dobro), isso gera protesto dos empres�rios

            if (SalarioMinimoMineradorFerro > salariominimoacima)
            {
                MessageBox.Show("Empres�rios do setor das Industrias de Ferro privado protestam contra o salario minimo atual dos Mineradores de Ferro ultrapassar 100% do salario minimo esperado, muitos empres�rios amea�am abandonar seus neg�cios se a situa��o continuar.");
                MenosIndustriaFerroRECESSAO();
                MessageBox.Show("Um empres�rio que possu�a uma Industria de Ferro faliu.");
            }

            if (SalarioMinimoTecnicoCombustivel > salariominimoacima)
            {
                MessageBox.Show("Empres�rios do setor das Industrias de Combust�veis privado protestam contra o salario minimo atual dos T�cnicos de Combust�veis ultrapassar 100% do salario minimo esperado, muitos empres�rios amea�am abandonar seus neg�cios se a situa��o continuar");
                MenosIndustriaCombustivelRECESSAO();
                MessageBox.Show("Um empres�rio que possu�a uma Industria de Combustivel faliu.");

            }


            if (SalarioMinimoAgricultores > salariominimoacima)
            {
                MessageBox.Show("Empres�rios do setor rural privado protestam contra o salario minimo atual dos agricultores ultrapassar 100% do salario minimo esperado, muitos empres�rios amea�am abandonar seus neg�cios se a situa��o continuar");
                MenosfazendasPrivadasRECESSAO();
                MessageBox.Show("Um empres�rio que possu�a uma Fazenda faliu.");

            }

            if (SalarioMinimoMedicos > salariominimoacima)
            {
                MessageBox.Show("Empres�rios do setor da sa�de privada protestam contra o salario minimo atual dos m�dicos ultrapassar 100% do salario minimo esperado, muitos empres�rios amea�am abandonar seus neg�cios se a situa��o continuar");
                MenosHospitalPrivadoRECESSAO();
                MessageBox.Show("Um empres�rio que possu�a um Hospital faliu.");

            }

            if (SalarioMinimoProfessores > salariominimoacima)
            {
                MessageBox.Show("Empres�rios do setor da educa��o privada protestam contra o salario minimo atual dos professore ultrapassar 100% do salario minimo esperado, muitos empres�rios amea�am abandonar seus neg�cios se a situa��o continuar");
                MenosInstituicaodeEnsinoRECESSAO();
                MessageBox.Show("Um empres�rio que possu�a uma Institui��o de Ensino faliu.");

            }
        }



        public void MilagreEconomico()
        {
            double poderDecompra = Poderdecompra;


            if (poderDecompra > 120 && poderDecompra < 131)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { InstituicaodeEnsinoPrivada(); }
                else if (indiceAleatorio == 2) { IndustriadeFerro(); }
                else if (indiceAleatorio == 3) { FazendaPrivada(); }
                else if (indiceAleatorio == 4) { Hospitalprivado(); }
                else if (indiceAleatorio == 5) { IndustriadeCombustivel(); }
                else if (indiceAleatorio == 6) { BancoPrivado(); }

            }
            else if (poderDecompra > 130 && poderDecompra < 171)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { InstituicaodeEnsinoPrivada(); Hospitalprivado(); }
                else if (indiceAleatorio == 2) { IndustriadeFerro(); IndustriadeCombustivel(); }
                else if (indiceAleatorio == 3) { FazendaPrivada(); InstituicaodeEnsinoPrivada(); }
                else if (indiceAleatorio == 4) { Hospitalprivado(); IndustriadeFerro(); }
                else if (indiceAleatorio == 5) { IndustriadeCombustivel(); BancoPrivado(); }
                else if (indiceAleatorio == 6) { BancoPrivado(); FazendaPrivada(); }


            }
            else if (poderDecompra > 170 && poderDecompra < 201)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { InstituicaodeEnsinoPrivada(); Hospitalprivado(); FazendaPrivada(); }
                else if (indiceAleatorio == 2) { IndustriadeFerro(); IndustriadeCombustivel(); BancoPrivado(); }
                else if (indiceAleatorio == 3) { FazendaPrivada(); InstituicaodeEnsinoPrivada(); IndustriadeFerro(); }
                else if (indiceAleatorio == 4) { Hospitalprivado(); IndustriadeFerro(); IndustriadeCombustivel(); }
                else if (indiceAleatorio == 5) { IndustriadeCombustivel(); BancoPrivado(); FazendaPrivada(); }
                else if (indiceAleatorio == 6) { BancoPrivado(); FazendaPrivada(); Hospitalprivado(); }


            }

        }
        public void Recessao()
        {
            double poderDecompra = Poderdecompra;
            if (poderDecompra < 90 && poderDecompra > 80)
            {

                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); }

            }
            else if (poderDecompra < 80 && poderDecompra > 70)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); }

            }
            else if (poderDecompra < 70 && poderDecompra > 50)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); MenosHospitalPrivadoRECESSAO(); MenosBancoPrivadoRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); MenosIndustriaCombustivelRECESSAO(); }

            }
            else if (poderDecompra < 50 && poderDecompra > 30)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); MenosHospitalPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); MenosHospitalPrivadoRECESSAO(); MenosBancoPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); MenosIndustriaFerroRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); MenosfazendasPrivadasRECESSAO(); MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); }

                MessageBox.Show("A Recess�o alcan�ou um n�vel critico. Quatro empresas privadas do seu pa�s faliram devido a recess�o. Pois o poder de compra esta abaixo de 50%, desestimulando a economia.");
            }
            else if (poderDecompra < 30)
            {
                int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

                if (indiceAleatorio == 1) { MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); MenosHospitalPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); }
                else if (indiceAleatorio == 2) { MenosIndustriaFerroRECESSAO(); MenosHospitalPrivadoRECESSAO(); MenosBancoPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); MenosHospitalPrivadoRECESSAO(); }
                else if (indiceAleatorio == 3) { MenosfazendasPrivadasRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); }
                else if (indiceAleatorio == 4) { MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); MenosIndustriaFerroRECESSAO(); MenosInstituicaodeEnsinoRECESSAO(); MenosfazendasPrivadasRECESSAO(); }
                else if (indiceAleatorio == 5) { MenosHospitalPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); MenosfazendasPrivadasRECESSAO(); MenosHospitalPrivadoRECESSAO(); MenosIndustriaFerroRECESSAO(); }
                else if (indiceAleatorio == 6) { MenosBancoPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); MenosIndustriaCombustivelRECESSAO(); MenosBancoPrivadoRECESSAO(); MenosIndustriaCombustivelRECESSAO(); }

                MessageBox.Show("A Recess�o alcan�ou um n�vel critico. Cinco empresas privadas do seu pa�s faliram devido a recess�o. Pois o poder de compra esta abaixo de 30%, desestimulando a economia.");
            }

        }

        public void MenosBancoPrivadoRECESSAO()
        {
            int totalbancosprivados = int.Parse(TotalBancosPrivados.Text);
            if (totalbancosprivados < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int totalbancosprivados1 = int.Parse(TotalBancosPrivados.Text) - 1;
            TotalBancosPrivados.Text = totalbancosprivados1.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);


            int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
            TotalEmpresarios.Text = totalEmpresarios.ToString();

            if (PopulacaoSemEmprego < 0)
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 1;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                TotalEmpresarios.Text = TotalEmpresarios.Text;

            }
            else
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 1;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 1;
                PopulacaoEmpregada.Text = povoEmpregado.ToString();
                int empresario = int.Parse(TotalEmpresarios.Text) - 1;
                TotalEmpresarios.Text = empresario.ToString();
            }



        }



        public void MenosIndustriaCombustivelRECESSAO()
        {
            int totalindustriacombustivel = int.Parse(TotalIndustriaCombustivelPrivada.Text);
            if (totalindustriacombustivel < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int Totalindustriacombustivelprivadas = int.Parse(TotalIndustriaCombustivelPrivada.Text) - 1;
            TotalIndustriaCombustivelPrivada.Text = Totalindustriacombustivelprivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoSemEmprego < 0)
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                TotalTecnicoCombustivelPrivado.Text = TotalTecnicoCombustivelPrivado.Text;
            }
            else
            {
                int totalTecnicoCombustivel = int.Parse(TotalTecnicoCombustivelPrivado.Text) - 5;
                TotalTecnicoCombustivelPrivado.Text = totalTecnicoCombustivel.ToString();
                int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
                TotalEmpresarios.Text = totalEmpresarios.ToString();
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 6;
                PopulacaoEmpregada.Text = povoEmpregado.ToString();


            }
        }
        public void MenosIndustriaFerroRECESSAO()
        {
            int totalindustriaFerro = int.Parse(TotalIndustriaFerroPrivado.Text);
            if (totalindustriaFerro < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int Totalindustriaferroprivadas = int.Parse(TotalIndustriaFerroPrivado.Text) - 1;
            TotalIndustriaFerroPrivado.Text = Totalindustriaferroprivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoSemEmprego < 0)
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                TotalMineradoresFerroPrivado.Text = TotalMineradoresFerroPrivado.Text;
            }
            else
            {
                int totalTecnicoCombustivel = int.Parse(TotalMineradoresFerroPrivado.Text) - 5;
                TotalMineradoresFerroPrivado.Text = totalTecnicoCombustivel.ToString();
                int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
                TotalEmpresarios.Text = totalEmpresarios.ToString();
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 6;
                PopulacaoEmpregada.Text = povoEmpregado.ToString();
            }


        }

        public void MenosfazendasPrivadasRECESSAO()
        {
            int totalFazenda = int.Parse(TotalFazendasPrivadas.Text);
            if (totalFazenda < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int TotalFazendasprivadas = int.Parse(TotalFazendasPrivadas.Text) - 1;
            TotalFazendasPrivadas.Text = TotalFazendasprivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoSemEmprego < 0)
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 9;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                TotalAgricultoresPrivados.Text = TotalAgricultoresPrivados.Text;
            }
            else
            {
                int totalTecnicoCombustivel = int.Parse(TotalAgricultoresPrivados.Text) - 8;
                TotalAgricultoresPrivados.Text = totalTecnicoCombustivel.ToString();
                int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
                TotalEmpresarios.Text = totalEmpresarios.ToString();
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 9;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 9;
                PopulacaoEmpregada.Text = povoEmpregado.ToString();
            }



            int populacaComRiscoDefome = int.Parse(PovoComFome.Text) + 50;
            PovoComFome.Text = populacaComRiscoDefome.ToString();
        }
        public void MenosInstituicaodeEnsinoRECESSAO()
        {
            int totalInstituicao = int.Parse(TotalEscolasPrivadas.Text);
            if (totalInstituicao < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int TotalescolasPrivadas = int.Parse(TotalEscolasPrivadas.Text) - 1;
            TotalEscolasPrivadas.Text = TotalescolasPrivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoSemEmprego < 0)
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                TotalProfessoresPrivados.Text = TotalProfessoresPrivados.Text;
            }
            else
            {
                int totalTecnicoCombustivel = int.Parse(TotalProfessoresPrivados.Text) - 5;
                TotalProfessoresPrivados.Text = totalTecnicoCombustivel.ToString();
                int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
                TotalEmpresarios.Text = totalEmpresarios.ToString();
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 6;
                PopulacaoEmpregada.Text = povoEmpregado.ToString();
            }

            int populacaosemeducacao = int.Parse(populacaoSemEducacao.Text) + 40;
            populacaoSemEducacao.Text = populacaosemeducacao.ToString();
        }


        public void MenosHospitalPrivadoRECESSAO()
        {
            int totalHospital = int.Parse(TotalHospitaisPrivados.Text);
            if (totalHospital < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int TotalhospitaisPrivados = int.Parse(TotalHospitaisPrivados.Text) - 1;
            TotalHospitaisPrivados.Text = TotalhospitaisPrivados.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoSemEmprego < 0)
            {
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 10;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                TotalMedicosPrivados.Text = TotalMedicosPrivados.Text;
            }
            else
            {
                int totalTecnicoCombustivel = int.Parse(TotalMedicosPrivados.Text) - 9;
                TotalMedicosPrivados.Text = totalTecnicoCombustivel.ToString();
                int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
                TotalEmpresarios.Text = totalEmpresarios.ToString();
                int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 10;
                PopulacaoDesempregada.Text = povoDesempregado.ToString();
                int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 10;
                PopulacaoEmpregada.Text = povoEmpregado.ToString();
            }



            int populacaosemAcessoHospital = int.Parse(PopulacaoSemAcessoHospital.Text) + 60;
            PopulacaoSemAcessoHospital.Text = populacaosemAcessoHospital.ToString();
        }





        public void MenosconsumoTodosEstatalA()
        {
            MenosconsumoTodosEstatal();
            MenosconsumoTodosEstatal1();
            MenosconsumoTodosEstatal2();
            MenosconsumoTodosEstatal3();
            MenosconsumoTodosEstatal4();

            MenosconsumoTodosPrivado();
            MenosconsumoTodosPrivado1();
            MenosconsumoPrivado2();
            MenosconsumoPrivado3();
            MenosconsumoPrivado4();


        }
        public void MenosconsumoTodosEstatal()
        {

            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                return;
            }



            if (MenosTodosEstatal.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(Ferro.Text);


                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(Ferro.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosFerro.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    Ferro.Text = "0";
                    ConsumoPontosFerro.Text = ConsumoPontosFerro.Text;
                }
                else
                {
                    ConsumoPontosFerro.Text = PermitircirculacaoDoProduto1.ToString();

                    decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                    decimal total = decimal.Parse(TotalIndustriaFerro.Text);
                    decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                    decimal recursostotais = decimal.Parse(Ferro.Text);

                    if (totalEdificios == 0)
                    {
                        return;
                    }
                    else
                    {


                        decimal Percentual = total / totalEdificios;
                        decimal Percentual1 = Percentual * 100;
                        decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                        decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                        decimal arredondado = Math.Round(divisao);

                        decimal subtraindo = recursostotais - subtracaodoconsumo;
                        Ferro.Text = subtraindo.ToString();

                        decimal multiplicando = subtracaodoconsumo * arredondado;
                        decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                        label2.Text = somandodinheirogoverno.ToString();
                        dinheiroDoGoverno = int.Parse(label2.Text);

                        decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                        label4.Text = subtraindodinheirocidadaos.ToString();
                        dinheiroDosCidadaos = int.Parse(label4.Text);

                    }
                    //----------------------------------------------------------------------

                }

            }
        }


        public void MenosconsumoTodosEstatal1()
        {

            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                return;
            }



            if (MenosTodosEstatal.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(Combustivel.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(Combustivel.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosCombustivel.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    Combustivel.Text = "0";
                    ConsumoPontosCombustivel.Text = ConsumoPontosCombustivel.Text;
                }
                else
                {
                    ConsumoPontosCombustivel.Text = PermitircirculacaoDoProduto1.ToString();

                    decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                    decimal total = decimal.Parse(TotalIndustriaCombustivel.Text);
                    decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                    decimal recursostotais = decimal.Parse(Combustivel.Text);

                    if (totalEdificios == 0)
                    {
                        return;
                    }
                    else
                    {


                        decimal Percentual = total / totalEdificios;
                        decimal Percentual1 = Percentual * 100;
                        decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                        decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                        decimal arredondado = Math.Round(divisao);

                        decimal subtraindo = recursostotais - subtracaodoconsumo;
                        Combustivel.Text = subtraindo.ToString();

                        decimal multiplicando = subtracaodoconsumo * arredondado;
                        decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                        label2.Text = somandodinheirogoverno.ToString();
                        dinheiroDoGoverno = int.Parse(label2.Text);

                        decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                        label4.Text = subtraindodinheirocidadaos.ToString();
                        dinheiroDosCidadaos = int.Parse(label4.Text);

                    }
                }
            }

        }


        public void MenosconsumoTodosEstatal2()
        {
            //------------------------------------------------------------------------

            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                return;
            }



            if (MenosTodosEstatal.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(Alimento.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(Alimento.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosAlimentos.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    Alimento.Text = "0";
                    ConsumoPontosAlimentos.Text = ConsumoPontosAlimentos.Text;
                }
                else
                {
                    ConsumoPontosAlimentos.Text = PermitircirculacaoDoProduto1.ToString();

                    decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                    decimal total = decimal.Parse(TotalFazendas.Text);
                    decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                    decimal recursostotais = decimal.Parse(Alimento.Text);

                    if (totalEdificios == 0)
                    {
                        return;
                    }
                    else
                    {


                        decimal Percentual = total / totalEdificios;
                        decimal Percentual1 = Percentual * 100;
                        decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                        decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                        decimal arredondado = Math.Round(divisao);

                        decimal subtraindo = recursostotais - subtracaodoconsumo;
                        Alimento.Text = subtraindo.ToString();

                        decimal multiplicando = subtracaodoconsumo * arredondado;
                        decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                        label2.Text = somandodinheirogoverno.ToString();
                        dinheiroDoGoverno = int.Parse(label2.Text);

                        decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                        label4.Text = subtraindodinheirocidadaos.ToString();
                        dinheiroDosCidadaos = int.Parse(label4.Text);

                    }
                }
            }


        }

        public void MenosconsumoTodosEstatal3()
        {
            //----------------------------------------------------------------------------------------

            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                return;
            }




            if (MenosTodosEstatal.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(Saude.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(Saude.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosSaude.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    Saude.Text = "0";
                    ConsumoPontosSaude.Text = ConsumoPontosSaude.Text;
                }
                else
                {
                    ConsumoPontosSaude.Text = PermitircirculacaoDoProduto1.ToString();


                    decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                    decimal total = decimal.Parse(TotalHospitais.Text);
                    decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                    decimal recursostotais = decimal.Parse(Saude.Text);

                    if (totalEdificios == 0)
                    {
                        return;
                    }
                    else
                    {


                        decimal Percentual = total / totalEdificios;
                        decimal Percentual1 = Percentual * 100;
                        decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                        decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                        decimal arredondado = Math.Round(divisao);

                        decimal subtraindo = recursostotais - subtracaodoconsumo;
                        Saude.Text = subtraindo.ToString();

                        decimal multiplicando = subtracaodoconsumo * arredondado;
                        decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                        label2.Text = somandodinheirogoverno.ToString();
                        dinheiroDoGoverno = int.Parse(label2.Text);

                        decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                        label4.Text = subtraindodinheirocidadaos.ToString();
                        dinheiroDosCidadaos = int.Parse(label4.Text);

                    }
                }

            }

        }


        public void MenosconsumoTodosEstatal4()
        {

            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                return;
            }


            if (MenosTodosEstatal.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(Educacao.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(Educacao.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosEducacao.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    Educacao.Text = "0";
                    ConsumoPontosEducacao.Text = ConsumoPontosEducacao.Text;
                }
                else
                {
                    ConsumoPontosEducacao.Text = PermitircirculacaoDoProduto1.ToString();

                    decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                    decimal total = decimal.Parse(TotalEscolas.Text);
                    decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                    decimal recursostotais = decimal.Parse(Educacao.Text);

                    if (totalEdificios == 0)
                    {
                        return;
                    }
                    else
                    {


                        decimal Percentual = total / totalEdificios;
                        decimal Percentual1 = Percentual * 100;
                        decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                        decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                        decimal arredondado = Math.Round(divisao);

                        decimal subtraindo = recursostotais - subtracaodoconsumo;
                        Educacao.Text = subtraindo.ToString();

                        decimal multiplicando = subtracaodoconsumo * arredondado;
                        decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                        label2.Text = somandodinheirogoverno.ToString();
                        dinheiroDoGoverno = int.Parse(label2.Text);

                        decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                        label4.Text = subtraindodinheirocidadaos.ToString();
                        dinheiroDosCidadaos = int.Parse(label4.Text);

                    }
                }
            }
        }


        public void MenosconsumoTodosPrivado()
        {
            if (MenosConsumoTodos.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(FerroPrivado.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(FerroPrivado.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosFerro.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    FerroPrivado.Text = "0";
                    ConsumoPontosFerro.Text = ConsumoPontosFerro.Text;
                }
                else
                {
                    FerroPrivado.Text = PermitircirculacaoDoProduto.ToString();
                    ConsumoPontosFerro.Text = PermitircirculacaoDoProduto1.ToString();
                }
            }

        }


        public void MenosconsumoTodosPrivado1()
        {
            if (MenosConsumoTodos.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(CombustivelPrivado.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(CombustivelPrivado.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosCombustivel.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    CombustivelPrivado.Text = "0";
                    ConsumoPontosCombustivel.Text = ConsumoPontosCombustivel.Text;
                }
                else
                {
                    CombustivelPrivado.Text = PermitircirculacaoDoProduto.ToString();
                    ConsumoPontosCombustivel.Text = PermitircirculacaoDoProduto1.ToString();
                }

            }

        }

        public void MenosconsumoPrivado2()
        {
            if (MenosConsumoTodos.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(AlimentoPrivado.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(AlimentoPrivado.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosAlimentos.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    AlimentoPrivado.Text = "0";
                    ConsumoPontosAlimentos.Text = ConsumoPontosAlimentos.Text;
                }
                else
                {
                    AlimentoPrivado.Text = PermitircirculacaoDoProduto.ToString();
                    ConsumoPontosAlimentos.Text = PermitircirculacaoDoProduto1.ToString();
                }

            }
        }


        public void MenosconsumoPrivado3()
        {
            if (MenosConsumoTodos.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(SaudePrivado.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(SaudePrivado.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosSaude.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    SaudePrivado.Text = "0";
                    ConsumoPontosSaude.Text = ConsumoPontosSaude.Text;
                }
                else
                {
                    SaudePrivado.Text = PermitircirculacaoDoProduto.ToString();
                    ConsumoPontosSaude.Text = PermitircirculacaoDoProduto1.ToString();
                }

            }
        }

        public void MenosconsumoPrivado4()
        {
            if (MenosConsumoTodos.Checked)
            {
                int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);
                int ferro = int.Parse(EducacaoPrivado.Text);

                if (SubtracaoConsumo.Text == "")
                {
                    return;
                }
                else if (subtracaodoconsumo > ferro)
                {
                    return;
                }

                int PermitircirculacaoDoProduto = int.Parse(EducacaoPrivado.Text) - subtracaodoconsumo;
                int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosEducacao.Text) - subtracaodoconsumo;
                if (PermitircirculacaoDoProduto < 0)
                {
                    EducacaoPrivado.Text = "0";
                    ConsumoPontosEducacao.Text = ConsumoPontosEducacao.Text;
                }
                else
                {
                    EducacaoPrivado.Text = PermitircirculacaoDoProduto.ToString();
                    ConsumoPontosEducacao.Text = PermitircirculacaoDoProduto1.ToString();
                }

            }
        }

        public void CalculoInflacaoAgregadaEDeflacaoAgregada()
        {
            // Varia��o Percentual = ((Novo Valor - Valor Anterior) / Valor Anterior) *100
            double inflacaoanterior = InflacaoAgregadaTurno;
            double deflacaoanterior = DeflacaoAgregadaTurno;

            double[] valoresText = { Inflacaodecusto, InflacaopontosFerro, InflacaopontosCombustivel, InflacaopontosAlimento, InflacaopontosSaude, InflacaopontosEducacao, InflacaoDeMoeda };

            double media = valoresText.Average();
            double media1 = Math.Round(media);

            INFLACAOAGREGADA.Text = media1.ToString() + "%";

            double[] valoresText1 = { Deflacaodecusto, DeflacaopontosFerro, DeflacaopontosCombustivel, DeflacaopontosAlimento, DeflacaopontosSaude, DeflacaopontosEducacao, DeflacaoDeMoeda };

            double media11 = valoresText1.Average();
            double media111 = Math.Round(media11);

            DEFLACAOAGREGADA.Text = media111.ToString() + "%";


            double variacaopercentualInflacao = media1 - inflacaoanterior;
            double variacaopercentualinflacao1 = Math.Round(variacaopercentualInflacao);
            INFLACAAGREGADAPORCENTAGEM.Text = variacaopercentualinflacao1.ToString() + "%";
            InflacaoAgregadaTurno = media1;

            double variacaopercentualDeflacao = media111 - deflacaoanterior;
            double variacaopercentualDeflacao1 = Math.Round(variacaopercentualDeflacao);
            DEFLACAOAGREGADAPORCENTAGEM.Text = variacaopercentualDeflacao1.ToString() + "%";
            DeflacaoAgregadaTurno = media111;

            // double A1 = double.Parse(IN.Text);
            //double A2 = double.Parse(InflacaoPontosEducacao.Text);
            //double A3 = double.Parse(InflacaoDeCustos.Text);
            //double A4 = double.Parse(InflacaoPontosSaude.Text);
            //double A5 = double.Parse(InflacaoPontosCombustivel.Text);
            //double A6 = double.Parse(InflacaoPontosAlimento.Text);
            //double A7 = double.Parse(InflacaoPontosFerro.Text);

            //double InflacaoAgregada = A1 + A2 + A3 + A4  + A6 + A7;
            //double InflacaoAgregada1 = InflacaoAgregada / 7;
            //INFLACAOAGREGADA.Text = InflacaoAgregada1.ToString("N0") + "%";

            //int DeflacaoAgregada = int.Parse(DF.Text) + int.Parse(DeflacaoDeCustos.Text) + int.Parse(DeflacaoPontosEducacao.Text) + int.Parse(DeflacaoPontosSaude.Text) + int.Parse(DeflacaoPontosCombustivel.Text) + int.Parse(DeflacaoPontosAlimento.Text) + int.Parse(DeflacaoPontosFerro.Text);
            //int DeflacaoAgregada1 = DeflacaoAgregada / 7;
            //DEFLACAOAGREGADA.Text = DeflacaoAgregada1.ToString("N0") + "%";


        }
        public void PIBReal()
        {
            double PibAnterior = Pibreal;

            double pib5 = 100 / 50;

            //Importante notar que eu tomei como referencia 100, ou seja, 100 dinheiro por pessoa na economia � o minimo. Passou disso � inflacao.
            // Aqui o eu levei em conta que cada pessoa consome 10 produtos de cada coisa da cesta de bens e consumo, totalizando 50 produtos, sendo assim,
            // se cada pessoa precisa ter no minimo 100 dinheiro, entao cada produto vale 2, ou seja 2% do valor minimo de dinheiro por pessoa.
            //Sendo assim o PIBNOMINAL leva em conta a quantia de dinheiro por pessoa com a infla��o, assim 2% ser� 2, se  aquantia de dinheiro
            //por pessoa estiver em 500,2% ser� 10. Assim o Pibnominal pode ter um falso crescimento ou falsa queda pois ele � muito influenciado pela infla��o
            //O PIBreal toma como referer�ncia a quantia minima de dinheiro por pessoa do periodo quando comeca o jogo que no caso � 100, assim pode-se
            //calcular um PIB livre da influ�ncia da infla��o. Assim temos o quanto realmente a produ��o fisica do pa�s cresceu.
            double pib1 = double.Parse(TotaldeIndustriaFerro.Text);
            double pib2 = pib1 * 10;
            double pib3 = pib2 / 4;
            double pib4 = pib2 + pib3;
            double pib6 = pib4 * pib5;
            double pib7 = Math.Round(pib6);

            double pib1A = double.Parse(TotaldeIndustriaCombustivel.Text);
            double pib2A = pib1A * 10;
            double pib3A = pib2A / 4;
            double pib4A = pib2A + pib3A;
            double pib6A = pib4A * pib5;
            double pib7A = Math.Round(pib6A);

            double pib1B = double.Parse(TotaldeEscolas.Text);
            double pib2B = pib1B * 10;
            double pib3B = pib2B / 4;
            double pib4B = pib2B + pib3B;
            double pib6B = pib4B * pib5;
            double pib7B = Math.Round(pib6B);

            double pib1C = double.Parse(TotaldeHospitais.Text);
            double pib2C = pib1C * 10;
            double pib3C = pib2C / 4;
            double pib4C = pib2C + pib3C;
            double pib6C = pib4C * pib5;
            double pib7C = Math.Round(pib6C);

            double pib1D = double.Parse(TotaldeFazendas.Text);
            double pib2D = pib1D * 10;
            double pib3D = pib2D / 4;
            double pib4D = pib2D + pib3D;
            double pib6D = pib4D * pib5;
            double pib7D = Math.Round(pib6D);

            double PIB = pib7 + pib7A + pib7B + pib7C + pib7D;

            PIBREAL.Text = PIB.ToString("N0");

            Pibreal = PIB;

            // Varia��o Percentual = ((Novo Valor - Valor Anterior) / Valor Anterior) *100

            double crescimentoPorcentagem = ((Pibreal - PibAnterior) / PibAnterior) * 100;
            double crescimentoPorcentagem1 = Math.Round(crescimentoPorcentagem);
            PIBREALPORCENTAGEM.Text = crescimentoPorcentagem1.ToString() + "%";

        }
        public void PIBNOMINAL()

        {

            double PibAnterior = Pibnominal;



            double pib5 = double.Parse(QDP.Text) / 50;


            double pib1 = double.Parse(TotaldeIndustriaFerro.Text);
            double pib2 = pib1 * 10;
            double pib3 = pib2 / 4;
            double pib4 = pib2 + pib3;
            double pib6 = pib4 * pib5;
            double pib7 = Math.Round(pib6);

            double pib1A = double.Parse(TotaldeIndustriaCombustivel.Text);
            double pib2A = pib1A * 10;
            double pib3A = pib2A / 4;
            double pib4A = pib2A + pib3A;
            double pib6A = pib4A * pib5;
            double pib7A = Math.Round(pib6A);

            double pib1B = double.Parse(TotaldeEscolas.Text);
            double pib2B = pib1B * 10;
            double pib3B = pib2B / 4;
            double pib4B = pib2B + pib3B;
            double pib6B = pib4B * pib5;
            double pib7B = Math.Round(pib6B);

            double pib1C = double.Parse(TotaldeHospitais.Text);
            double pib2C = pib1C * 10;
            double pib3C = pib2C / 4;
            double pib4C = pib2C + pib3C;
            double pib6C = pib4C * pib5;
            double pib7C = Math.Round(pib6C);

            double pib1D = double.Parse(TotaldeFazendas.Text);
            double pib2D = pib1D * 10;
            double pib3D = pib2D / 4;
            double pib4D = pib2D + pib3D;
            double pib6D = pib4D * pib5;
            double pib7D = Math.Round(pib6D);

            double PIB = pib7 + pib7A + pib7B + pib7C + pib7D;
            ProdutoInternoBruto.Text = PIB.ToString("N0");

            Pibnominal = PIB;

            // Varia��o Percentual = ((Novo Valor - Valor Anterior) / Valor Anterior) *100

            double crescimentoPorcentagem = ((Pibnominal - PibAnterior) / PibAnterior) * 100;
            double crescimentoPorcentagem1 = Math.Round(crescimentoPorcentagem);
            PIBNOMINALPORCENTAGEM.Text = crescimentoPorcentagem1.ToString("N0") + "%";

        }

        public void PoderDeCompraDoConsumidor()
        {
            int taxaselic = int.Parse(TaxaSelic.Text);
            double salariominimoesperado = double.Parse(SalarioMinimoEsperado.Text);

            string Inflacao1 = InflacaoDeCustos.Text; // Remove o s�mbolo "%"
            Inflacao1 = Inflacao1.Replace("%", "");

            string Deflacao1 = DeflacaoDeCustos.Text; // Remove o s�mbolo "%"
            Deflacao1 = Deflacao1.Replace("%", "");


            double TotaldePrudtos = double.Parse(ConsumoPontosEducacao.Text) + double.Parse(ConsumoPontosSaude.Text) + double.Parse(ConsumoPontosFerro.Text) + double.Parse(ConsumoPontosCombustivel.Text) + double.Parse(ConsumoPontosAlimentos.Text);

            double salariominimonecessario = int.Parse(QDP.Text) / 4;
            SalarioMinimoNecessario.Text = salariominimonecessario.ToString();
            if (taxaselic < 3)
            {
                //Salario minimo esperado equivale a 25% da quantidade de dinheiro por pessoa, � dividido por 4. Eu fiz isso pois se o salario minimo esperado fosse igual a quantia de dinheiro por pessoa, na hora de colocar as funcoes de dobro do salario minimo, o salario dos empregados seria maior que o dinheiro em circula��o.
                //Eu dividi salario minimo por 4, assim decidi que cada pessoa consome o necess�rio de 25 produtos, pois aquantia minima de dinheiro por pessoa � 100.
                // Ao dividir por 100 o salario minimo obtenho 1% dele, ao dividir salario medio nacional por 1% eu obterei 100 partes se o salario medio nacional for igual ao salario minimo esperado, pois eu precisarei de umtotal de 100 partes de 1% para dar salario minimo esperado
                //se o salario medio for menor que salario minimo esperado o poder de compra fica abaixo de 100.
                // depois baixo eu dividi o salario minimo por 75, depois por 50 e 25, pois eu calculei o seguinte: imaginando que a
                //os produtos ficam mais caros ao aumentar a taxa de juros, ent�o o salario minimo tem menor poder de compra, 
                //se dividirmos por 75 � o mesmo que dizer que salario minimo perdeu 25% do seu valor, assim o salario minimo esperado pode nao corresponder ao necess�rio para uma vida digna para a pessoa.
                double poderdecompra = double.Parse(SalarioMinimoNecessario.Text) / 100;//Aqui � definido o indice de pre�os
                double poderdecompra1 = double.Parse(SalarioMedioNacional.Text) / poderdecompra;//Aqui � calculado poder de compra, ou seja, RENDA/Indice de pre�os.
                double poderdecompra2 = Math.Round(poderdecompra1);
                PoderDeCompra.Text = poderdecompra2.ToString("N0") + "%";
                Poderdecompra = poderdecompra2;
                // este calculo acima � o momento onde o salario minimo esperado � igual ao salario minimo necessario.
                //Resultado = Valor + (Valor * (Porcentagem / 100))





            }
            else if (taxaselic < 6 && taxaselic > 2)
            {
                double poderdecompra = double.Parse(SalarioMinimoNecessario.Text) / 75;
                double poderdecompra1 = double.Parse(SalarioMedioNacional.Text) / poderdecompra;
                double poderdecompra2 = Math.Round(poderdecompra1);
                PoderDeCompra.Text = poderdecompra2.ToString("N0") + "%";
                Poderdecompra = poderdecompra2;


            }
            else if (taxaselic < 10 && taxaselic > 5)
            {
                double poderdecompra = double.Parse(SalarioMinimoNecessario.Text) / 50;
                double poderdecompra1 = double.Parse(SalarioMedioNacional.Text) / poderdecompra;
                double poderdecompra2 = Math.Round(poderdecompra1);
                PoderDeCompra.Text = poderdecompra2.ToString("N0") + "%";
                Poderdecompra = poderdecompra2;



            }
            else if (taxaselic < 16 && taxaselic > 9)
            {
                double poderdecompra = double.Parse(SalarioMinimoNecessario.Text) / 25;
                double poderdecompra1 = double.Parse(SalarioMedioNacional.Text) / poderdecompra;
                double poderdecompra2 = Math.Round(poderdecompra1);
                PoderDeCompra.Text = poderdecompra2.ToString("N0") + "%";
                Poderdecompra = poderdecompra2;



            }


        }

        public void SalarioMinimoMediaNacional()
        {
            int SalarioTotal = SalarioMinimoProfessores + SalarioMinimoProfessoresEstatal + SalarioMinimoMedicos + SalarioMinimoMedicosEstatal + SalarioMinimoAgricultores + SalarioMinimoAgricultoresEstatal + SalarioMinimoPoliciaisEstatal + SalarioMinimoSoldadosEstatal + SalarioMinimoEletrecistasEstatal + SalarioMinimoEncanadoresEstatal + SalarioMinimoMineradorFerro + SalarioMinimoTecnicoCombustivel + SalarioMinimoMineradorFerroEstatal + SalarioMinimoTecnicoCombustivelEstatal;
            int SalarioMediaNacional = SalarioTotal / 14;
            SalarioMedioNacional.Text = SalarioMediaNacional.ToString();
        }

        public void IndiceAleatorioDeEdfificiosPrivados()
        {
            int indiceAleatorio = AleatorioEdificiosPrivados.Next(1, 6);

            if (indiceAleatorio == 1) { InstituicaodeEnsinoPrivada(); Hospitalprivado(); FazendaPrivada(); }
            else if (indiceAleatorio == 2) { IndustriadeFerro(); IndustriadeCombustivel(); BancoPrivado(); }
            else if (indiceAleatorio == 3) { FazendaPrivada(); InstituicaodeEnsinoPrivada(); IndustriadeFerro(); }
            else if (indiceAleatorio == 4) { Hospitalprivado(); IndustriadeFerro(); IndustriadeCombustivel(); }
            else if (indiceAleatorio == 5) { IndustriadeCombustivel(); BancoPrivado(); FazendaPrivada(); }
            else if (indiceAleatorio == 6) { BancoPrivado(); FazendaPrivada(); Hospitalprivado(); }



        }


        public void SalarioMinimoesperado()
        {
            // int valor = 100;
            //int porcentagem = 10;
            //int valorAumentado = valor * (1 + porcentagem / 100); Valor - (Valor * (Porcentagem / 100))
            //string AD = DeflacaoDeCustos.Text;
            string Inflacao1 = InflacaoDeCustos.Text; // Remove o s�mbolo "%"
            Inflacao1 = Inflacao1.Replace("%", "");
            string Deflacao1 = DeflacaoDeCustos.Text; // Remove o s�mbolo "%"
            Deflacao1 = Deflacao1.Replace("%", "");

            string inflacaoagregada = INFLACAOAGREGADA.Text;
            inflacaoagregada = inflacaoagregada.Replace("%", "");

            string deflacaoagregada = DEFLACAOAGREGADA.Text;
            deflacaoagregada = deflacaoagregada.Replace("%", "");
            //Na vida real a inflacao agregada subtrai do poder de consumo, aqui no jogo fiz o mesmo, assim se o jogador nao resolver o problema da inflacao nao adiantara apenas aumentar salario minimo das empresas
            double AE = double.Parse(Deflacao1);
            double AC = double.Parse(Inflacao1);


            if (AC > 0)
            {//Embora se tiver muitas oportunidades de emprego isso aumente o poder de compra isso pode no geral aumentar custos de materias primas levando a uma inflacao descontrolada, entao preferi colocar que uma alta inflacao de custo por causa de emprego leva a uma diminuicao no poder de compra
             //AQUI TEM UM PROBLEMA PARA RESOLVER A INFLACAO PODE CHEGAR A MAIS DE 100, nao tem como o salario ficar abaixo de 100, e salario esperado � usado para dividir pelo poder de compra
             //Valor real = Valor nominal / (1 + Infla��o)^Tempo
             //Usei s� isso: Valor real = Valor nominal / (1 + Infla��o)

                double qdp = double.Parse(QDP.Text) / 4;

                // double ValorAumentado = qdp - (qdp * (AC / 100));
                // double ValorAumentado1 = Math.Round(ValorAumentado);
                // SalarioMinimoEsperado.Text = ValorAumentado1.ToString();
                // SalarioEsperado = ValorAumentado1;

                double ValorReal = qdp / (1 + (AC / 100));//Este aqui reduz valor em porcentagem
                double ValorReal1 = Math.Round(ValorReal);
                SalarioMinimoEsperado.Text = ValorReal1.ToString();
                SalarioEsperado = ValorReal1;
                //DeflacaoDeCustos.Text = "0";
            }





        }
        public void CalculoInflacaoDeCustos()
        {

            //La na cesta de bens de consumo tem inflacao e deflacao, eu resolvi considerar aquilo tambem inflacao e deflacao de custo, apena para os alimentos, combustiveis e ferro que s�o mat�rias primas que servem para a producao de outros bens
            //pois a ideia que eu queria representar � se um governo imprime para comprar demais recursos o custo das materia primas
            //sobe, levando a um aumento geral nos precos de todos os outros produtos.

            //(Valor final - Valor inicial) / Valor inicial * 100

            //Abaixo eu verifico custo de producao de salarios, embora aqui eu nao aumente salarios, ele serve como referencia
            double populacaodesempregada1 = int.Parse(PopulacaoDesempregada.Text);
            double ConvertendoSinal1 = Math.Abs(populacaodesempregada1);
            double Soma1 = populacaodesempregada1 + int.Parse(Povo.Text);
            double CalculoGeraldainflacaodeCustos1 = (int.Parse(Povo.Text) - Soma1) / Soma1 * 100;
            double calculoGeralInflacaoCustos11 = Math.Round(CalculoGeraldainflacaodeCustos1);
            double convertendoSinal1 = Math.Abs(calculoGeralInflacaoCustos11);// Aqui eu descobri qual foi a variacao percentual


            //Abaixo � o custo de bens de producao
            double totalDeInflacaoBensdeProducao = InflacaopontosAlimento + InflacaopontosFerro + InflacaopontosCombustivel + convertendoSinal1 / 4;
            double inflacaodecusto = totalDeInflacaoBensdeProducao;

            InflacaoDeCustos.Text = inflacaodecusto.ToString() + "%";
            Inflacaodecusto = inflacaodecusto;
            InflacaodecustoPorCausaDeEmprego = convertendoSinal1;





        }


        public void deflacaoDeCusto()
        {

            SalarioMinimoEsperado.Text = QDP.Text;
            double populacaodesempregada = int.Parse(PopulacaoDesempregada.Text);
            double ConvertendoSinal = Math.Abs(populacaodesempregada);
            double Soma = populacaodesempregada + int.Parse(Povo.Text);
            double CalculoGeraldainflacaodeCustos = (int.Parse(Povo.Text) - Soma) / Soma * 100;
            double calculoGeralInflacaoCustos = Math.Round(CalculoGeraldainflacaodeCustos);
            double convertendoSinal = Math.Abs(calculoGeralInflacaoCustos);

            double totalDeDelacaoBensdeProducao = DeflacaopontosAlimento + DeflacaopontosFerro + DeflacaopontosCombustivel + convertendoSinal / 4;
            double deflacaodecusto = totalDeDelacaoBensdeProducao;


            DeflacaoDeCustos.Text = deflacaodecusto.ToString() + "%";
            Deflacaodecusto = deflacaodecusto;
            DeflacaodecustoPorCausaDeEmprego = convertendoSinal;
        }
        public void AtualizadordeTotais()
        {
            int totalresidencias = int.Parse(label480.Text) + int.Parse(labelpredio.Text);
            TotalResidencias.Text = totalresidencias.ToString();

            int totalescolas = int.Parse(TotalEscolas.Text) + int.Parse(TotalEscolasPrivadas.Text);
            TotaldeEscolas.Text = totalescolas.ToString();

            int totalHospitais = int.Parse(TotalHospitais.Text) + int.Parse(TotalHospitaisPrivados.Text);
            TotaldeHospitais.Text = totalHospitais.ToString();

            int totalfazendas = int.Parse(TotalFazendas.Text) + int.Parse(TotalFazendasPrivadas.Text);
            TotaldeFazendas.Text = totalfazendas.ToString();

            int totalindustriaferro = int.Parse(TotalIndustriaFerro.Text) + int.Parse(TotalIndustriaFerroPrivado.Text);
            TotaldeIndustriaFerro.Text = totalindustriaferro.ToString();

            int totalindustriacombustivel = int.Parse(TotalIndustriaCombustivel.Text) + int.Parse(TotalIndustriaCombustivelPrivada.Text);
            TotaldeIndustriaCombustivel.Text = totalindustriacombustivel.ToString();

            int Totaledificios = int.Parse(TotalBancosPrivados.Text) + totalresidencias + totalescolas + totalHospitais + totalfazendas + totalindustriaferro + totalindustriacombustivel;
            TotalEdificios.Text = Totaledificios.ToString();


            int totalmedicos = int.Parse(TotalMedicos.Text) + int.Parse(TotalMedicosPrivados.Text);
            TotaldeMedicos.Text = totalmedicos.ToString();

            int totalprofessores = int.Parse(TotalProfessores.Text) + int.Parse(TotalProfessoresPrivados.Text);
            TotaldeProfessores.Text = totalprofessores.ToString();

            int totalagricultores = int.Parse(TotalAgricultores.Text) + int.Parse(TotalAgricultoresPrivados.Text);
            TotaldeAgricultores.Text = totalagricultores.ToString();

            int totalMineradoresferro = int.Parse(TotalMineradoresFerro.Text) + int.Parse(TotalMineradoresFerroPrivado.Text);
            TotaldeMineradoresFerro.Text = totalMineradoresferro.ToString();

            int totaltecnicocombustivel = int.Parse(TotalTecnicoCombustivel.Text) + int.Parse(TotalTecnicoCombustivelPrivado.Text);
            TotaldeTecnicoCombustivel.Text = totaltecnicocombustivel.ToString();



        }

        public void AtualizadorRecursosEducacaoEstatal()
        {
            int totalrecursosConsumo = (int.Parse(TotalEscolas.Text) * 40) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(Educacao.Text) + totalrecursos;
            Educacao.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosEducacaoPrivado()
        {
            int totalrecursosConsumo = (int.Parse(TotalEscolasPrivadas.Text) * 40) * 10;


            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;


            int RecursoEducacao = int.Parse(EducacaoPrivado.Text) + totalrecursos;
            EducacaoPrivado.Text = RecursoEducacao.ToString();


        }

        public void AtualizadorRecursosSaudeEstatal()
        {
            int totalrecursosConsumo = (int.Parse(TotalHospitais.Text) * 60) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(Saude.Text) + totalrecursos;
            Saude.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosSaudePrivada()
        {
            int totalrecursosConsumo = (int.Parse(TotalHospitaisPrivados.Text) * 60) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(SaudePrivado.Text) + totalrecursos;
            SaudePrivado.Text = RecursoEducacao.ToString();
        }

        public void AtualizadorRecursosAlimentosEstatal()
        {
            int totalrecursosConsumo = (int.Parse(TotalFazendas.Text) * 50) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(Alimento.Text) + totalrecursos;
            Alimento.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosAlimentosPrivado()
        {
            int totalrecursosConsumo = (int.Parse(TotalFazendasPrivadas.Text) * 50) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(AlimentoPrivado.Text) + totalrecursos;
            AlimentoPrivado.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosCombustivelEstatal()
        {
            int totalrecursosConsumo = (int.Parse(TotalIndustriaCombustivel.Text) * 40) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(Combustivel.Text) + totalrecursos;
            Combustivel.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosCombustivelPrivado()
        {
            int totalrecursosConsumo = (int.Parse(TotalIndustriaCombustivelPrivada.Text) * 40) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(CombustivelPrivado.Text) + totalrecursos;
            CombustivelPrivado.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosFerroEstatal()
        {
            int totalrecursosConsumo = (int.Parse(TotalIndustriaFerro.Text) * 40) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(Ferro.Text) + totalrecursos;
            Ferro.Text = RecursoEducacao.ToString();

        }

        public void AtualizadorRecursosFerroPrivado()
        {
            int totalrecursosConsumo = (int.Parse(TotalIndustriaFerroPrivado.Text) * 40) * 10;

            int totalrecursosExtra = totalrecursosConsumo / 4;

            int totalrecursos = totalrecursosConsumo + totalrecursosExtra;

            int RecursoEducacao = int.Parse(FerroPrivado.Text) + totalrecursos;
            FerroPrivado.Text = RecursoEducacao.ToString();

        }

        public void ConsumodoPovo()
        {
            ConsumodoPovoEducacao();
            ConsumodoPovoSaude();
            ConsumodoPovoAlimento();
            ConsumodoPovoCombustivel();
            ConsumodoPovoFerro();
        }

        public void ConsumodoPovoFerro()
        {

            int ConsumoTotal = int.Parse(Povo.Text) * 5;
            int ConsumodePontosEducacao = int.Parse(Povo.Text) * 100;//Eu coloquei 100 aqui pois na hora da porcentagem a deflacao nao chegava at� 100 s� at� 10, assim pelo menos funcionou
            int Consumopontos = int.Parse(ConsumoPontosFerro.Text);
            int SomadoConsumoAnterior = ConsumodePontosEducacao + Consumopontos;
            int SomadoConsumoAnterior1 = ConsumoTotal + Consumopontos;
            ConsumoPontosFerro.Text = SomadoConsumoAnterior1.ToString();

            int quantiaDeDinheiroParaConsumoPorPessoa = SomadoConsumoAnterior / int.Parse(Povo.Text);
            int quantiaDeDinheiroParaConsumo = quantiaDeDinheiroParaConsumoPorPessoa * int.Parse(Povo.Text);
            int IN1;
            int DF1;
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { IN1 = 0; } else { IN1 = quantiaDeDinheiroParaConsumoPorPessoa - 100; }
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { DF1 = 100 - quantiaDeDinheiroParaConsumoPorPessoa; } else { DF1 = 0; };
            InflacaoPontosFerro.Text = IN1.ToString() + "%";
            DeflacaoPontosFerro.Text = DF1.ToString() + "%";
            InflacaopontosFerro = IN1;
            DeflacaopontosFerro = DF1;

        }

        public void ConsumodoPovoCombustivel()
        {
            int ConsumoTotal = int.Parse(Povo.Text) * 5;
            int ConsumodePontosEducacao = int.Parse(Povo.Text) * 100;//Eu coloquei 100 aqui pois na hora da porcentagem a deflacao nao chegava at� 100 s� at� 10, assim pelo menos funcionou
            int Consumopontos = int.Parse(ConsumoPontosCombustivel.Text);
            int SomadoConsumoAnterior = ConsumodePontosEducacao + Consumopontos;
            int SomadoConsumoAnterior1 = ConsumoTotal + Consumopontos;
            ConsumoPontosCombustivel.Text = SomadoConsumoAnterior1.ToString();
            int quantiaDeDinheiroParaConsumoPorPessoa = SomadoConsumoAnterior / int.Parse(Povo.Text);
            int quantiaDeDinheiroParaConsumo = quantiaDeDinheiroParaConsumoPorPessoa * int.Parse(Povo.Text);
            int IN1;
            int DF1;
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { IN1 = 0; } else { IN1 = quantiaDeDinheiroParaConsumoPorPessoa - 100; }
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { DF1 = 100 - quantiaDeDinheiroParaConsumoPorPessoa; } else { DF1 = 0; };
            InflacaoPontosCombustivel.Text = IN1.ToString() + "%";
            DeflacaoPontosCombustivel.Text = DF1.ToString() + "%";
            InflacaopontosCombustivel = IN1;
            DeflacaopontosCombustivel = DF1;
        }

        public void ConsumodoPovoAlimento()
        {
            int ConsumoTotal = int.Parse(Povo.Text) * 5; //Antes ao inves de 5 era 10, mas como 10 deixava o consumo do povo mmuito alto, acabava por sobrar muito pouco recurso produzido por empresas;
            int ConsumodePontosEducacao = int.Parse(Povo.Text) * 100;//Eu coloquei 100 aqui pois na hora da porcentagem a deflacao nao chegava at� 100 s� at� 10, assim pelo menos funcionou
            int Consumopontos = int.Parse(ConsumoPontosAlimentos.Text);
            int SomadoConsumoAnterior = ConsumodePontosEducacao + Consumopontos;
            int SomadoConsumoAnterior1 = ConsumoTotal + Consumopontos;
            ConsumoPontosAlimentos.Text = SomadoConsumoAnterior1.ToString();
            int quantiaDeDinheiroParaConsumoPorPessoa = SomadoConsumoAnterior / int.Parse(Povo.Text);
            int quantiaDeDinheiroParaConsumo = quantiaDeDinheiroParaConsumoPorPessoa * int.Parse(Povo.Text);
            int IN1;
            int DF1;
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { IN1 = 0; } else { IN1 = quantiaDeDinheiroParaConsumoPorPessoa - 100; }
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { DF1 = 100 - quantiaDeDinheiroParaConsumoPorPessoa; } else { DF1 = 0; };
            InflacaoPontosAlimento.Text = IN1.ToString() + "%";
            DeflacaoPontosAlimento.Text = DF1.ToString() + "%";
            InflacaopontosAlimento = IN1;
            DeflacaopontosAlimento = DF1;
        }
        public void ConsumodoPovoSaude()
        {
            int ConsumoTotal = int.Parse(Povo.Text) * 5;
            int ConsumodePontosEducacao = int.Parse(Povo.Text) * 100;//Eu coloquei 100 aqui pois na hora da porcentagem a deflacao nao chegava at� 100 s� at� 10, assim pelo menos funcionou
            int Consumopontos = int.Parse(ConsumoPontosSaude.Text);
            int SomadoConsumoAnterior = ConsumodePontosEducacao + Consumopontos;
            int SomadoConsumoAnterior1 = ConsumoTotal + Consumopontos;
            ConsumoPontosSaude.Text = SomadoConsumoAnterior1.ToString();
            int quantiaDeDinheiroParaConsumoPorPessoa = SomadoConsumoAnterior / int.Parse(Povo.Text);
            int quantiaDeDinheiroParaConsumo = quantiaDeDinheiroParaConsumoPorPessoa * int.Parse(Povo.Text);
            int IN1;
            int DF1;
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { IN1 = 0; } else { IN1 = quantiaDeDinheiroParaConsumoPorPessoa - 100; }
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { DF1 = 100 - quantiaDeDinheiroParaConsumoPorPessoa; } else { DF1 = 0; };
            InflacaoPontosSaude.Text = IN1.ToString() + "%";
            DeflacaoPontosSaude.Text = DF1.ToString() + "%";
            InflacaopontosSaude = IN1;
            DeflacaopontosSaude = DF1;
        }

        public void ConsumodoPovoEducacao()
        {
            int ConsumoTotal = int.Parse(Povo.Text) * 5;// Coloquei 5 o consumo do povo pois com 10  o consummo era muito alto  e sobrava pouco extra
            int ConsumodePontosEducacao = int.Parse(Povo.Text) * 100;//Eu coloquei 100 aqui pois na hora da porcentagem a deflacao nao chegava at� 100 s� at� 10, assim pelo menos funcionou
            int Consumopontos = int.Parse(ConsumoPontosEducacao.Text);
            int SomadoConsumoAnterior = ConsumodePontosEducacao + Consumopontos;

            int SomadoConsumoAnterior1 = ConsumoTotal + Consumopontos;
            ConsumoPontosEducacao.Text = SomadoConsumoAnterior1.ToString();

            int quantiaDeDinheiroParaConsumoPorPessoa = SomadoConsumoAnterior / int.Parse(Povo.Text);//vc divide pelo povo, assim se o resultado da divisao for menor que 100 entao � deflacao
            int IN1;
            int DF1;
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { IN1 = 0; } else { IN1 = quantiaDeDinheiroParaConsumoPorPessoa - 100; } // Quando voce divide pelo povo, se der menor que 100 � deflacao, por isso a deflacao nao pode ser menor que zero.
            if (quantiaDeDinheiroParaConsumoPorPessoa < 100) { DF1 = 100 - quantiaDeDinheiroParaConsumoPorPessoa; } else { DF1 = 0; };// calculando 100 - (90) = 10, ou seja aquia deflacao seria de 10%, se fosse 99, seria 1%. Se for maior que 100 � igual a 0 pela regra da fun��o
            InflacaoPontosEducacao.Text = IN1.ToString() + "%";
            DeflacaoPontosEducacao.Text = DF1.ToString() + "%";
            InflacaopontosEducacao = IN1;
            DeflacaopontosEducacao = DF1;

        }

        void CobrarImpostos(int taxaImposto)
        {
            int dinheirocidadaos = int.Parse(label4.Text);
            int creditototal = int.Parse(TotalCredito.Text);
            if (dinheirocidadaos <= creditototal)
            {
                dinheirocidadaos = creditototal;
                return;
            }
            int impostos = (dinheiroDosCidadaos * taxaImposto) / 100;
            dinheiroDoGoverno += impostos;
            dinheiroDosCidadaos -= impostos;
            label2.Text = dinheiroDoGoverno.ToString();
            label4.Text = dinheiroDosCidadaos.ToString();


        }
        int Nascimentos()
        {

            int minCitizens = 10;
            int maxCitizens = 30;
            int numberOfCitizens = random.Next(minCitizens, maxCitizens + 1);
            int populacaodisponivel = int.Parse(PopulacaoDesempregada.Text) + numberOfCitizens;
            PopulacaoDesempregada.Text = populacaodisponivel.ToString();
            return numberOfCitizens;


        }


        public void CorrigirProblemaDeEmpregadosComNumeroNegativo()
        {//Quando a populacao desempregada fica negativa os empregados ficam 0, porem quando o numero de desempregados negativo volta a ficar positivo o numero de empregados fica negativo, aqui estou corrigindo este problema


            int povosememprego = int.Parse(PopulacaoDesempregada.Text);

            if (povosememprego > 0)
            {
                int totalescolasprivadas = int.Parse(TotalEscolasPrivadas.Text);
                int professoresprivados = totalescolasprivadas * 5;
                TotalProfessoresPrivados.Text = professoresprivados.ToString();

                int totalescolasestatais = int.Parse(TotalEscolas.Text);
                int professoresestatais = totalescolasestatais * 5;
                TotalProfessores.Text = professoresestatais.ToString();


            }

            if (povosememprego > 0)
            {
                int totalhospitaisprivadas = int.Parse(TotalHospitaisPrivados.Text);
                int medicosprivados = totalhospitaisprivadas * 9;
                TotalMedicosPrivados.Text = medicosprivados.ToString();

                int totalhospitaisestatais = int.Parse(TotalHospitais.Text);
                int medicosestatais = totalhospitaisestatais * 9;
                TotalMedicos.Text = medicosestatais.ToString();
            }

            if (povosememprego > 0)
            {
                int totalhospitaisprivadas = int.Parse(TotalFazendasPrivadas.Text);
                int medicosprivados = totalhospitaisprivadas * 8;
                TotalAgricultoresPrivados.Text = medicosprivados.ToString();

                int totalhospitaisestatais = int.Parse(TotalFazendas.Text);
                int medicosestatais = totalhospitaisestatais * 8;
                TotalAgricultores.Text = medicosestatais.ToString();
            }

            if (povosememprego > 0)
            {
                int totalhospitaisprivadas = int.Parse(TotalIndustriaCombustivelPrivada.Text);
                int medicosprivados = totalhospitaisprivadas * 5;
                TotalTecnicoCombustivelPrivado.Text = medicosprivados.ToString();

                int totalhospitaisestatais = int.Parse(TotalIndustriaCombustivel.Text);
                int medicosestatais = totalhospitaisestatais * 5;
                TotalTecnicoCombustivel.Text = medicosestatais.ToString();
            }

            if (povosememprego > 0)
            {
                int totalhospitaisprivadas = int.Parse(TotalIndustriaFerroPrivado.Text);
                int medicosprivados = totalhospitaisprivadas * 5;
                TotalMineradoresFerroPrivado.Text = medicosprivados.ToString();

                int totalhospitaisestatais = int.Parse(TotalIndustriaFerro.Text);
                int medicosestatais = totalhospitaisestatais * 5;
                TotalMineradoresFerro.Text = medicosestatais.ToString();
            }

            if (povosememprego > 0)
            {
                int totalhospitaisprivadas = int.Parse(TotalReservatoriosAgua.Text);
                int medicosprivados = totalhospitaisprivadas * 2;
                TotalEncanadores.Text = medicosprivados.ToString();


            }

            if (povosememprego > 0)
            {
                int totalhospitaisprivadas = int.Parse(TotalCentrosdeEnergia.Text);
                int medicosprivados = totalhospitaisprivadas * 2;
                TotalEletrecistas.Text = medicosprivados.ToString();


            }

            if (povosememprego > 0)
            {
                int Totalempresarios = int.Parse(TotalBancosPrivados.Text) + int.Parse(TotalEscolasPrivadas.Text) + int.Parse(TotalHospitaisPrivados.Text) + int.Parse(TotalFazendasPrivadas.Text) + int.Parse(TotalIndustriaFerroPrivado.Text) + int.Parse(TotalIndustriaCombustivelPrivada.Text);
                TotalEmpresarios.Text = Totalempresarios.ToString();

            }



        }

        public void populacaodesempregada1(int Pessoasdesempregadas)
        {
            int Pessoasdesempregadas1 = int.Parse(PopulacaoDesempregada.Text) + (Pessoasdesempregadas);
            PopulacaoDesempregada.Text = Pessoasdesempregadas1.ToString();

            PopulacaoEmpregada.Text = Povo.Text;


        }

        public void populacaodesempregada(int Pessoasdesempregadas)
        {
            int Pessoasdesempregadas1 = int.Parse(PopulacaoDesempregada.Text) + (Pessoasdesempregadas);
            PopulacaoDesempregada.Text = Pessoasdesempregadas1.ToString();
            int populacaoempregada = int.Parse(Povo.Text) - int.Parse(PopulacaoDesempregada.Text);
            int populacaoempregada1 = Math.Abs(populacaoempregada);
            PopulacaoEmpregada.Text = populacaoempregada1.ToString();


        }


        public void metodonovopredio(int valor, string Total, string Governo, string Cidadao)
        {
            labelpredio.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int LabelPopulacaoComResidencia = (int.Parse(label480.Text) * 5) + (int.Parse(labelpredio.Text) * 13);
            int LabelPopulacaoSemResidencia = int.Parse(Povo.Text) - LabelPopulacaoComResidencia;
            if (LabelPopulacaoSemResidencia < 1) { labelPopulacaoSemResidencia.Text = "0"; }
            if (LabelPopulacaoSemResidencia < 1) { return; };
            labelPopulacaoSemResidencia.Text = LabelPopulacaoSemResidencia.ToString();
        }
        public void metodonovocasa(int valor, string Total, string Governo, string Cidadao)
        {

            label480.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int LabelPopulacaoComResidencia = (int.Parse(label480.Text) * 5) + (int.Parse(labelpredio.Text) * 13);
            int LabelPopulacaoSemResidencia = int.Parse(Povo.Text) - LabelPopulacaoComResidencia;
            if (LabelPopulacaoSemResidencia < 1) { labelPopulacaoSemResidencia.Text = "0"; }
            if (LabelPopulacaoSemResidencia < 1) { return; };
            labelPopulacaoSemResidencia.Text = LabelPopulacaoSemResidencia.ToString();


        }

        public void metodonovaFazenda(int valor, string Total, string Governo, string Cidadao)
        {
            TotalFazendas.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int EspacoDisponivelParaFazendas = int.Parse(TotalFazendas.Text) * 50;
            int PopulacaoSemAcessoComida = EspacoDisponivelParaFazendas - int.Parse(Povo.Text);

            PovoComFome.Text = PopulacaoSemAcessoComida.ToString();

            int povosemacessocomida = int.Parse(PovoComFome.Text);

            if (povosemacessocomida < 0)
            {
                povosemacessocomida = -povosemacessocomida; // sinal do n�mero para torn�-lo positivo
            }
            else if (povosemacessocomida > 0)
            {
                povosemacessocomida = -povosemacessocomida;// Inverte o sinal do n�mero para torn�-lo negativo
            }

            PovoComFome.Text = povosemacessocomida.ToString();
        }
        public void metodonovoHospital(int valor, string Total, string Governo, string Cidadao)
        {

            TotalHospitais.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int EspacoDisponivelParaHospitais = int.Parse(TotalHospitais.Text) * 60;
            int PopulacaoSemAcessoHospitais = EspacoDisponivelParaHospitais - int.Parse(Povo.Text);

            PopulacaoSemAcessoHospital.Text = PopulacaoSemAcessoHospitais.ToString();

            int povosemacessocomida = int.Parse(PopulacaoSemAcessoHospital.Text);

            if (povosemacessocomida < 0)
            {
                povosemacessocomida = -povosemacessocomida; // sinal do n�mero para torn�-lo positivo
            }
            else if (povosemacessocomida > 0)
            {
                povosemacessocomida = -povosemacessocomida;// Inverte o sinal do n�mero para torn�-lo negativo
            }

            PopulacaoSemAcessoHospital.Text = povosemacessocomida.ToString();
        }

        public void metodonovaInstituicaoDeEnsino(int valor, string Total, string Governo, string Cidadao)
        {

            TotalEscolas.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int EspacoDisponivelParaInstituicoesDeEnsino = int.Parse(TotalEscolas.Text) * 40;
            int PopulacaoSemEducacao = EspacoDisponivelParaInstituicoesDeEnsino - int.Parse(Povo.Text);

            populacaoSemEducacao.Text = PopulacaoSemEducacao.ToString();

            int povosemeducacao = int.Parse(populacaoSemEducacao.Text);

            if (povosemeducacao < 0)
            {
                povosemeducacao = -povosemeducacao; // sinal do n�mero para torn�-lo positivo
            }
            else if (povosemeducacao > 0)
            {
                povosemeducacao = -povosemeducacao;// Inverte o sinal do n�mero para torn�-lo negativo
            }

            populacaoSemEducacao.Text = povosemeducacao.ToString();
        }

        public void metodonovoCentrodeEnergia(int valor, string Total, string Governo, string Cidadao)
        {
            TotalCentrosdeEnergia.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int EspacoDisponivelParaMaisPessoasComAcessoEnergia = int.Parse(TotalCentrosdeEnergia.Text) * 40;
            int PopulacaoSemAcessoEnergiaEletrica = EspacoDisponivelParaMaisPessoasComAcessoEnergia - int.Parse(Povo.Text);

            PovoSemEnergia.Text = PopulacaoSemAcessoEnergiaEletrica.ToString();

            int povosemenergiaeletrica = int.Parse(PovoSemEnergia.Text);

            if (povosemenergiaeletrica < 0)
            {
                povosemenergiaeletrica = -povosemenergiaeletrica; // sinal do n�mero para torn�-lo positivo
            }
            else if (povosemenergiaeletrica > 0)
            {
                povosemenergiaeletrica = -povosemenergiaeletrica;// Inverte o sinal do n�mero para torn�-lo negativo
            }

            PovoSemEnergia.Text = povosemenergiaeletrica.ToString();
        }

        public void metodonovoReservatorioAgua(int valor, string Total, string Governo, string Cidadao)
        {
            TotalReservatoriosAgua.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int EspacoDisponivelParaMaisPessoasComAcessoASaneamentoBasico = int.Parse(TotalReservatoriosAgua.Text) * 40;
            int PopulacaoSemAcessoSaneamentoBasico = EspacoDisponivelParaMaisPessoasComAcessoASaneamentoBasico - int.Parse(Povo.Text);

            PovoSemSaneamento.Text = PopulacaoSemAcessoSaneamentoBasico.ToString();

            int povosemsaneamento = int.Parse(PovoSemSaneamento.Text);

            if (povosemsaneamento < 0)
            {
                povosemsaneamento = -povosemsaneamento; // sinal do n�mero para torn�-lo positivo
            }
            else if (povosemsaneamento > 0)
            {
                povosemsaneamento = -povosemsaneamento;// Inverte o sinal do n�mero para torn�-lo negativo
            }

            PovoSemSaneamento.Text = povosemsaneamento.ToString();
        }

        public void NovoQuartel(int valor, string Total, string Governo, string Cidadao)
        {
            TotalQuarteis.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int espacodisponivelsoldados = int.Parse(EspacoDisponivelSoldados.Text) + 50;
            EspacoDisponivelSoldados.Text = espacodisponivelsoldados.ToString();

        }

        public void NovaDelegacia(int valor, string Total, string Governo, string Cidadao)
        {
            TotalDelegacias.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

            int espacodisponivelpoliciais = int.Parse(EspacoDisponivelPoliciais.Text) + 50;
            EspacoDisponivelPoliciais.Text = espacodisponivelpoliciais.ToString();

        }

        public void NovaIndustriaFerro(int valor, string Total, string Governo, string Cidadao)
        {
            TotalIndustriaFerro.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

        }

        public void NovaIndustriaCombustivel(int valor, string Total, string Governo, string Cidadao)
        {
            TotalIndustriaCombustivel.Text = valor.ToString();
            label1.Text = Total;
            DinheiroTotal = int.Parse(Total);
            label2.Text = Governo;
            dinheiroDoGoverno = int.Parse(Governo);
            dinheiroDosCidadaos = int.Parse(Cidadao);
            label4.Text = Cidadao;

        }


        public void MenosUmaCasa()
        {
            int PessoasSemResidencia = int.Parse(labelPopulacaoSemResidencia.Text) + 5;
            labelPopulacaoSemResidencia.Text = PessoasSemResidencia.ToString();
            int LabelMenosUmaCasa = int.Parse(label480.Text) - 1;
            label480.Text = LabelMenosUmaCasa.ToString();

        }

        public void MenosUmaEscola()
        {


            int PessoasSemEducacao = int.Parse(populacaoSemEducacao.Text) + 40;
            populacaoSemEducacao.Text = PessoasSemEducacao.ToString();
            int MenosUmaEscola = int.Parse(TotalEscolas.Text) - 1;
            TotalEscolas.Text = MenosUmaEscola.ToString();
        }

        public void MenosUmHospital()
        {
            int PessoasSemacessoHospital = int.Parse(PopulacaoSemAcessoHospital.Text) + 60;
            PopulacaoSemAcessoHospital.Text = PessoasSemacessoHospital.ToString();
            int MenosUmHospital = int.Parse(TotalHospitais.Text) - 1;
            TotalHospitais.Text = MenosUmHospital.ToString();
        }
        public void MenosUmPredio()
        {
            int PessoasSemResidencia = int.Parse(labelPopulacaoSemResidencia.Text) + 13;
            labelPopulacaoSemResidencia.Text = PessoasSemResidencia.ToString();
            int LabelMenosUmPredio = int.Parse(labelpredio.Text) - 1;
            labelpredio.Text = LabelMenosUmPredio.ToString();

        }

        public void MenosUmaFazenda()
        {

            int PessoasComFome = int.Parse(PovoComFome.Text) + 50;
            PovoComFome.Text = PessoasComFome.ToString();
            int MenosUmaFazenda = int.Parse(TotalFazendas.Text) - 1;
            TotalFazendas.Text = MenosUmaFazenda.ToString();
        }

        public void MenosUmCentroEnergia()
        {
            int PessoasSemEnergia = int.Parse(PovoSemEnergia.Text) + 40;
            PovoSemEnergia.Text = PessoasSemEnergia.ToString();
            int MenosUmCentroEnergia = int.Parse(TotalCentrosdeEnergia.Text) - 1;
            TotalCentrosdeEnergia.Text = MenosUmCentroEnergia.ToString();
        }

        public void MenosUmReservatorioAgua()
        {
            int PessoassemSaneamento = int.Parse(PovoSemSaneamento.Text) + 40;
            PovoSemSaneamento.Text = PessoassemSaneamento.ToString();
            int MenosumReservatorioAgua = int.Parse(TotalReservatoriosAgua.Text) - 1;
            TotalReservatoriosAgua.Text = MenosumReservatorioAgua.ToString();
        }

        public void MenosUmQuartel()
        {
            int espacodisponivelsoldados = int.Parse(EspacoDisponivelSoldados.Text) - 50;
            EspacoDisponivelSoldados.Text = espacodisponivelsoldados.ToString();
            int MenosQuartel = int.Parse(TotalQuarteis.Text) - 1;
            TotalQuarteis.Text = MenosQuartel.ToString();
        }

        public void MenosUmaDelegacia()
        {
            int espacodisponivelpoliciais = int.Parse(EspacoDisponivelPoliciais.Text) - 50;
            EspacoDisponivelPoliciais.Text = espacodisponivelpoliciais.ToString();
            int MenosDelegacia = int.Parse(TotalDelegacias.Text) - 1;
            TotalDelegacias.Text = MenosDelegacia.ToString();
        }

        public void MenosUmaIndustriaFerro()
        {

            int MenosIndustriadeFerro = int.Parse(TotalIndustriaFerro.Text) - 1;
            TotalIndustriaFerro.Text = MenosIndustriadeFerro.ToString();
        }

        public void MenosUmaIndustriaCombustivel()
        {

            int MenosIndustriadeCombustivel = int.Parse(TotalIndustriaCombustivel.Text) - 1;
            TotalIndustriaCombustivel.Text = MenosIndustriadeCombustivel.ToString();
        }

        public void Terrasdisponiveis(int Terrasdisponiveis)
        {
            TerrasDisponiveis.Text = Terrasdisponiveis.ToString();
            int Terrasocupadas = int.Parse(TerritoriosPais.Text) - int.Parse(TerrasDisponiveis.Text);
            TerrasOcupadas.Text = Terrasocupadas.ToString();
        }

        public void SalarioMinimoprofessores(int salariominimo1)
        {
            SalarioMinimoProfessores = salariominimo1;
        }

        public void SalarioMinimoagricultores(int salariominimo1)
        {
            SalarioMinimoAgricultores = salariominimo1;
        }

        public void SalarioMinimomedicos(int salariominimo1)
        {
            SalarioMinimoMedicos = salariominimo1;
        }

        public void SalarioMinimoprofessoresEstatal(int salariominimo1)
        {
            SalarioMinimoProfessoresEstatal = salariominimo1;
        }

        public void SalarioMinimoagricultoresEstatal(int salariominimo1)
        {
            SalarioMinimoAgricultoresEstatal = salariominimo1;
        }

        public void SalarioMinimomedicosEstatal(int salariominimo1)
        {
            SalarioMinimoMedicosEstatal = salariominimo1;
        }

        public void SalarioMinimopoliciaisEstatal(int salariominimo1)
        {
            SalarioMinimoPoliciaisEstatal = salariominimo1;
        }

        public void SalarioMinimosoldadosEstatal(int salariominimo1)
        {
            SalarioMinimoSoldadosEstatal = salariominimo1;
        }

        public void SalarioMinimoeletrecistasEstatal(int salariominimo1)
        {
            SalarioMinimoEletrecistasEstatal = salariominimo1;
        }

        public void SalarioMinimoencanadoresEstatal(int salariominimo1)
        {
            SalarioMinimoEncanadoresEstatal = salariominimo1;
        }

        public void SalarioMinimoMineradoresFerroEstatal(int salariominimo1)
        {
            SalarioMinimoMineradorFerroEstatal = salariominimo1;
        }

        public void SalarioMinimoTecnicocombustivelEstatal(int salariominimo1)
        {
            SalarioMinimoTecnicoCombustivelEstatal = salariominimo1;
        }

        public void SalarioMinimoMineradoresFerro(int salariominimo1)
        {
            SalarioMinimoMineradorFerro = salariominimo1;
        }

        public void SalarioMinimoTecnicocombustivel(int salariominimo1)
        {
            SalarioMinimoTecnicoCombustivel = salariominimo1;
        }


        public void Agricultores(int Agricultores1)
        {
            TotalAgricultores.Text = Agricultores1.ToString();

        }
        public void medicos(int medicos1)
        {
            TotalMedicos.Text = medicos1.ToString();

        }
        public void professores(int Professores1)
        {
            TotalProfessores.Text = Professores1.ToString();

        }

        public void eletrecista(int eletrecista1)
        {
            TotalEletrecistas.Text = eletrecista1.ToString();

        }

        public void encanador(int encanadores1)
        {
            TotalEncanadores.Text = encanadores1.ToString();

        }

        public void mineradorferro(int mineradorferro1)
        {
            TotalMineradoresFerro.Text = mineradorferro1.ToString();
        }

        public void Tecnicocombustivel(int tecnicocombustivel1)
        {
            TotalTecnicoCombustivel.Text = tecnicocombustivel1.ToString();
        }


        public void MetodoBUGInstituicaoDeEnsinoPrivada()
        {
            int Dobrosalariominimoesperado = int.Parse(SalarioMinimoEsperado.Text) * 2;
            if (SalarioMinimoProfessores > Dobrosalariominimoesperado)
            {

                int totalescola1 = int.Parse(TotalEscolas.Text) + int.Parse(TotalEscolasPrivadas.Text);

                TotaldeEscolas.Text = totalescola1.ToString();

                int populacaocomeducacao = (int.Parse(TotalEscolas.Text) * 40) + (int.Parse(TotalEscolasPrivadas.Text) * 50);
                int populacaosemeducacao = int.Parse(Povo.Text) - populacaocomeducacao;
                populacaoSemEducacao.Text = populacaosemeducacao.ToString();

                int totalescola2 = int.Parse(TotalEscolas.Text) + int.Parse(TotalEscolasPrivadas.Text);
                TotaldeEscolas.Text = totalescola1.ToString();
            }
            else
            {
                int totalescola = int.Parse(TotalEscolas.Text) + int.Parse(TotalEscolasPrivadas.Text);
                TotaldeEscolas.Text = totalescola.ToString();

                int populacaocomeducacao = int.Parse(TotaldeEscolas.Text) * 40;
                int populacaosemeducacao = int.Parse(Povo.Text) - populacaocomeducacao;
                populacaoSemEducacao.Text = populacaosemeducacao.ToString();

                int totalescola1 = int.Parse(TotalEscolas.Text) + int.Parse(TotalEscolasPrivadas.Text);
                TotaldeEscolas.Text = totalescola1.ToString();
            }
        }


















        public void InstituicaodeEnsinoPrivada()
        {


            int PrecoInstituicaoPrivada = DinheiroTotal / 11;

            int Escolasnecessarias = int.Parse(populacaoSemEducacao.Text);
            //decimal Escolasnecessarias1 = (decimal)Escolasnecessarias / 40;
            //decimal Escolasnecessarias2 = Math.Floor(Escolasnecessarias1);
            //int Escolasnecessarias = Convert.ToInt32(Escolasnecessarias2);

            //int PrecototalNovasEscolasPrivadas = PrecoInstituicaoPrivada * Escolasnecessarias;
            int totalcredito = int.Parse(TotalCredito.Text);

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);


            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            if (totalcredito > PrecoInstituicaoPrivada && terradisponivel > 0)
            {
                int TotalescolasPrivadas = int.Parse(TotalEscolasPrivadas.Text) + 1;
                TotalEscolasPrivadas.Text = TotalescolasPrivadas.ToString();

                int AtualizandoTotalCredito = int.Parse(TotalCredito.Text) - PrecoInstituicaoPrivada;
                TotalCredito.Text = AtualizandoTotalCredito.ToString();

                int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) - 1;
                Terrasdisponiveis(terrasdisponiveis);

                if (PopulacaoSemEmprego > 5)
                {
                    int totalprofessores = int.Parse(TotalProfessoresPrivados.Text) + 5;
                    TotalProfessoresPrivados.Text = totalprofessores.ToString();
                    int totalEmpresarios = int.Parse(TotalEmpresarios.Text) + 1;
                    TotalEmpresarios.Text = totalEmpresarios.ToString();
                    int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) + 6;
                    PopulacaoEmpregada.Text = povoEmpregado.ToString();
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 6;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                }
                else
                {
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 6;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                    TotalProfessoresPrivados.Text = TotalProfessoresPrivados.Text;
                    TotalEmpresarios.Text = TotalEmpresarios.Text;
                }
















            }

            AtualizadordeTotais();


        }

        public void MetodoBUGhospital()
        {
            // Este construtor foi criado a fim de corrigir um problema no construtor HospitalPrivado, por algum BUG esta mesma fun��o abaixo n�o estava funcionando no metodo Hospital privado.
            int Dobrosalariominimoesperado = int.Parse(SalarioMinimoEsperado.Text) * 2;
            if (SalarioMinimoMedicos > Dobrosalariominimoesperado)
            {

                int totalhospital1 = int.Parse(TotalHospitais.Text) + int.Parse(TotalHospitaisPrivados.Text);
                TotaldeHospitais.Text = totalhospital1.ToString();

                int populacaocomAcessoHospital = int.Parse(TotalHospitais.Text) * 60;
                int populacaocomAcessoHospital1 = int.Parse(TotalHospitaisPrivados.Text) * 70;
                int populacaocomAcessoHospital2 = populacaocomAcessoHospital + populacaocomAcessoHospital1;
                int populacaosemAcessoHospital = int.Parse(Povo.Text) - populacaocomAcessoHospital2;
                PopulacaoSemAcessoHospital.Text = populacaosemAcessoHospital.ToString();

                int totalhospital2 = int.Parse(TotalHospitais.Text) + int.Parse(TotalHospitaisPrivados.Text);
                TotaldeHospitais.Text = totalhospital2.ToString();
            }
            else
            {
                int populacaocomAcessoHospital = int.Parse(TotalHospitais.Text) * 60;
                int populacaocomAcessoHospital1 = int.Parse(TotalHospitaisPrivados.Text) * 60;
                int populacaocomAcessoHospital2 = populacaocomAcessoHospital + populacaocomAcessoHospital1;
                int populacaosemAcessoHospital = int.Parse(Povo.Text) - populacaocomAcessoHospital2;
                PopulacaoSemAcessoHospital.Text = populacaosemAcessoHospital.ToString();
            }
        }
        public void Hospitalprivado()
        {


            int PrecoHospitalPrivado = DinheiroTotal / 15;

            int Hospitaisnecessarios = int.Parse(PopulacaoSemAcessoHospital.Text);
            //decimal Escolasnecessarias1 = (decimal)Escolasnecessarias / 40;
            //decimal Escolasnecessarias2 = Math.Floor(Escolasnecessarias1);
            //int Escolasnecessarias = Convert.ToInt32(Escolasnecessarias2);

            //int PrecototalNovasEscolasPrivadas = PrecoInstituicaoPrivada * Escolasnecessarias;
            int totalcredito = int.Parse(TotalCredito.Text);

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            if (totalcredito > PrecoHospitalPrivado && terradisponivel > 0)
            {
                int Totalhospitaisprivados = int.Parse(TotalHospitaisPrivados.Text) + 1;
                TotalHospitaisPrivados.Text = Totalhospitaisprivados.ToString();

                int AtualizandoTotalCredito = int.Parse(TotalCredito.Text) - PrecoHospitalPrivado;
                TotalCredito.Text = AtualizandoTotalCredito.ToString();

                int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) - 1;
                Terrasdisponiveis(terrasdisponiveis);

                if (PopulacaoSemEmprego > 9)
                {
                    int totalmedicos = int.Parse(TotalMedicosPrivados.Text) + 9;
                    TotalMedicosPrivados.Text = totalmedicos.ToString();
                    int totalEmpresarios = int.Parse(TotalEmpresarios.Text) + 1;
                    TotalEmpresarios.Text = totalEmpresarios.ToString();
                    int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) + 10;
                    PopulacaoEmpregada.Text = povoEmpregado.ToString();


                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 10;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                }
                else
                {
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 10;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                    TotalMedicosPrivados.Text = TotalMedicosPrivados.Text;
                    TotalEmpresarios.Text = TotalEmpresarios.Text;
                }







            }

            AtualizadordeTotais();
        }

        public void BUGFazendaPrivada()
        {
            int Dobrosalariominimoesperado = int.Parse(SalarioMinimoEsperado.Text) * 2;
            if (SalarioMinimoAgricultores > Dobrosalariominimoesperado)
            {

                int totalfazenda1 = int.Parse(TotalFazendas.Text) + int.Parse(TotalFazendasPrivadas.Text);
                TotaldeFazendas.Text = totalfazenda1.ToString();

                int populacaoSemFome = (int.Parse(TotalFazendas.Text) * 50) + (int.Parse(TotalFazendasPrivadas.Text) * 60);
                int populacaoComFome = int.Parse(Povo.Text) - populacaoSemFome;
                PovoComFome.Text = populacaoComFome.ToString();

                int totalfazenda2 = int.Parse(TotalFazendas.Text) + int.Parse(TotalFazendasPrivadas.Text);
                TotaldeFazendas.Text = totalfazenda2.ToString();
            }
            else
            {
                int totalfazenda = int.Parse(TotalFazendas.Text) + int.Parse(TotalFazendasPrivadas.Text);
                TotaldeFazendas.Text = totalfazenda.ToString();

                int populacaoSemFome = int.Parse(TotaldeFazendas.Text) * 50;
                int populacaoComFome = int.Parse(Povo.Text) - populacaoSemFome;
                PovoComFome.Text = populacaoComFome.ToString();

                int totalfazenda1 = int.Parse(TotalFazendas.Text) + int.Parse(TotalFazendasPrivadas.Text);
                TotaldeFazendas.Text = totalfazenda1.ToString();
            }

            AtualizadordeTotais();
        }

        public void FazendaPrivada()
        {


            int PrecoHospitalPrivado = DinheiroTotal / 13;

            int Hospitaisnecessarios = int.Parse(PopulacaoSemAcessoHospital.Text);
            //decimal Escolasnecessarias1 = (decimal)Escolasnecessarias / 40;
            //decimal Escolasnecessarias2 = Math.Floor(Escolasnecessarias1);
            //int Escolasnecessarias = Convert.ToInt32(Escolasnecessarias2);

            //int PrecototalNovasEscolasPrivadas = PrecoInstituicaoPrivada * Escolasnecessarias;
            int totalcredito = int.Parse(TotalCredito.Text);

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            if (totalcredito > PrecoHospitalPrivado && terradisponivel > 0)
            {
                int Totalfazendasprivadas = int.Parse(TotalFazendasPrivadas.Text) + 1;
                TotalFazendasPrivadas.Text = Totalfazendasprivadas.ToString();

                int AtualizandoTotalCredito = int.Parse(TotalCredito.Text) - PrecoHospitalPrivado;
                TotalCredito.Text = AtualizandoTotalCredito.ToString();

                int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) - 1;
                Terrasdisponiveis(terrasdisponiveis);

                if (PopulacaoSemEmprego > 8)
                {
                    int totalagricultores = int.Parse(TotalAgricultoresPrivados.Text) + 8;
                    TotalAgricultoresPrivados.Text = totalagricultores.ToString();
                    int totalEmpresarios = int.Parse(TotalEmpresarios.Text) + 1;
                    TotalEmpresarios.Text = totalEmpresarios.ToString();
                    int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) + 9;
                    PopulacaoEmpregada.Text = povoEmpregado.ToString();


                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 9;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                }
                else
                {
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 9;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                    TotalAgricultoresPrivados.Text = TotalAgricultoresPrivados.Text;
                    TotalEmpresarios.Text = TotalEmpresarios.Text;
                }

            }

            AtualizadordeTotais();
        }


        public void IndustriadeCombustivel()
        {


            int PrecoIndustriaCombustivel = DinheiroTotal / 6;

            int Hospitaisnecessarios = int.Parse(PopulacaoSemAcessoHospital.Text);
            //decimal Escolasnecessarias1 = (decimal)Escolasnecessarias / 40;
            //decimal Escolasnecessarias2 = Math.Floor(Escolasnecessarias1);
            //int Escolasnecessarias = Convert.ToInt32(Escolasnecessarias2);

            //int PrecototalNovasEscolasPrivadas = PrecoInstituicaoPrivada * Escolasnecessarias;
            int totalcredito = int.Parse(TotalCredito.Text);

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            if (totalcredito > PrecoIndustriaCombustivel && terradisponivel > 0)
            {
                int TotalIndustriacombustivelPrivada = int.Parse(TotalIndustriaCombustivelPrivada.Text) + 1;
                TotalIndustriaCombustivelPrivada.Text = TotalIndustriacombustivelPrivada.ToString();

                int AtualizandoTotalCredito = int.Parse(TotalCredito.Text) - PrecoIndustriaCombustivel;
                TotalCredito.Text = AtualizandoTotalCredito.ToString();

                int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) - 1;
                Terrasdisponiveis(terrasdisponiveis);

                if (PopulacaoSemEmprego > 5)
                {
                    int totalteccombustivel = int.Parse(TotalTecnicoCombustivelPrivado.Text) + 5;
                    TotalTecnicoCombustivelPrivado.Text = totalteccombustivel.ToString();
                    int totalEmpresarios = int.Parse(TotalEmpresarios.Text) + 1;
                    TotalEmpresarios.Text = totalEmpresarios.ToString();
                    int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) + 6;
                    PopulacaoEmpregada.Text = povoEmpregado.ToString();


                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 6;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                }
                else
                {
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 6;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                    TotalTecnicoCombustivelPrivado.Text = TotalTecnicoCombustivelPrivado.Text;
                    TotalEmpresarios.Text = TotalEmpresarios.Text;
                }


                int totalindustriacombustivel1 = int.Parse(TotalIndustriaCombustivel.Text) + int.Parse(TotalIndustriaCombustivelPrivada.Text);
                TotaldeIndustriaCombustivel.Text = totalindustriacombustivel1.ToString();



            }

            AtualizadordeTotais();
        }


        public void IndustriadeFerro()
        {


            int PrecoIndustriaCombustivel = DinheiroTotal / 6;

            //decimal Escolasnecessarias1 = (decimal)Escolasnecessarias / 40;
            //decimal Escolasnecessarias2 = Math.Floor(Escolasnecessarias1);
            //int Escolasnecessarias = Convert.ToInt32(Escolasnecessarias2);

            //int PrecototalNovasEscolasPrivadas = PrecoInstituicaoPrivada * Escolasnecessarias;
            int totalcredito = int.Parse(TotalCredito.Text);

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            if (totalcredito > PrecoIndustriaCombustivel && terradisponivel > 0)
            {
                int TotalIndustriaFerroPrivada = int.Parse(TotalIndustriaFerroPrivado.Text) + 1;
                TotalIndustriaFerroPrivado.Text = TotalIndustriaFerroPrivada.ToString();

                int AtualizandoTotalCredito = int.Parse(TotalCredito.Text) - PrecoIndustriaCombustivel;
                TotalCredito.Text = AtualizandoTotalCredito.ToString();

                int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) - 1;
                Terrasdisponiveis(terrasdisponiveis);

                if (PopulacaoSemEmprego > 5)
                {
                    int totalmineradorferro = int.Parse(TotalMineradoresFerroPrivado.Text) + 5;
                    TotalMineradoresFerroPrivado.Text = totalmineradorferro.ToString();
                    int totalEmpresarios = int.Parse(TotalEmpresarios.Text) + 1;
                    TotalEmpresarios.Text = totalEmpresarios.ToString();
                    int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) + 6;
                    PopulacaoEmpregada.Text = povoEmpregado.ToString();


                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 6;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                }
                else
                {
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 6;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                    TotalMineradoresFerroPrivado.Text = TotalMineradoresFerroPrivado.Text;
                    TotalEmpresarios.Text = TotalEmpresarios.Text;
                }


                int totalindustriaferro1 = int.Parse(TotalIndustriaFerro.Text) + int.Parse(TotalIndustriaFerroPrivado.Text);
                TotaldeIndustriaFerro.Text = totalindustriaferro1.ToString();

                AtualizadordeTotais();

            }
        }


        public void BancoPrivado()
        {
            int TotalBancos = int.Parse(TotalBancosPrivados.Text);
            if (TotalBancos > 19)
            {
                return;
            }
            int PrecoBancoPrivado = DinheiroTotal / 10;

            int Escolasnecessarias = int.Parse(populacaoSemEducacao.Text);

            int totalcredito = int.Parse(TotalCredito.Text);

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            if (totalcredito > PrecoBancoPrivado && terradisponivel > 0)
            {
                int totalBancosPrivados = int.Parse(TotalBancosPrivados.Text) + 1;
                TotalBancosPrivados.Text = totalBancosPrivados.ToString();

                int AtualizandoTotalCredito = int.Parse(TotalCredito.Text) - PrecoBancoPrivado;
                TotalCredito.Text = AtualizandoTotalCredito.ToString();

                int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) - 1;
                Terrasdisponiveis(terrasdisponiveis);

                if (PopulacaoSemEmprego > 0)
                {
                    int totalEmpresarios = int.Parse(TotalEmpresarios.Text) + 1;
                    TotalEmpresarios.Text = totalEmpresarios.ToString();
                    int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) + 1;
                    PopulacaoEmpregada.Text = povoEmpregado.ToString();


                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 1;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                }
                else
                {
                    int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) - 1;
                    PopulacaoDesempregada.Text = povoDesempregado.ToString();
                    TotalEmpresarios.Text = TotalEmpresarios.Text;
                }



            }

            AtualizadordeTotais();

        }

        public void MaisCreditoNacional()
        {
            int taxaselic = int.Parse(TaxaSelic.Text);
            int Umporcento = dinheiroDosCidadaos / 100;
            int TotaldeBancosPrivados = int.Parse(TotalBancosPrivados.Text);
            int TotaldeCredito = TotaldeBancosPrivados * Umporcento;
            int TotaldeCreditoMais = int.Parse(TotalCredito.Text) + TotaldeCredito;

            if (TotaldeCreditoMais > dinheiroDosCidadaos)
            {
                TotalCredito.Text = dinheiroDosCidadaos.ToString();
            }


            if (taxaselic > 14)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 16;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }

            }
            else if (taxaselic > 13)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 15;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 12)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 14;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 11)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 13;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 10)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 12;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 9)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 11;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 8)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 10;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 7)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 9;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 6)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 8;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 5)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 7;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 4)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 6;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 3)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 5;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 2)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 4;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 1)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 3;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > 0)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1 / 2;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }
            else if (taxaselic > -1)
            {
                int Umporcento1 = dinheiroDosCidadaos / 100;
                int AtualizarPorCentoDeAcordoComValorTaxaSelic = Umporcento1;
                int TotaldeBancosPrivados1 = int.Parse(TotalBancosPrivados.Text);
                int TotaldeCredito1 = TotaldeBancosPrivados1 * AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int TotaldeCreditoMais1 = int.Parse(TotalCredito.Text) + TotaldeCredito1;
                TotalCredito.Text = TotaldeCreditoMais1.ToString();
                EmprestimosPorBanco.Text = AtualizarPorCentoDeAcordoComValorTaxaSelic.ToString();

                int Titulospublicos = Umporcento1 - AtualizarPorCentoDeAcordoComValorTaxaSelic;
                int Titulospublicos2 = int.Parse(TitulosMoney.Text) + Titulospublicos;
                TitulosMoney.Text = Titulospublicos2.ToString();
                int Titulospublico1 = Umporcento1;
                int Titulosmoney = int.Parse(TitulosMoney.Text);
                if (Titulosmoney > Titulospublico1)
                {
                    int Titulospublicos3 = int.Parse(TitulosMoney.Text) - Titulospublico1;
                    TitulosMoney.Text = Titulospublicos3.ToString();
                    dinheiroDoGoverno = dinheiroDoGoverno + Titulospublico1;
                    label2.Text = dinheiroDoGoverno.ToString();
                    dinheiroDosCidadaos = dinheiroDosCidadaos - Titulospublico1;
                    label4.Text = dinheiroDosCidadaos.ToString();
                    int Titulospublicos4 = int.Parse(TitulosPublicos.Text) + 1;
                    TitulosPublicos.Text = Titulospublicos4.ToString();

                }
            }




        }








        public Form1()
        {
            InitializeComponent();

            if (TaxaSelic.Text == "")
            {
                TaxaSelic.Text = "0";
            }

            if (Taxa.Text == "")
            {
                Taxa.Text = "0";
            }
            PovoSemResidencia = 200;
            labelPopulacaoSemResidencia.Text = PovoSemResidencia.ToString();
            QuantidadedeHospitais = int.Parse(TotalHospitais.Text);
            TerrasDisponiveis.Text = TerritoriosPais.Text;
            Povo.Text = "200";
            label1.Text = DinheiroTotal.ToString();
            label4.Text = dinheiroDosCidadaos.ToString();
            PovoSemEnergia.Text = "200";
            PovoSemSaneamento.Text = "200";
            PopulacaoDesempregada.Text = "200";

            if (TaxaSelic.Text == "")
            {
                Taxa.Text = "0";
            }

            if (Taxa.Text == "")
            {
                Taxa.Text = "0";
            }

            //Aqui � calculado a quantia min�ma de dinheiro necess�ria em circula��o e a quantia de dinheiro por pessoa
            int N = int.Parse(Povo.Text);
            Povo.Text = N.ToString();
            int Minimo = N * 100;
            INDF.Text = Minimo.ToString();
            int P = dinheiroDosCidadaos / N;
            QDP.Text = P.ToString();

            //Aqui � calculado a infla��o e defla��o de moeda
            int IN1;
            if (P < 100) { IN1 = 0; } else { IN1 = P - 100; }
            IN.Text = IN1.ToString() + "%";
            int DF1;
            if (P < 100) { DF1 = 100 - P; } else { DF1 = 0; };
            DF.Text = DF1.ToString() + "%";
            InflacaoDeMoeda = IN1;
            DeflacaoDeMoeda = DF1;

            int precovendatitulos = dinheiroDosCidadaos / 100;
            int precocompratitulos = dinheiroDosCidadaos / 80;
            PrecoVendaTitulos.Text = precovendatitulos.ToString();
            PrecoCompraTitulos.Text = precocompratitulos.ToString();



            ConsumodoPovo();
            MaisCreditoNacional();
            IndiceAleatorioDeEdfificiosPrivados();
            MetodoBUGhospital();
            BUGFazendaPrivada();
            MetodoBUGInstituicaoDeEnsinoPrivada();

            AtualizadorRecursosEducacaoPrivado();//Aqui como nos outros abaixo est�o os atualizadores que acrescentam recursos que foram produzidos pelo pa�s.
            AtualizadorRecursosEducacaoEstatal();
            AtualizadorRecursosSaudeEstatal();
            AtualizadorRecursosSaudePrivada();
            AtualizadorRecursosAlimentosEstatal();
            AtualizadorRecursosAlimentosPrivado();
            AtualizadorRecursosCombustivelPrivado();
            AtualizadorRecursosCombustivelEstatal();
            AtualizadorRecursosFerroEstatal();
            AtualizadorRecursosFerroPrivado();



            CalculoInflacaoDeCustos();
            CalculoInflacaoDeCustos();
            deflacaoDeCusto();
            SalarioMinimoMediaNacional();
            SalarioMinimoesperado();
            PIBNOMINAL();
            PIBReal();
            PoderDeCompraDoConsumidor();
            CalculoInflacaoAgregadaEDeflacaoAgregada();
            MenosconsumoTodosEstatalA();//Aqui esta a subtracao do consumo,ou seja ele tira os recursos dos pontos de saude, educacao, ferro etc... e subtrai do consumo da cesta de bens e servi�os
            CorrigindoSalarioMinimoZero();
            MilagreEconomico();
            TAXAdeDESEMPREGO();
            DemandaAgregada();

            //SatisfacaoDeEmpresas();//Aqui � decidido protestos das empresas.
            AtualizadordeTotais();

            //Aqui � definido a taxa de imposto e o pr�ximo turno
            DemandaAgregada();

            turno = turno + 1;
            label5.Text = turno.ToString();


        }
        private void button1_Click(object sender, EventArgs e)
        {
            DinheiroTotal += 500;

            label1.Text = DinheiroTotal.ToString();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dinheiroDoGoverno = DinheiroTotal - dinheiroDosCidadaos;

            label2.Text = dinheiroDoGoverno.ToString();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {


        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            dinheiroDosCidadaos = DinheiroTotal - dinheiroDoGoverno;

            label4.Text = dinheiroDosCidadaos.ToString();
        }

        private void Taxa_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) {}



        private void button5_Click(object sender, EventArgs e)
        {


            if (TaxaSelic.Text == "")
            {
                TaxaSelic.Text = "0";
            }
            int taxaselic = int.Parse(TaxaSelic.Text);
            if (taxaselic > 15)
            {
                MessageBox.Show("Digite uma taxa selic que seja igual ou menor que 15%");
                return;
            }

            if (Taxa.Text == "")
            {
                Taxa.Text = "0";
            }
            int imposto = int.Parse(Taxa.Text);
            if (imposto > 30)
            {
                MessageBox.Show("Digite uma taxa de imposto que seja igual ou menor que 30%");
                return;
            }

            if (TaxaEducacao.Text == "")
            {
                TaxaEducacao.Text = "0";
            }

            if (TaxaSaude.Text == "")
            {
                TaxaSaude.Text = "0";
            }


            if (TaxaFerro.Text == "")
            {
                TaxaFerro.Text = "0";
            }


            if (TaxaCombustivel.Text == "")
            {
                TaxaCombustivel.Text = "0";
            }


            if (TaxaAgricultura.Text == "")
            {
                TaxaAgricultura.Text = "0";
            }
            double taxaeducacao = double.Parse(TaxaEducacao.Text);
            double taxasaude = double.Parse(TaxaSaude.Text);
            double taxaagricultura = double.Parse(TaxaAgricultura.Text);
            double taxaferro = double.Parse(TaxaFerro.Text);
            double taxacombustivel = double.Parse(TaxaCombustivel.Text);

            if (taxaeducacao > 50)
            {
                MessageBox.Show("Digite uma taxa de imposto igual ou menor que 50% para o setor da educa��o.");
                return;
            }

            if (taxasaude > 50)
            {
                MessageBox.Show("Digite uma taxa de imposto igual ou menor que 50% para o setor da saude.");
                return;
            }

            if (taxaagricultura > 50)
            {
                MessageBox.Show("Digite uma taxa de imposto igual ou menor que 50% para o setor da agricultura.");
                return;
            }

            if (taxaferro > 50)
            {
                MessageBox.Show("Digite uma taxa de imposto igual ou menor que 50% para o setor do Ferro.");
                return;
            }

            if (taxacombustivel > 50)
            {
                MessageBox.Show("Digite uma taxa de imposto igual ou menor que 50% para o setor de Combust�vel.");
                return;
            }


            //Aqui � calculado a quantia min�ma de dinheiro necess�ria em circula��o e a quantia de dinheiro por pessoa
            int N = int.Parse(Povo.Text);
            N += Nascimentos();
            Povo.Text = N.ToString();
            int Minimo = N * 100;
            INDF.Text = Minimo.ToString();
            int P = dinheiroDosCidadaos / N;
            QDP.Text = P.ToString();

            //Aqui � calculado a infla��o e defla��o de moeda
            int IN1;
            if (P < 100) { IN1 = 0; } else { IN1 = P - 100; }
            IN.Text = IN1.ToString() + "%";
            int DF1;
            if (P < 100) { DF1 = 100 - P; } else { DF1 = 0; };
            DF.Text = DF1.ToString() + "%";
            InflacaoDeMoeda = IN1;
            DeflacaoDeMoeda = DF1;

            int populacaocommoradia = (int.Parse(label480.Text) * 5) + (int.Parse(labelpredio.Text) * 13);
            int populacaosemresidencia = int.Parse(Povo.Text) - populacaocommoradia;
            if (populacaosemresidencia < 1) { labelPopulacaoSemResidencia.Text = "0"; }
            labelPopulacaoSemResidencia.Text = populacaosemresidencia.ToString();
            PovoSemResidencia = int.Parse(labelPopulacaoSemResidencia.Text);
            labelPopulacaoSemResidencia.Text = populacaosemresidencia.ToString();


            QuantidadedeHospitais = int.Parse(TotalHospitais.Text);
            int populacaoComAcessoaHospital = int.Parse(TotalHospitais.Text) * 60;
            int populacaoSemAcessoaHospital = int.Parse(Povo.Text) - populacaoComAcessoaHospital;
            PopulacaoSemAcessoHospital.Text = populacaoSemAcessoaHospital.ToString();

            int PovoComComida = int.Parse(TotalFazendas.Text) * 50;
            int PovoSemComida = int.Parse(Povo.Text) - PovoComComida;
            PovoComFome.Text = PovoSemComida.ToString();

            int PovoComEnergia = int.Parse(TotalCentrosdeEnergia.Text) * 40;
            int PovosemEnergia = int.Parse(Povo.Text) - PovoComEnergia;
            PovoSemEnergia.Text = PovosemEnergia.ToString();

            int PovoComSaneamento = int.Parse(TotalReservatoriosAgua.Text) * 40;
            int PovosemSaneamento = int.Parse(Povo.Text) - PovoComSaneamento;
            PovoSemSaneamento.Text = PovosemSaneamento.ToString();

            //Form3 form3 = new Form3(this, TotalCentrosdeEnergia.Text, TotalFazendas.Text, TotalHospitais.Text, TotalEscolas.Text, Povo.Text);
            // form3.Show();

            int precovendatitulos = dinheiroDosCidadaos / 100;
            int precocompratitulos = dinheiroDosCidadaos / 80;
            PrecoVendaTitulos.Text = precovendatitulos.ToString();
            PrecoCompraTitulos.Text = precocompratitulos.ToString();




            MaisCreditoNacional();
            IndiceAleatorioDeEdfificiosPrivados();
            MetodoBUGhospital();
            BUGFazendaPrivada();
            MetodoBUGInstituicaoDeEnsinoPrivada();






            int creditonacional = int.Parse(TotalCredito.Text);
            if (creditonacional > dinheiroDosCidadaos)
            {
                TotalCredito.Text = dinheiroDosCidadaos.ToString();
            }




            int povaodesempregado = int.Parse(PopulacaoDesempregada.Text);
            if (povaodesempregado < 0)
            {
                int Soma = int.Parse(PopulacaoEmpregada.Text);
                Soma = 0;
                PopulacaoEmpregada.Text = Soma.ToString();
                int Soma1 = int.Parse(PopulacaoEmpregada.Text);
                int Soma2 = Soma1 + int.Parse(Povo.Text);
                PopulacaoEmpregada.Text = Soma2.ToString();
            }
            else
            {
                int Subtrair = int.Parse(Povo.Text) - int.Parse(PopulacaoDesempregada.Text);
                PopulacaoEmpregada.Text = Subtrair.ToString();
            }


            AtualizadorRecursosEducacaoPrivado();//Aqui como nos outros abaixo est�o os atualizadores que acrescentam recursos que foram produzidos pelo pa�s.
            AtualizadorRecursosEducacaoEstatal();
            AtualizadorRecursosSaudeEstatal();
            AtualizadorRecursosSaudePrivada();
            AtualizadorRecursosAlimentosEstatal();
            AtualizadorRecursosAlimentosPrivado();
            AtualizadorRecursosCombustivelPrivado();
            AtualizadorRecursosCombustivelEstatal();
            AtualizadorRecursosFerroEstatal();
            AtualizadorRecursosFerroPrivado();



            CalculoInflacaoDeCustos();
            CalculoInflacaoDeCustos();
            deflacaoDeCusto();
            SalarioMinimoMediaNacional();
            SalarioMinimoesperado();
            PIBNOMINAL();
            PIBReal();
            PoderDeCompraDoConsumidor();
            CalculoInflacaoAgregadaEDeflacaoAgregada();
            MenosconsumoTodosEstatalA();//Aqui esta a subtracao do consumo,ou seja ele tira os recursos dos pontos de saude, educacao, ferro etc... e subtrai do consumo da cesta de bens e servi�os
            CorrigindoSalarioMinimoZero();
            Recessao();
            ProtestoDeEmpresas();
            MilagreEconomico();
            //SatisfacaoDeEmpresas();//Aqui � decidido protestos das empresas.
            CorrigirProblemaDeEmpregadosComNumeroNegativo();
            TAXAdeDESEMPREGO();
            DemandaAgregada();
            ConsumodoPovo();


            AtualizadordeTotais();

            //Aqui � definido a taxa de imposto e o pr�ximo turno
            if (dinheiroDosCidadaos > dinheiroDoGoverno)
            {
                SetorEstatalDinheiroMovimentado();

                CobrarImpostoEducacao();
                CobrarImpostoSaude();
                CobrarImpostoFerro();
                CobrarImpostoCombustivel();
                CobrarImpostoAgricultura();
                CobrarImpostos(imposto);
            }
            else
            {
                MessageBox.Show("N�o foi poss�vel cobrar os impostos no turno anterior pois o dinheiro dos cidadaos � menor que o dinheiro do governo.");

            }

            turno = turno + 1;
            label5.Text = turno.ToString();

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void QDP_Click(object sender, EventArgs e)
        {

        }

        private void label48_Click(object sender, EventArgs e)
        {

        }

        private void ELIMINAR_Click(object sender, EventArgs e)
        {

            if (dinheiroDoGoverno < 1) { DinheiroTotal = DinheiroTotal + 0; return; }
            int DinheiroTotal1 = DinheiroTotal - 500;
            dinheiroDoGoverno = DinheiroTotal1 - dinheiroDosCidadaos;

            label2.Text = dinheiroDoGoverno.ToString();
            DinheiroTotal = dinheiroDoGoverno + dinheiroDosCidadaos;
            label1.Text = DinheiroTotal.ToString();
            if (dinheiroDoGoverno < 0) { dinheiroDoGoverno = 0; };
            label2.Text = dinheiroDoGoverno.ToString();
        }
        private void Administra��o_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(this, TotalHospitais.Text, TotalIndustriaCombustivel.Text, TotalTecnicoCombustivel.Text, TotalIndustriaFerro.Text, TotalMineradoresFerro.Text, TotalDelegacias.Text, EspacoDisponivelPoliciais.Text, EspacoDisponivelSoldados.Text, TotalQuarteis.Text, TotalReservatoriosAgua.Text, TotalEncanadores.Text, TotalCentrosdeEnergia.Text, TotalEletrecistas.Text, TotalFazendas.Text, TotalAgricultores.Text, label480.Text, labelpredio.Text, TerrasOcupadas.Text, TerritoriosPais.Text, TotalEscolas.Text, Povo.Text, TotalProfessores.Text, PopulacaoDesempregada.Text, TotalMedicos.Text);
            form2.Show();
        }

        private void label480_Click(object sender, EventArgs e)
        {

        }

        private void labelpredio_Click(object sender, EventArgs e)
        {

        }

        private void AcessarIndice_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(this, TotalReservatoriosAgua.Text, TotalCentrosdeEnergia.Text, TotaldeFazendas.Text, TotaldeHospitais.Text, TotaldeEscolas.Text, Povo.Text);
            form3.Show();
        }

        private void TerrasOcupadas_Click(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void CreditoNacional_TextChanged(object sender, EventArgs e)
        {

        }

        private void MaisCredito_Click(object sender, EventArgs e)
        {
            int creditonacional = int.Parse(CreditoNacional.Text);
            int dinheirocidadaos = int.Parse(label4.Text);
            int creditototal = int.Parse(TotalCredito.Text);

            if (dinheirocidadaos < creditototal)
            {
                dinheirocidadaos = creditototal;
            }

            if (CreditoNacional.Text == "")
            {
                return;
            }


            if (dinheiroDoGoverno > creditonacional)
            {
                int AtualizarCredito = creditonacional + int.Parse(TotalCredito.Text);
                TotalCredito.Text = AtualizarCredito.ToString();

                dinheiroDoGoverno = dinheiroDoGoverno - creditonacional;
                label2.Text = dinheiroDoGoverno.ToString();

                dinheiroDosCidadaos = dinheiroDosCidadaos + creditonacional;
                label4.Text = dinheiroDosCidadaos.ToString();

            }
            else
            {
                MessageBox.Show("Governo sem dinheiro suficiente"); return;
            }
        }

        private void TotalCredito_Click(object sender, EventArgs e)
        {

        }

        private void label56_Click(object sender, EventArgs e)
        {
        }

        private void MenosCredito_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {

        }

        private void BuyTitulos_Click(object sender, EventArgs e)
        {
            int titulopublico1 = int.Parse(TitulosPublicos.Text);
            if (titulopublico1 < 1)
            {
                return;
            }
            int PrecoParaComprarTituloPublico = dinheiroDosCidadaos / 80;
            int titulopublico = int.Parse(TitulosPublicos.Text) - 1;
            TitulosPublicos.Text = titulopublico.ToString();
            dinheiroDoGoverno = dinheiroDoGoverno - PrecoParaComprarTituloPublico;
            label2.Text = dinheiroDoGoverno.ToString();
            dinheiroDosCidadaos = dinheiroDosCidadaos + PrecoParaComprarTituloPublico;
            label4.Text = dinheiroDosCidadaos.ToString();
        }



        private void AdministracaoAvancada_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4(this);
            form4.Show();
        }

        private void TotalEletrecistas_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void MenosInstituicaoEnsinoPrivada_Click(object sender, EventArgs e)
        {
            int totalInstituicao = int.Parse(TotalEscolasPrivadas.Text);
            if (totalInstituicao < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int TotalescolasPrivadas = int.Parse(TotalEscolasPrivadas.Text) - 1;
            TotalEscolasPrivadas.Text = TotalescolasPrivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            int totalprofessores = int.Parse(TotalProfessoresPrivados.Text) - 5;
            TotalProfessoresPrivados.Text = totalprofessores.ToString();
            int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
            TotalEmpresarios.Text = totalEmpresarios.ToString();

            int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
            PopulacaoDesempregada.Text = povoDesempregado.ToString();
            int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 6;
            PopulacaoEmpregada.Text = povoEmpregado.ToString();

            int populacaosemeducacao = int.Parse(populacaoSemEducacao.Text) + 40;
            populacaoSemEducacao.Text = populacaosemeducacao.ToString();

        }


        //Aqui AquiAqui Aqui Aqui Aqui Aqui 








        private void MenosHospitalPrivado_Click(object sender, EventArgs e)
        {
            int totalHospital = int.Parse(TotalHospitaisPrivados.Text);
            if (totalHospital < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int TotalhospitaisPrivados = int.Parse(TotalHospitaisPrivados.Text) - 1;
            TotalHospitaisPrivados.Text = TotalhospitaisPrivados.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            int totalmedicos = int.Parse(TotalMedicosPrivados.Text) - 9;
            TotalMedicosPrivados.Text = totalmedicos.ToString();
            int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
            TotalEmpresarios.Text = totalEmpresarios.ToString();

            int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 10;
            PopulacaoDesempregada.Text = povoDesempregado.ToString();
            int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 10;
            PopulacaoEmpregada.Text = povoEmpregado.ToString();

            int populacaosemAcessoHospital = int.Parse(PopulacaoSemAcessoHospital.Text) + 60;
            PopulacaoSemAcessoHospital.Text = populacaosemAcessoHospital.ToString();
        }

        private void MenosFazendaPrivada_Click(object sender, EventArgs e)
        {
            int totalFazenda = int.Parse(TotalFazendasPrivadas.Text);
            if (totalFazenda < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int TotalFazendasprivadas = int.Parse(TotalFazendasPrivadas.Text) - 1;
            TotalFazendasPrivadas.Text = TotalFazendasprivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            int totalagricultores = int.Parse(TotalAgricultoresPrivados.Text) - 8;
            TotalAgricultoresPrivados.Text = totalagricultores.ToString();
            int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
            TotalEmpresarios.Text = totalEmpresarios.ToString();

            int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 9;
            PopulacaoDesempregada.Text = povoDesempregado.ToString();
            int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 9;
            PopulacaoEmpregada.Text = povoEmpregado.ToString();

            int populacaComRiscoDefome = int.Parse(PovoComFome.Text) + 50;
            PovoComFome.Text = populacaComRiscoDefome.ToString();
        }

        private void MenosIndustriaFerroPrivada_Click(object sender, EventArgs e)
        {
            int totalindustriaFerro = int.Parse(TotalIndustriaFerroPrivado.Text);
            if (totalindustriaFerro < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int Totalindustriaferroprivadas = int.Parse(TotalIndustriaFerroPrivado.Text) - 1;
            TotalIndustriaFerroPrivado.Text = Totalindustriaferroprivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            int totalMineradoresFerro = int.Parse(TotalMineradoresFerroPrivado.Text) - 5;
            TotalMineradoresFerroPrivado.Text = totalMineradoresFerro.ToString();
            int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
            TotalEmpresarios.Text = totalEmpresarios.ToString();

            int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
            PopulacaoDesempregada.Text = povoDesempregado.ToString();
            int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 6;
            PopulacaoEmpregada.Text = povoEmpregado.ToString();
        }

        private void MenosIndustriaCombustivelPrivada_Click(object sender, EventArgs e)
        {
            int totalindustriacombustivel = int.Parse(TotalIndustriaCombustivelPrivada.Text);
            if (totalindustriacombustivel < 1)
            {
                return;
            }

            int PopulacaoSemEmprego = int.Parse(PopulacaoDesempregada.Text);

            int terradisponivel = int.Parse(TerrasDisponiveis.Text);

            int Totalindustriacombustivelprivadas = int.Parse(TotalIndustriaCombustivelPrivada.Text) - 1;
            TotalIndustriaCombustivelPrivada.Text = Totalindustriacombustivelprivadas.ToString();



            int terrasdisponiveis = int.Parse(TerrasDisponiveis.Text) + 1;
            Terrasdisponiveis(terrasdisponiveis);

            int totalTecnicoCombustivel = int.Parse(TotalTecnicoCombustivelPrivado.Text) - 5;
            TotalTecnicoCombustivelPrivado.Text = totalTecnicoCombustivel.ToString();
            int totalEmpresarios = int.Parse(TotalEmpresarios.Text) - 1;
            TotalEmpresarios.Text = totalEmpresarios.ToString();

            int povoDesempregado = int.Parse(PopulacaoDesempregada.Text) + 6;
            PopulacaoDesempregada.Text = povoDesempregado.ToString();
            int povoEmpregado = int.Parse(PopulacaoEmpregada.Text) - 6;
            PopulacaoEmpregada.Text = povoEmpregado.ToString();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Tick(object sender, EventArgs e)
        {

        }

        private void MenosConsumoPrivadoEducacao_Click(object sender, EventArgs e)
        {
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(EducacaoPrivado.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosEducacao.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                EducacaoPrivado.Text = "0";
                ConsumoPontosEducacao.Text = ConsumoPontosEducacao.Text;
            }
            else
            {
                EducacaoPrivado.Text = PermitircirculacaoDoProduto.ToString();
                ConsumoPontosEducacao.Text = PermitircirculacaoDoProduto1.ToString();
            }
        }

        private void MenosConsumoPrivadoSaude_Click(object sender, EventArgs e)
        {
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(SaudePrivado.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosSaude.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                SaudePrivado.Text = "0";
                ConsumoPontosSaude.Text = ConsumoPontosSaude.Text;
            }
            else
            {
                SaudePrivado.Text = PermitircirculacaoDoProduto.ToString();
                ConsumoPontosSaude.Text = PermitircirculacaoDoProduto1.ToString();
            }
        }

        private void MenosConsumoEstatalEducacao_Click(object sender, EventArgs e)
        {
            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                MessageBox.Show("O dinheiro do governo � maior que o dos cidad�os, n�o � poss�vel vender mais recursos.");
                return;
            }
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(Educacao.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosEducacao.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                Educacao.Text = "0";
                ConsumoPontosEducacao.Text = ConsumoPontosEducacao.Text;
            }
            else
            {
                ConsumoPontosEducacao.Text = PermitircirculacaoDoProduto1.ToString();

                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalEscolas.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                decimal recursostotais = decimal.Parse(Educacao.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {


                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                    decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                    decimal arredondado = Math.Round(divisao);

                    decimal subtraindo = recursostotais - subtracaodoconsumo;
                    Educacao.Text = subtraindo.ToString();

                    decimal multiplicando = subtracaodoconsumo * arredondado;
                    decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                    label2.Text = somandodinheirogoverno.ToString();
                    dinheiroDoGoverno = int.Parse(label2.Text);

                    decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                    label4.Text = subtraindodinheirocidadaos.ToString();
                    dinheiroDosCidadaos = int.Parse(label4.Text);

                }


            }
        }

        private void SubtracaoConsumo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label59_Click(object sender, EventArgs e)
        {

        }

        private void TotalIndustriaFerro_Click(object sender, EventArgs e)
        {
        }

        private void label68_Click(object sender, EventArgs e)
        {
        }

        private void TotalEdificios_Click(object sender, EventArgs e)
        {
        }

        private void label39_Click(object sender, EventArgs e)
        {
        }

        private void TotalCentrosdeEnergia_Click(object sender, EventArgs e)
        {
        }

        private void TotalIndustriaCombustivel_Click(object sender, EventArgs e)
        {
        }

        private void label65_Click(object sender, EventArgs e)
        {
        }

        private void TotalResidencias_Click(object sender, EventArgs e)
        {
        }

        private void label32_Click(object sender, EventArgs e)
        {
        }

        private void TotalFazendas_Click(object sender, EventArgs e)
        {
        }

        private void label40_Click(object sender, EventArgs e)
        {
        }

        private void TotalReservatoriosAgua_Click(object sender, EventArgs e)
        {
        }

        private void label31_Click(object sender, EventArgs e)
        {
        }

        private void label16_Click(object sender, EventArgs e)
        {
        }

        private void label41_Click(object sender, EventArgs e)
        {
        }

        private void labelpredio_Click_1(object sender, EventArgs e)
        {
        }

        private void label30_Click(object sender, EventArgs e)
        {
        }

        private void label17_Click(object sender, EventArgs e)
        {
        }

        private void TotalBancosPrivados_Click(object sender, EventArgs e)
        {
        }

        private void TerritoriosPais_Click(object sender, EventArgs e)
        {
        }

        private void TotalIndustriaFerroPrivado_Click(object sender, EventArgs e)
        {
        }

        private void label18_Click(object sender, EventArgs e)
        {
        }

        private void label54_Click(object sender, EventArgs e)
        {
        }

        private void label19_Click(object sender, EventArgs e)
        {
        }

        private void TotalIndustriaCombustivelPrivada_Click(object sender, EventArgs e)
        {
        }

        private void label55_Click(object sender, EventArgs e)
        {
        }

        private void TerrasDisponiveis_Click(object sender, EventArgs e)
        {
        }

        private void TotaldeFazendas_Click(object sender, EventArgs e)
        {
        }

        private void EspacoDisponivelSoldados_Click(object sender, EventArgs e)
        {
        }

        private void label49_Click(object sender, EventArgs e)
        {
        }

        private void label20_Click(object sender, EventArgs e)
        {
        }

        private void TotaldeIndustriaCombustivel_Click(object sender, EventArgs e)
        {
        }

        private void TotalHospitais_Click(object sender, EventArgs e)
        {
        }

        private void TotalFazendasPrivadas_Click(object sender, EventArgs e)
        {
        }

        private void label26_Click(object sender, EventArgs e)
        {
        }

        private void TotalQuarteis_Click(object sender, EventArgs e)
        {
        }

        private void label22_Click(object sender, EventArgs e)
        {
        }

        private void TotaldeIndustriaFerro_Click(object sender, EventArgs e)
        {
        }

        private void EspacoDisponivelPoliciais_Click(object sender, EventArgs e)
        {
        }

        private void TotaldeHospitais_Click(object sender, EventArgs e)
        {
        }

        private void label25_Click(object sender, EventArgs e)
        {
        }

        private void TotalDelegacias_Click(object sender, EventArgs e)
        {
        }

        private void TotalHospitaisPrivados_Click(object sender, EventArgs e)
        {
        }

        private void label23_Click(object sender, EventArgs e)
        {
        }

        private void TotaldeEscolas_Click(object sender, EventArgs e)
        {
        }

        private void TotalEscolas_Click(object sender, EventArgs e)
        {
        }

        private void label24_Click(object sender, EventArgs e)
        {
        }

        private void TotalEscolasPrivadas_Click(object sender, EventArgs e)
        {
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }



        private void MnosConsumoSaudeEstatal_Click(object sender, EventArgs e)
        {
            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                MessageBox.Show("O dinheiro do governo � maior que o dos cidad�os, n�o � poss�vel vender mais recursos.");
                return;
            }
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(Saude.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosSaude.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                Saude.Text = "0";
                ConsumoPontosSaude.Text = ConsumoPontosSaude.Text;
            }
            else
            {
                ConsumoPontosSaude.Text = PermitircirculacaoDoProduto1.ToString();

                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalHospitais.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                decimal recursostotais = decimal.Parse(Saude.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {


                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                    decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                    decimal arredondado = Math.Round(divisao);

                    decimal subtraindo = recursostotais - subtracaodoconsumo;
                    Saude.Text = subtraindo.ToString();

                    decimal multiplicando = subtracaodoconsumo * arredondado;
                    decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                    label2.Text = somandodinheirogoverno.ToString();
                    dinheiroDoGoverno = int.Parse(label2.Text);


                    decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                    label4.Text = subtraindodinheirocidadaos.ToString();
                    dinheiroDosCidadaos = int.Parse(label4.Text);


                }
            }
        }

        private void MenosConsumoPrivadoAlimentos_Click(object sender, EventArgs e)
        {
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(AlimentoPrivado.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosAlimentos.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                AlimentoPrivado.Text = "0";
                ConsumoPontosAlimentos.Text = ConsumoPontosAlimentos.Text;
            }
            else
            {
                AlimentoPrivado.Text = PermitircirculacaoDoProduto.ToString();
                ConsumoPontosAlimentos.Text = PermitircirculacaoDoProduto1.ToString();
            }
        }

        private void MenosConsumoAlimentoEstatal_Click(object sender, EventArgs e)
        {
            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                MessageBox.Show("O dinheiro do governo � maior que o dos cidad�os, n�o � poss�vel vender mais recursos.");
                return;
            }
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(Alimento.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosAlimentos.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                Alimento.Text = "0";
                ConsumoPontosAlimentos.Text = ConsumoPontosAlimentos.Text;
            }
            else
            {
                ConsumoPontosAlimentos.Text = PermitircirculacaoDoProduto1.ToString();

                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalFazendas.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                decimal recursostotais = decimal.Parse(Alimento.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {


                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                    decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                    decimal arredondado = Math.Round(divisao);

                    decimal subtraindo = recursostotais - subtracaodoconsumo;
                    Alimento.Text = subtraindo.ToString();

                    decimal multiplicando = subtracaodoconsumo * arredondado;
                    decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                    label2.Text = somandodinheirogoverno.ToString();
                    dinheiroDoGoverno = int.Parse(label2.Text);


                    decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                    label4.Text = subtraindodinheirocidadaos.ToString();
                    dinheiroDosCidadaos = int.Parse(label4.Text);


                }
            }
        }
        private void MenosConsumoPrivadoCombustivel_Click(object sender, EventArgs e)
        {
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(CombustivelPrivado.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosCombustivel.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                CombustivelPrivado.Text = "0";
                ConsumoPontosCombustivel.Text = ConsumoPontosCombustivel.Text;
            }
            else
            {
                CombustivelPrivado.Text = PermitircirculacaoDoProduto.ToString();
                ConsumoPontosCombustivel.Text = PermitircirculacaoDoProduto1.ToString();

            }
        }



        private void MenosConsumoCombustivelEstatal_Click(object sender, EventArgs e)
        {
            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                MessageBox.Show("O dinheiro do governo � maior que o dos cidad�os, n�o � poss�vel vender mais recursos.");
                return;
            }
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(Combustivel.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosCombustivel.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                Combustivel.Text = "0";
                ConsumoPontosCombustivel.Text = ConsumoPontosCombustivel.Text;
            }
            else
            {
                ConsumoPontosCombustivel.Text = PermitircirculacaoDoProduto1.ToString();



                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalIndustriaCombustivel.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                decimal recursostotais = decimal.Parse(Combustivel.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {


                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                    decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                    decimal arredondado = Math.Round(divisao);

                    decimal subtraindo = recursostotais - subtracaodoconsumo;
                    Combustivel.Text = subtraindo.ToString();

                    decimal multiplicando = subtracaodoconsumo * arredondado;
                    decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                    label2.Text = somandodinheirogoverno.ToString();
                    dinheiroDoGoverno = int.Parse(label2.Text);


                    decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                    label4.Text = subtraindodinheirocidadaos.ToString();
                    dinheiroDosCidadaos = int.Parse(label4.Text);


                }
            }
        }

        private void MenosConsumoFerroPrivado_Click(object sender, EventArgs e)
        {
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(FerroPrivado.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosFerro.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                FerroPrivado.Text = "0";
                ConsumoPontosFerro.Text = ConsumoPontosFerro.Text;
            }
            else
            {
                FerroPrivado.Text = PermitircirculacaoDoProduto.ToString();
                ConsumoPontosFerro.Text = PermitircirculacaoDoProduto1.ToString();
            }
        }

        private void MenosConsumoFerroEstatal_Click(object sender, EventArgs e)
        {
            if (dinheiroDosCidadaos < dinheiroDoGoverno)
            {
                MessageBox.Show("O dinheiro do governo � maior que o dos cidad�os, n�o � poss�vel vender mais recursos.");
                return;
            }
            if (SubtracaoConsumo.Text == "")
            {
                return;
            }
            int subtracaodoconsumo = int.Parse(SubtracaoConsumo.Text);

            int PermitircirculacaoDoProduto = int.Parse(Ferro.Text) - subtracaodoconsumo;
            int PermitircirculacaoDoProduto1 = int.Parse(ConsumoPontosFerro.Text) - subtracaodoconsumo;
            if (PermitircirculacaoDoProduto < 0)
            {
                Ferro.Text = "0";
                ConsumoPontosFerro.Text = ConsumoPontosFerro.Text;
            }
            else
            {

                ConsumoPontosFerro.Text = PermitircirculacaoDoProduto1.ToString();

                decimal Demandaagregada = decimal.Parse(demandaagregada.Text);
                decimal total = decimal.Parse(TotalIndustriaFerro.Text);
                decimal totalEdificios = decimal.Parse(TotalEdificios.Text);
                decimal recursostotais = decimal.Parse(Ferro.Text);

                if (totalEdificios == 0)
                {
                    return;
                }
                else
                {


                    decimal Percentual = total / totalEdificios;
                    decimal Percentual1 = Percentual * 100;
                    decimal DinheiroQueOSetorMovimenta = (Percentual1 / 100) * Demandaagregada;

                    decimal divisao = DinheiroQueOSetorMovimenta / recursostotais;
                    decimal arredondado = Math.Round(divisao);

                    decimal subtraindo = recursostotais - subtracaodoconsumo;
                    Ferro.Text = subtraindo.ToString();

                    decimal multiplicando = subtracaodoconsumo * arredondado;
                    decimal somandodinheirogoverno = dinheiroDoGoverno + multiplicando;
                    label2.Text = somandodinheirogoverno.ToString();
                    dinheiroDoGoverno = int.Parse(label2.Text);

                    decimal subtraindodinheirocidadaos = dinheiroDosCidadaos - multiplicando;
                    label4.Text = subtraindodinheirocidadaos.ToString();
                    dinheiroDosCidadaos = int.Parse(label4.Text);
                }
            }
        }

        private void label102_Click(object sender, EventArgs e)
        {

        }

        private void label109_Click(object sender, EventArgs e)
        {

        }

        private void DEFLACAOAGREGADAPORCENTAGEM_Click(object sender, EventArgs e)
        {
        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void label130_Click(object sender, EventArgs e)
        {

        }

        private void MenosTodosEstatal_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}