﻿namespace Derick
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            SalarioMinimoprofessores = new TextBox();
            AtualizarInformacoes = new Button();
            SalarioMinimoagricultores = new TextBox();
            label2 = new Label();
            SalarioMinimomedicos = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            SalarioMinimomedicosEstatal = new TextBox();
            label6 = new Label();
            SalarioMinimoagricultoresEstatal = new TextBox();
            label7 = new Label();
            SalarioMinimoprofessoresEstatal = new TextBox();
            label8 = new Label();
            SalarioMinimoeletrecistasEstatal = new TextBox();
            label9 = new Label();
            SalarioMinimosoldadosEstatal = new TextBox();
            label10 = new Label();
            SalarioMinimopoliciaisEstatal = new TextBox();
            label11 = new Label();
            SalarioMinimoencanadoresEstatal = new TextBox();
            label12 = new Label();
            SalarioMinimoTecnicoCombustivel = new TextBox();
            label13 = new Label();
            SalarioMinimoMineradorFerro = new TextBox();
            label14 = new Label();
            SalarioMinimoTecnicoCombustivelEstatal = new TextBox();
            label15 = new Label();
            SalarioMinimoMineradorFerroEstatal = new TextBox();
            label16 = new Label();
            SalarioEsperado = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 50);
            label1.Name = "label1";
            label1.Size = new Size(153, 15);
            label1.TabIndex = 0;
            label1.Text = "Salário Minímo Professores:";
            // 
            // SalarioMinimoprofessores
            // 
            SalarioMinimoprofessores.Location = new Point(228, 45);
            SalarioMinimoprofessores.Name = "SalarioMinimoprofessores";
            SalarioMinimoprofessores.Size = new Size(59, 23);
            SalarioMinimoprofessores.TabIndex = 1;
            // 
            // AtualizarInformacoes
            // 
            AtualizarInformacoes.Location = new Point(0, 1);
            AtualizarInformacoes.Name = "AtualizarInformacoes";
            AtualizarInformacoes.Size = new Size(176, 23);
            AtualizarInformacoes.TabIndex = 2;
            AtualizarInformacoes.Text = "ATUALIZAR INFORMAÇÕES";
            AtualizarInformacoes.UseVisualStyleBackColor = true;
            AtualizarInformacoes.Click += AtualizarInformacoes_Click;
            // 
            // SalarioMinimoagricultores
            // 
            SalarioMinimoagricultores.Location = new Point(228, 74);
            SalarioMinimoagricultores.Name = "SalarioMinimoagricultores";
            SalarioMinimoagricultores.Size = new Size(59, 23);
            SalarioMinimoagricultores.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 79);
            label2.Name = "label2";
            label2.Size = new Size(157, 15);
            label2.TabIndex = 3;
            label2.Text = "Salário Minímo Agricultores:";
            // 
            // SalarioMinimomedicos
            // 
            SalarioMinimomedicos.Location = new Point(228, 103);
            SalarioMinimomedicos.Name = "SalarioMinimomedicos";
            SalarioMinimomedicos.Size = new Size(59, 23);
            SalarioMinimomedicos.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 108);
            label3.Name = "label3";
            label3.Size = new Size(138, 15);
            label3.TabIndex = 5;
            label3.Text = "Salário Minímo Medicos:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(81, 27);
            label4.Name = "label4";
            label4.Size = new Size(84, 15);
            label4.TabIndex = 7;
            label4.Text = "REDE PRIVADA";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(366, 27);
            label5.Name = "label5";
            label5.Size = new Size(84, 15);
            label5.TabIndex = 8;
            label5.Text = "REDE PÚBLICA";
            // 
            // SalarioMinimomedicosEstatal
            // 
            SalarioMinimomedicosEstatal.Location = new Point(511, 105);
            SalarioMinimomedicosEstatal.Name = "SalarioMinimomedicosEstatal";
            SalarioMinimomedicosEstatal.Size = new Size(59, 23);
            SalarioMinimomedicosEstatal.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(293, 108);
            label6.Name = "label6";
            label6.Size = new Size(138, 15);
            label6.TabIndex = 13;
            label6.Text = "Salário Minímo Medicos:";
            // 
            // SalarioMinimoagricultoresEstatal
            // 
            SalarioMinimoagricultoresEstatal.Location = new Point(511, 76);
            SalarioMinimoagricultoresEstatal.Name = "SalarioMinimoagricultoresEstatal";
            SalarioMinimoagricultoresEstatal.Size = new Size(59, 23);
            SalarioMinimoagricultoresEstatal.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(293, 79);
            label7.Name = "label7";
            label7.Size = new Size(157, 15);
            label7.TabIndex = 11;
            label7.Text = "Salário Minímo Agricultores:";
            // 
            // SalarioMinimoprofessoresEstatal
            // 
            SalarioMinimoprofessoresEstatal.Location = new Point(511, 47);
            SalarioMinimoprofessoresEstatal.Name = "SalarioMinimoprofessoresEstatal";
            SalarioMinimoprofessoresEstatal.Size = new Size(59, 23);
            SalarioMinimoprofessoresEstatal.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(293, 50);
            label8.Name = "label8";
            label8.Size = new Size(153, 15);
            label8.TabIndex = 9;
            label8.Text = "Salário Minímo Professores:";
            // 
            // SalarioMinimoeletrecistasEstatal
            // 
            SalarioMinimoeletrecistasEstatal.Location = new Point(511, 189);
            SalarioMinimoeletrecistasEstatal.Name = "SalarioMinimoeletrecistasEstatal";
            SalarioMinimoeletrecistasEstatal.Size = new Size(59, 23);
            SalarioMinimoeletrecistasEstatal.TabIndex = 20;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(293, 192);
            label9.Name = "label9";
            label9.Size = new Size(151, 15);
            label9.TabIndex = 19;
            label9.Text = "Salário Minímo Eletrecistas:";
            // 
            // SalarioMinimosoldadosEstatal
            // 
            SalarioMinimosoldadosEstatal.Location = new Point(511, 160);
            SalarioMinimosoldadosEstatal.Name = "SalarioMinimosoldadosEstatal";
            SalarioMinimosoldadosEstatal.Size = new Size(59, 23);
            SalarioMinimosoldadosEstatal.TabIndex = 18;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(293, 163);
            label10.Name = "label10";
            label10.Size = new Size(141, 15);
            label10.TabIndex = 17;
            label10.Text = "Salário Minímo Soldados:";
            // 
            // SalarioMinimopoliciaisEstatal
            // 
            SalarioMinimopoliciaisEstatal.Location = new Point(511, 131);
            SalarioMinimopoliciaisEstatal.Name = "SalarioMinimopoliciaisEstatal";
            SalarioMinimopoliciaisEstatal.Size = new Size(59, 23);
            SalarioMinimopoliciaisEstatal.TabIndex = 16;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(293, 134);
            label11.Name = "label11";
            label11.Size = new Size(136, 15);
            label11.TabIndex = 15;
            label11.Text = "Salário Minímo Policiais:";
            // 
            // SalarioMinimoencanadoresEstatal
            // 
            SalarioMinimoencanadoresEstatal.Location = new Point(511, 218);
            SalarioMinimoencanadoresEstatal.Name = "SalarioMinimoencanadoresEstatal";
            SalarioMinimoencanadoresEstatal.Size = new Size(59, 23);
            SalarioMinimoencanadoresEstatal.TabIndex = 22;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(293, 221);
            label12.Name = "label12";
            label12.Size = new Size(160, 15);
            label12.TabIndex = 21;
            label12.Text = "Salário Minímo Encanadores:";
            // 
            // SalarioMinimoTecnicoCombustivel
            // 
            SalarioMinimoTecnicoCombustivel.Location = new Point(228, 163);
            SalarioMinimoTecnicoCombustivel.Name = "SalarioMinimoTecnicoCombustivel";
            SalarioMinimoTecnicoCombustivel.Size = new Size(59, 23);
            SalarioMinimoTecnicoCombustivel.TabIndex = 26;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(12, 168);
            label13.Name = "label13";
            label13.Size = new Size(219, 15);
            label13.TabIndex = 25;
            label13.Text = "Salário Minímo Técnico de Combustivel:";
            // 
            // SalarioMinimoMineradorFerro
            // 
            SalarioMinimoMineradorFerro.Location = new Point(228, 134);
            SalarioMinimoMineradorFerro.Name = "SalarioMinimoMineradorFerro";
            SalarioMinimoMineradorFerro.Size = new Size(59, 23);
            SalarioMinimoMineradorFerro.TabIndex = 24;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(12, 139);
            label14.Name = "label14";
            label14.Size = new Size(194, 15);
            label14.TabIndex = 23;
            label14.Text = "Salário Minímo Minerador de Ferro:";
            // 
            // SalarioMinimoTecnicoCombustivelEstatal
            // 
            SalarioMinimoTecnicoCombustivelEstatal.Location = new Point(511, 275);
            SalarioMinimoTecnicoCombustivelEstatal.Name = "SalarioMinimoTecnicoCombustivelEstatal";
            SalarioMinimoTecnicoCombustivelEstatal.Size = new Size(59, 23);
            SalarioMinimoTecnicoCombustivelEstatal.TabIndex = 30;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(295, 280);
            label15.Name = "label15";
            label15.Size = new Size(219, 15);
            label15.TabIndex = 29;
            label15.Text = "Salário Minímo Técnico de Combustivel:";
            // 
            // SalarioMinimoMineradorFerroEstatal
            // 
            SalarioMinimoMineradorFerroEstatal.Location = new Point(511, 246);
            SalarioMinimoMineradorFerroEstatal.Name = "SalarioMinimoMineradorFerroEstatal";
            SalarioMinimoMineradorFerroEstatal.Size = new Size(59, 23);
            SalarioMinimoMineradorFerroEstatal.TabIndex = 28;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(295, 251);
            label16.Name = "label16";
            label16.Size = new Size(194, 15);
            label16.TabIndex = 27;
            label16.Text = "Salário Minímo Minerador de Ferro:";
            // 
            // SalarioEsperado
            // 
            SalarioEsperado.Location = new Point(182, 1);
            SalarioEsperado.Name = "SalarioEsperado";
            SalarioEsperado.Size = new Size(157, 23);
            SalarioEsperado.TabIndex = 31;
            SalarioEsperado.Text = "Salario Minímo Esperado";
            SalarioEsperado.UseVisualStyleBackColor = true;
            SalarioEsperado.Click += SalarioEsperado_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(SalarioEsperado);
            Controls.Add(SalarioMinimoTecnicoCombustivelEstatal);
            Controls.Add(label15);
            Controls.Add(SalarioMinimoMineradorFerroEstatal);
            Controls.Add(label16);
            Controls.Add(SalarioMinimoTecnicoCombustivel);
            Controls.Add(label13);
            Controls.Add(SalarioMinimoMineradorFerro);
            Controls.Add(label14);
            Controls.Add(SalarioMinimoencanadoresEstatal);
            Controls.Add(label12);
            Controls.Add(SalarioMinimoeletrecistasEstatal);
            Controls.Add(label9);
            Controls.Add(SalarioMinimosoldadosEstatal);
            Controls.Add(label10);
            Controls.Add(SalarioMinimopoliciaisEstatal);
            Controls.Add(label11);
            Controls.Add(SalarioMinimomedicosEstatal);
            Controls.Add(label6);
            Controls.Add(SalarioMinimoagricultoresEstatal);
            Controls.Add(label7);
            Controls.Add(SalarioMinimoprofessoresEstatal);
            Controls.Add(label8);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(SalarioMinimomedicos);
            Controls.Add(label3);
            Controls.Add(SalarioMinimoagricultores);
            Controls.Add(label2);
            Controls.Add(AtualizarInformacoes);
            Controls.Add(SalarioMinimoprofessores);
            Controls.Add(label1);
            Name = "Form4";
            Text = "Form4";
            Load += Form4_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox SalarioMinimoprofessores;
        private Button AtualizarInformacoes;
        private TextBox SalarioMinimoagricultores;
        private Label label2;
        private TextBox SalarioMinimomedicos;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox SalarioMinimomedicosEstatal;
        private Label label6;
        private TextBox SalarioMinimoagricultoresEstatal;
        private Label label7;
        private TextBox SalarioMinimoprofessoresEstatal;
        private Label label8;
        private TextBox SalarioMinimoeletrecistasEstatal;
        private Label label9;
        private TextBox SalarioMinimosoldadosEstatal;
        private Label label10;
        private TextBox SalarioMinimopoliciaisEstatal;
        private Label label11;
        private TextBox SalarioMinimoencanadoresEstatal;
        private Label label12;
        private TextBox SalarioMinimoTecnicoCombustivel;
        private Label label13;
        private TextBox SalarioMinimoMineradorFerro;
        private Label label14;
        private TextBox SalarioMinimoTecnicoCombustivelEstatal;
        private Label label15;
        private TextBox SalarioMinimoMineradorFerroEstatal;
        private Label label16;
        private Button SalarioEsperado;
    }
}