﻿namespace Derick
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label12 = new Label();
            EscolasNecessarias = new Label();
            HospitaisNecessarios = new Label();
            label4 = new Label();
            FazendasNecessarias = new Label();
            CentrosEnergiaNecessarios = new Label();
            ReservatorioAguanecessario = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 56);
            label1.Name = "label1";
            label1.Size = new Size(245, 15);
            label1.TabIndex = 0;
            label1.Text = "Quantia necessária de Instituições de Ensino: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Size = new Size(0, 15);
            label2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(333, 0);
            label3.Name = "label3";
            label3.Size = new Size(0, 15);
            label3.TabIndex = 2;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(0, 116);
            label5.Name = "label5";
            label5.Size = new Size(161, 15);
            label5.TabIndex = 4;
            label5.Text = "Quantia necessária Hospitais:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(0, 71);
            label6.Name = "label6";
            label6.Size = new Size(192, 15);
            label6.TabIndex = 5;
            label6.Text = "Quantia de necessária de Fazendas:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(0, 101);
            label7.Name = "label7";
            label7.Size = new Size(309, 15);
            label7.TabIndex = 6;
            label7.Text = "Quantia necessária de Centros de Distribuição de Energia:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(0, 86);
            label8.Name = "label8";
            label8.Size = new Size(245, 15);
            label8.TabIndex = 7;
            label8.Text = "Quantia necessária de Reservatórios de Água:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(0, 31);
            label12.Name = "label12";
            label12.Size = new Size(307, 15);
            label12.TabIndex = 11;
            label12.Text = "INDÍCE PARA UM MELHOR DESENVOLVIMENTO DO PAÍS:";
            // 
            // EscolasNecessarias
            // 
            EscolasNecessarias.AutoSize = true;
            EscolasNecessarias.Location = new Point(251, 56);
            EscolasNecessarias.Name = "EscolasNecessarias";
            EscolasNecessarias.Size = new Size(13, 15);
            EscolasNecessarias.TabIndex = 12;
            EscolasNecessarias.Text = "0";
            // 
            // HospitaisNecessarios
            // 
            HospitaisNecessarios.AutoSize = true;
            HospitaisNecessarios.Location = new Point(165, 116);
            HospitaisNecessarios.Name = "HospitaisNecessarios";
            HospitaisNecessarios.Size = new Size(13, 15);
            HospitaisNecessarios.TabIndex = 13;
            HospitaisNecessarios.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(198, 71);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 14;
            // 
            // FazendasNecessarias
            // 
            FazendasNecessarias.AutoSize = true;
            FazendasNecessarias.Location = new Point(198, 71);
            FazendasNecessarias.Name = "FazendasNecessarias";
            FazendasNecessarias.Size = new Size(13, 15);
            FazendasNecessarias.TabIndex = 15;
            FazendasNecessarias.Text = "0";
            // 
            // CentrosEnergiaNecessarios
            // 
            CentrosEnergiaNecessarios.AutoSize = true;
            CentrosEnergiaNecessarios.Location = new Point(315, 101);
            CentrosEnergiaNecessarios.Name = "CentrosEnergiaNecessarios";
            CentrosEnergiaNecessarios.Size = new Size(13, 15);
            CentrosEnergiaNecessarios.TabIndex = 16;
            CentrosEnergiaNecessarios.Text = "0";
            // 
            // ReservatorioAguanecessario
            // 
            ReservatorioAguanecessario.AutoSize = true;
            ReservatorioAguanecessario.Location = new Point(251, 86);
            ReservatorioAguanecessario.Name = "ReservatorioAguanecessario";
            ReservatorioAguanecessario.Size = new Size(13, 15);
            ReservatorioAguanecessario.TabIndex = 17;
            ReservatorioAguanecessario.Text = "0";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(334, 171);
            Controls.Add(ReservatorioAguanecessario);
            Controls.Add(CentrosEnergiaNecessarios);
            Controls.Add(FazendasNecessarias);
            Controls.Add(label4);
            Controls.Add(HospitaisNecessarios);
            Controls.Add(EscolasNecessarias);
            Controls.Add(label12);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label12;
        private Label EscolasNecessarias;
        private Label HospitaisNecessarios;
        private Label label4;
        private Label FazendasNecessarias;
        private Label CentrosEnergiaNecessarios;
        private Label ReservatorioAguanecessario;
    }
}