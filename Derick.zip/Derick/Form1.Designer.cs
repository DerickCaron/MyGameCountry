﻿namespace Derick
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            label1 = new Label();
            button4 = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button3 = new Button();
            Taxa = new TextBox();
            button5 = new Button();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            label26 = new Label();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            label30 = new Label();
            label31 = new Label();
            label32 = new Label();
            label33 = new Label();
            label34 = new Label();
            label35 = new Label();
            label36 = new Label();
            label37 = new Label();
            label38 = new Label();
            label39 = new Label();
            label40 = new Label();
            label41 = new Label();
            label42 = new Label();
            Povo = new Label();
            label44 = new Label();
            INDF = new Label();
            label46 = new Label();
            label47 = new Label();
            IN = new Label();
            DF = new Label();
            label43 = new Label();
            QDP = new Label();
            label45 = new Label();
            ELIMINAR = new Button();
            Administração = new Button();
            label480 = new Label();
            label48 = new Label();
            labelPopulacaoSemResidencia = new Label();
            fileSystemWatcher1 = new FileSystemWatcher();
            TerrasDisponiveis = new Label();
            label49 = new Label();
            TerrasOcupadas = new Label();
            PopulacaoDesempregada = new Label();
            AcessarIndice = new Button();
            label50 = new Label();
            TotalEscolas = new Label();
            populacaoSemEducacao = new Label();
            TotalProfessores = new Label();
            label21 = new Label();
            PopulacaoEmpregada = new Label();
            TotalHospitais = new Label();
            PopulacaoSemAcessoHospital = new Label();
            TotalMedicos = new Label();
            TerritoriosPais = new Label();
            labelpredio = new Label();
            TotalFazendas = new Label();
            TotalAgricultores = new Label();
            label51 = new Label();
            PovoComFome = new Label();
            TotalCentrosdeEnergia = new Label();
            TotalEletrecistas = new Label();
            label53 = new Label();
            PovoSemEnergia = new Label();
            label52 = new Label();
            TotalEncanadores = new Label();
            TotalReservatoriosAgua = new Label();
            PovoSemSaneamento = new Label();
            label54 = new Label();
            label55 = new Label();
            EspacoDisponivelSoldados = new Label();
            TotalSoldados = new Label();
            TotalQuarteis = new Label();
            EspacoDisponivelPoliciais = new Label();
            TotalPoliciais = new Label();
            TotalDelegacias = new Label();
            TotalEscolasPrivadas = new Label();
            TotaldeEscolas = new Label();
            TotalHospitaisPrivados = new Label();
            TotaldeHospitais = new Label();
            TotalFazendasPrivadas = new Label();
            TotaldeFazendas = new Label();
            CreditoNacional = new TextBox();
            label56 = new Label();
            TotalCredito = new Label();
            MaisCredito = new Button();
            label57 = new Label();
            TotalEmpresarios = new Label();
            TotalProfessoresPrivados = new Label();
            textBox1 = new TextBox();
            TaxaSelic = new TextBox();
            label58 = new Label();
            label59 = new Label();
            TotalBancosPrivados = new Label();
            EmprestimosPorBanco = new Label();
            label60 = new Label();
            TitulosPublicos = new Label();
            TitulosMoney = new Label();
            BuyTitulos = new Button();
            label61 = new Label();
            label62 = new Label();
            PrecoVendaTitulos = new Label();
            PrecoCompraTitulos = new Label();
            label64 = new Label();
            SalarioMinimoEsperado = new Label();
            TotalMedicosPrivados = new Label();
            TotalAgricultoresPrivados = new Label();
            AdministracaoAvancada = new Button();
            label65 = new Label();
            TotalIndustriaFerro = new Label();
            label66 = new Label();
            TotalMineradoresFerro = new Label();
            label67 = new Label();
            TotalTecnicoCombustivel = new Label();
            label68 = new Label();
            TotalIndustriaCombustivel = new Label();
            TotalMineradoresFerroPrivado = new Label();
            TotalTecnicoCombustivelPrivado = new Label();
            TotalIndustriaFerroPrivado = new Label();
            TotalIndustriaCombustivelPrivada = new Label();
            TotaldeTecnicoCombustivel = new Label();
            TotaldeIndustriaCombustivel = new Label();
            TotaldeIndustriaFerro = new Label();
            MenosInstituicaoEnsinoPrivada = new Button();
            MenosIndustriaCombustivelPrivada = new Button();
            MenosIndustriaFerroPrivada = new Button();
            MenosFazendaPrivada = new Button();
            MenosHospitalPrivado = new Button();
            TotaldeMineradoresFerro = new Label();
            TotaldeMedicos = new Label();
            TotaldeAgricultores = new Label();
            TotaldeProfessores = new Label();
            TotalResidencias = new Label();
            TotalEdificios = new Label();
            label63 = new Label();
            label69 = new Label();
            label70 = new Label();
            label71 = new Label();
            label72 = new Label();
            label73 = new Label();
            label74 = new Label();
            label75 = new Label();
            label76 = new Label();
            label77 = new Label();
            label78 = new Label();
            label79 = new Label();
            Ferro = new Label();
            Combustivel = new Label();
            Alimento = new Label();
            Educacao = new Label();
            Saude = new Label();
            FerroPrivado = new Label();
            CombustivelPrivado = new Label();
            AlimentoPrivado = new Label();
            EducacaoPrivado = new Label();
            SaudePrivado = new Label();
            label80 = new Label();
            label81 = new Label();
            ConsumoPontosEducacao = new Label();
            label82 = new Label();
            label83 = new Label();
            label84 = new Label();
            InflacaoPontosEducacao = new Label();
            DeflacaoPontosEducacao = new Label();
            label87 = new Label();
            DeflacaoPontosSaude = new Label();
            label86 = new Label();
            InflacaoPontosSaude = new Label();
            label89 = new Label();
            ConsumoPontosSaude = new Label();
            label91 = new Label();
            DeflacaoPontosAlimento = new Label();
            label88 = new Label();
            InflacaoPontosAlimento = new Label();
            label92 = new Label();
            ConsumoPontosAlimentos = new Label();
            label94 = new Label();
            MenosConsumoPrivadoEducacao = new Button();
            MenosConsumoEstatalEducacao = new Button();
            MenosConsumoPrivadoSaude = new Button();
            MenosConsumoAlimentoEstatal = new Button();
            MenosConsumoPrivadoAlimentos = new Button();
            MenosConsumoPrivadoCombustivel = new Button();
            DeflacaoPontosCombustivel = new Label();
            label90 = new Label();
            InflacaoPontosCombustivel = new Label();
            label95 = new Label();
            ConsumoPontosCombustivel = new Label();
            label97 = new Label();
            MenosConsumoFerroEstatal = new Button();
            MenosConsumoFerroPrivado = new Button();
            DeflacaoPontosFerro = new Label();
            label93 = new Label();
            InflacaoPontosFerro = new Label();
            label98 = new Label();
            ConsumoPontosFerro = new Label();
            label100 = new Label();
            SubtracaoConsumo = new TextBox();
            PainelDeControle = new TabControl();
            tabPage1 = new TabPage();
            Painel = new TabControl();
            tabPage6 = new TabPage();
            label115 = new Label();
            label114 = new Label();
            tabPage5 = new TabPage();
            TaxaFerro = new TextBox();
            label128 = new Label();
            TaxaCombustivel = new TextBox();
            label127 = new Label();
            TaxaAgricultura = new TextBox();
            label122 = new Label();
            TaxaSaude = new TextBox();
            TaxaEducacao = new TextBox();
            label121 = new Label();
            label120 = new Label();
            label118 = new Label();
            tabPage7 = new TabPage();
            label131 = new Label();
            label132 = new Label();
            SetorAgriculturaEstatal = new Label();
            SetorFerroEstatal = new Label();
            label135 = new Label();
            label136 = new Label();
            label137 = new Label();
            SetorSaudeEstatal = new Label();
            SetorEducacaoEstatal = new Label();
            SetorCombustivelEstatal = new Label();
            label141 = new Label();
            label130 = new Label();
            label123 = new Label();
            SetorAgriculturaPrivado = new Label();
            SetorFerroPrivado = new Label();
            label126 = new Label();
            label124 = new Label();
            label129 = new Label();
            SetorSaudePrivado = new Label();
            SetorEducacaoPrivado = new Label();
            SetorCombustivelPrivado = new Label();
            label125 = new Label();
            demandaagregada = new Label();
            label119 = new Label();
            TaxaDesemprego = new Label();
            label117 = new Label();
            SalarioMinimoNecessario = new Label();
            label116 = new Label();
            MenosTodosEstatal = new CheckBox();
            MenosConsumoTodos = new CheckBox();
            DEFLACAOAGREGADAPORCENTAGEM = new Label();
            INFLACAAGREGADAPORCENTAGEM = new Label();
            label109 = new Label();
            label102 = new Label();
            MenosConsumoCombustivelEstatal = new Button();
            MnosConsumoSaudeEstatal = new Button();
            PoderDeCompra = new Label();
            PIBNOMINALPORCENTAGEM = new Label();
            label113 = new Label();
            PIBREALPORCENTAGEM = new Label();
            label111 = new Label();
            PIBREAL = new Label();
            label112 = new Label();
            ProdutoInternoBruto = new Label();
            label110 = new Label();
            label108 = new Label();
            DEFLACAOAGREGADA = new Label();
            label107 = new Label();
            SalarioMedioNacional = new Label();
            label104 = new Label();
            label106 = new Label();
            DeflacaoDeCustos = new Label();
            label105 = new Label();
            InflacaoDeCustos = new Label();
            label103 = new Label();
            INFLACAOAGREGADA = new Label();
            label101 = new Label();
            label99 = new Label();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            label96 = new Label();
            tabPage4 = new TabPage();
            label85 = new Label();
            folderBrowserDialog1 = new FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)fileSystemWatcher1).BeginInit();
            PainelDeControle.SuspendLayout();
            tabPage1.SuspendLayout();
            Painel.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage5.SuspendLayout();
            tabPage7.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(10, 6);
            button1.Name = "button1";
            button1.Size = new Size(61, 27);
            button1.TabIndex = 0;
            button1.Text = "Imprimir";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(128, 255, 128);
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Location = new Point(136, 38);
            label1.Margin = new Padding(3);
            label1.Name = "label1";
            label1.Size = new Size(15, 17);
            label1.TabIndex = 1;
            label1.Text = "0";
            label1.Click += label1_Tick;
            // 
            // button4
            // 
            button4.BackColor = Color.Lime;
            button4.Location = new Point(10, 38);
            button4.Name = "button4";
            button4.Size = new Size(173, 23);
            button4.TabIndex = 4;
            button4.Text = "Tranferir para Governo";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(128, 255, 128);
            label2.Location = new Point(275, 38);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 5;
            label2.Text = "0";
            label2.Click += label2_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(458, 3);
            label3.Name = "label3";
            label3.Size = new Size(0, 15);
            label3.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(128, 255, 128);
            label4.Location = new Point(417, 38);
            label4.Name = "label4";
            label4.Size = new Size(13, 15);
            label4.TabIndex = 7;
            label4.Text = "0";
            label4.Click += label4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(10, 67);
            button3.Name = "button3";
            button3.Size = new Size(173, 23);
            button3.TabIndex = 8;
            button3.Text = "Transferir para Cidadaos";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click_1;
            // 
            // Taxa
            // 
            Taxa.Location = new Point(131, 90);
            Taxa.Name = "Taxa";
            Taxa.Size = new Size(49, 23);
            Taxa.TabIndex = 9;
            Taxa.TextChanged += Taxa_TextChanged;
            // 
            // button5
            // 
            button5.Location = new Point(525, 32);
            button5.Name = "button5";
            button5.Size = new Size(112, 23);
            button5.TabIndex = 10;
            button5.Text = "Próximo Turno";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ActiveBorder;
            label5.Location = new Point(643, 36);
            label5.Name = "label5";
            label5.Size = new Size(13, 15);
            label5.TabIndex = 11;
            label5.Text = "0";
            label5.Click += label5_Click_1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(4, 93);
            label6.Name = "label6";
            label6.Size = new Size(118, 15);
            label6.TabIndex = 12;
            label6.Text = "Taxa Imposto Direto: ";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(3, 38);
            label7.Name = "label7";
            label7.Size = new Size(134, 15);
            label7.TabIndex = 13;
            label7.Text = "Dinheiro Total Impresso:";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(214, 38);
            label8.Name = "label8";
            label8.Size = new Size(55, 15);
            label8.TabIndex = 14;
            label8.Text = "Governo:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(352, 38);
            label9.Name = "label9";
            label9.Size = new Size(59, 15);
            label9.TabIndex = 15;
            label9.Text = "Cidadaos:";
            label9.Click += label9_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Red;
            label10.Location = new Point(3, 3);
            label10.Name = "label10";
            label10.Padding = new Padding(0, 0, 410, 15);
            label10.RightToLeft = RightToLeft.No;
            label10.Size = new Size(667, 30);
            label10.TabIndex = 16;
            label10.Text = "PAINEL PARA CONTROLE FINANCEIRO DO PAÍS";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            label10.Click += label10_Click;
            // 
            // label11
            // 
            label11.BackColor = Color.Red;
            label11.Location = new Point(3, 3);
            label11.Name = "label11";
            label11.Padding = new Padding(0, 0, 410, 15);
            label11.RightToLeft = RightToLeft.No;
            label11.Size = new Size(284, 30);
            label11.TabIndex = 17;
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(3, 32);
            label12.Name = "label12";
            label12.Size = new Size(115, 15);
            label12.TabIndex = 18;
            label12.Text = "POPULAÇÃO TOTAL:";
            label12.Click += label12_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(3, 92);
            label13.Name = "label13";
            label13.Size = new Size(173, 15);
            label13.TabIndex = 19;
            label13.Text = "POPULAÇÃO SEM RESIDÊNCIA:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(1, 122);
            label14.Name = "label14";
            label14.Size = new Size(209, 15);
            label14.TabIndex = 20;
            label14.Text = "POPULAÇÃO SEM ENERGIA ELÉTRICA:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(1, 137);
            label15.Name = "label15";
            label15.Size = new Size(230, 15);
            label15.TabIndex = 21;
            label15.Text = "POPULAÇÃO SEM SANEAMENTO BÁSICO:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(15, 23);
            label16.Name = "label16";
            label16.Size = new Size(114, 15);
            label16.TabIndex = 22;
            label16.Text = "TOTAL DE EDIFICIOS:";
            label16.Click += label16_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(15, 38);
            label17.Name = "label17";
            label17.Size = new Size(132, 15);
            label17.TabIndex = 23;
            label17.Text = "TOTAL DE RESIDÊNCIAS:";
            label17.Click += label17_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(15, 53);
            label18.Name = "label18";
            label18.Size = new Size(174, 15);
            label18.TabIndex = 24;
            label18.Text = "TOTAL DE CASAS RESIDENCIAIS:";
            label18.Click += label18_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(15, 68);
            label19.Name = "label19";
            label19.Size = new Size(184, 15);
            label19.TabIndex = 25;
            label19.Text = "TOTAL DE PRÉDIOS RESIDENCIAIS:";
            label19.Click += label19_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(18, 98);
            label20.Name = "label20";
            label20.Size = new Size(197, 15);
            label20.TabIndex = 26;
            label20.Text = "TOTAL DE INSTITUIÇÕES DE ENSINO:";
            label20.Click += label20_Click;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(18, 113);
            label22.Name = "label22";
            label22.Size = new Size(118, 15);
            label22.TabIndex = 28;
            label22.Text = "TOTAL DE HOSPITAIS:";
            label22.Click += label22_Click;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(18, 127);
            label23.Name = "label23";
            label23.Size = new Size(129, 15);
            label23.TabIndex = 29;
            label23.Text = "TOTAL DE DELEGACIAS:";
            label23.Click += label23_Click;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(18, 143);
            label24.Name = "label24";
            label24.Size = new Size(114, 15);
            label24.TabIndex = 30;
            label24.Text = "TOTAL DE QUARTÉIS:";
            label24.Click += label24_Click;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(18, 160);
            label25.Name = "label25";
            label25.Size = new Size(198, 15);
            label25.TabIndex = 31;
            label25.Text = "TOTAL DE RESERVATÓRIOS DE ÁGUA:";
            label25.Click += label25_Click;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(18, 175);
            label26.Name = "label26";
            label26.Size = new Size(276, 15);
            label26.TabIndex = 32;
            label26.Text = "TOTAL DE CENTROS DE DISTRIBUIÇÃO DE ENERGIA:";
            label26.Click += label26_Click;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(3, 167);
            label27.Name = "label27";
            label27.Size = new Size(139, 15);
            label27.TabIndex = 33;
            label27.Text = "POPULAÇÃO NO CRIME:";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(658, 395);
            label28.Name = "label28";
            label28.Size = new Size(0, 15);
            label28.TabIndex = 34;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(-1, 152);
            label29.Name = "label29";
            label29.Size = new Size(219, 15);
            label29.TabIndex = 35;
            label29.Text = "POPULAÇÃO SEM ACESSO A HOSPITAL:";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(18, 333);
            label30.Name = "label30";
            label30.Size = new Size(106, 15);
            label30.TabIndex = 36;
            label30.Text = "TOTAL DE MORTES:";
            label30.Click += label30_Click;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(18, 303);
            label31.Name = "label31";
            label31.Size = new Size(179, 15);
            label31.TabIndex = 37;
            label31.Text = "MORTES POR CAUSA DO CRIME:";
            label31.Click += label31_Click;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(18, 318);
            label32.Name = "label32";
            label32.Size = new Size(137, 15);
            label32.TabIndex = 38;
            label32.Text = "MORTES POR DOENÇAS:";
            label32.Click += label32_Click;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(1, 62);
            label33.Name = "label33";
            label33.Size = new Size(113, 15);
            label33.TabIndex = 39;
            label33.Text = "TOTAL DE MÉDICOS:";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(0, 32);
            label34.Name = "label34";
            label34.Size = new Size(115, 15);
            label34.TabIndex = 40;
            label34.Text = "TOTAL DE POLICIAIS:";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(1, 47);
            label35.Name = "label35";
            label35.Size = new Size(122, 15);
            label35.TabIndex = 41;
            label35.Text = "TOTAL DE SOLDADOS:";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(1, 77);
            label36.Name = "label36";
            label36.Size = new Size(137, 15);
            label36.TabIndex = 42;
            label36.Text = "TOTAL DE PROFESSORES:";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new Point(3, 107);
            label37.Name = "label37";
            label37.Size = new Size(129, 15);
            label37.TabIndex = 43;
            label37.Text = "TOTAL ENCANADORES:";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(3, 122);
            label38.Name = "label38";
            label38.Size = new Size(118, 15);
            label38.TabIndex = 44;
            label38.Text = "TOTAL ELETRECISTAS:";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new Point(18, 260);
            label39.Name = "label39";
            label39.Size = new Size(176, 15);
            label39.TabIndex = 45;
            label39.Text = "TOTAL DE TERRITÓRIOS DO PAÍS:";
            label39.Click += label39_Click;
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(18, 275);
            label40.Name = "label40";
            label40.Size = new Size(148, 15);
            label40.TabIndex = 46;
            label40.Text = "TERRITÓRIOS DISPONÍVEIS:";
            label40.Click += label40_Click;
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new Point(18, 191);
            label41.Name = "label41";
            label41.Size = new Size(119, 15);
            label41.TabIndex = 47;
            label41.Text = "TOTAL DE FAZENDAS:";
            label41.Click += label41_Click;
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Location = new Point(1, 92);
            label42.Name = "label42";
            label42.Size = new Size(142, 15);
            label42.TabIndex = 48;
            label42.Text = "TOTAL DE AGRICULTORES:";
            // 
            // Povo
            // 
            Povo.AutoSize = true;
            Povo.Location = new Point(124, 32);
            Povo.Name = "Povo";
            Povo.Size = new Size(13, 15);
            Povo.TabIndex = 49;
            Povo.Text = "0";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Location = new Point(3, 483);
            label44.Name = "label44";
            label44.Size = new Size(192, 15);
            label44.TabIndex = 50;
            label44.Text = "Minimo de dinheiro em circulação:";
            // 
            // INDF
            // 
            INDF.AutoSize = true;
            INDF.Location = new Point(201, 483);
            INDF.Name = "INDF";
            INDF.Size = new Size(13, 15);
            INDF.TabIndex = 51;
            INDF.Text = "0";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Location = new Point(267, 439);
            label46.Name = "label46";
            label46.Size = new Size(152, 15);
            label46.TabIndex = 52;
            label46.Text = "Inflação excesso de moeda:";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Location = new Point(267, 424);
            label47.Name = "label47";
            label47.Size = new Size(159, 15);
            label47.TabIndex = 53;
            label47.Text = "Deflação escassez de moeda:";
            // 
            // IN
            // 
            IN.AutoSize = true;
            IN.Location = new Point(428, 439);
            IN.Name = "IN";
            IN.Size = new Size(13, 15);
            IN.TabIndex = 54;
            IN.Text = "0";
            IN.Click += label48_Click;
            // 
            // DF
            // 
            DF.AutoSize = true;
            DF.Location = new Point(428, 424);
            DF.Name = "DF";
            DF.Size = new Size(13, 15);
            DF.TabIndex = 55;
            DF.Text = "0";
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Location = new Point(3, 422);
            label43.Name = "label43";
            label43.Size = new Size(175, 15);
            label43.TabIndex = 56;
            label43.Text = "Quantia de dinheiro por pessoa:";
            // 
            // QDP
            // 
            QDP.AutoSize = true;
            QDP.Location = new Point(184, 422);
            QDP.Name = "QDP";
            QDP.Size = new Size(13, 15);
            QDP.TabIndex = 57;
            QDP.Text = "0";
            QDP.Click += QDP_Click;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Location = new Point(-2, 151);
            label45.Name = "label45";
            label45.Size = new Size(0, 15);
            label45.TabIndex = 58;
            // 
            // ELIMINAR
            // 
            ELIMINAR.Location = new Point(78, 6);
            ELIMINAR.Name = "ELIMINAR";
            ELIMINAR.Size = new Size(105, 27);
            ELIMINAR.TabIndex = 59;
            ELIMINAR.Text = "Eliminar dinheiro";
            ELIMINAR.UseVisualStyleBackColor = true;
            ELIMINAR.Click += ELIMINAR_Click;
            // 
            // Administração
            // 
            Administração.Location = new Point(207, 6);
            Administração.Name = "Administração";
            Administração.Size = new Size(260, 25);
            Administração.TabIndex = 60;
            Administração.Text = "Acessar Construções do País";
            Administração.UseVisualStyleBackColor = true;
            Administração.Click += Administração_Click;
            // 
            // label480
            // 
            label480.AutoSize = true;
            label480.Location = new Point(195, 54);
            label480.Name = "label480";
            label480.Size = new Size(13, 15);
            label480.TabIndex = 61;
            label480.Text = "0";
            label480.Click += label480_Click;
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Location = new Point(2, 62);
            label48.Name = "label48";
            label48.Size = new Size(172, 15);
            label48.TabIndex = 63;
            label48.Text = "POPULAÇÃO DESEMPREGADA:";
            // 
            // labelPopulacaoSemResidencia
            // 
            labelPopulacaoSemResidencia.AutoSize = true;
            labelPopulacaoSemResidencia.Location = new Point(180, 92);
            labelPopulacaoSemResidencia.Name = "labelPopulacaoSemResidencia";
            labelPopulacaoSemResidencia.Size = new Size(13, 15);
            labelPopulacaoSemResidencia.TabIndex = 64;
            labelPopulacaoSemResidencia.Text = "0";
            // 
            // fileSystemWatcher1
            // 
            fileSystemWatcher1.EnableRaisingEvents = true;
            fileSystemWatcher1.SynchronizingObject = this;
            // 
            // TerrasDisponiveis
            // 
            TerrasDisponiveis.AutoSize = true;
            TerrasDisponiveis.Location = new Point(172, 276);
            TerrasDisponiveis.Name = "TerrasDisponiveis";
            TerrasDisponiveis.Size = new Size(13, 15);
            TerrasDisponiveis.TabIndex = 65;
            TerrasDisponiveis.Text = "0";
            TerrasDisponiveis.Click += TerrasDisponiveis_Click;
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.Location = new Point(18, 290);
            label49.Name = "label49";
            label49.Size = new Size(143, 15);
            label49.TabIndex = 67;
            label49.Text = "TERRITÓRIOS OCUPADOS:";
            label49.Click += label49_Click;
            // 
            // TerrasOcupadas
            // 
            TerrasOcupadas.AutoSize = true;
            TerrasOcupadas.Location = new Point(167, 291);
            TerrasOcupadas.Name = "TerrasOcupadas";
            TerrasOcupadas.Size = new Size(13, 15);
            TerrasOcupadas.TabIndex = 68;
            TerrasOcupadas.Text = "0";
            TerrasOcupadas.Click += TerrasOcupadas_Click;
            // 
            // PopulacaoDesempregada
            // 
            PopulacaoDesempregada.AutoSize = true;
            PopulacaoDesempregada.Location = new Point(177, 62);
            PopulacaoDesempregada.Name = "PopulacaoDesempregada";
            PopulacaoDesempregada.Size = new Size(13, 15);
            PopulacaoDesempregada.TabIndex = 69;
            PopulacaoDesempregada.Text = "0";
            // 
            // AcessarIndice
            // 
            AcessarIndice.Location = new Point(18, 0);
            AcessarIndice.Name = "AcessarIndice";
            AcessarIndice.Size = new Size(286, 23);
            AcessarIndice.TabIndex = 70;
            AcessarIndice.Text = "Acessar Indíce de Desenvolvimento do País";
            AcessarIndice.UseVisualStyleBackColor = true;
            AcessarIndice.Click += AcessarIndice_Click;
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Location = new Point(3, 77);
            label50.Name = "label50";
            label50.Size = new Size(172, 15);
            label50.TabIndex = 71;
            label50.Text = "POPULAÇÃO SEM EDUCAÇÃO:";
            // 
            // TotalEscolas
            // 
            TotalEscolas.AutoSize = true;
            TotalEscolas.Location = new Point(222, 98);
            TotalEscolas.Name = "TotalEscolas";
            TotalEscolas.Size = new Size(13, 15);
            TotalEscolas.TabIndex = 72;
            TotalEscolas.Text = "0";
            TotalEscolas.Click += TotalEscolas_Click;
            // 
            // populacaoSemEducacao
            // 
            populacaoSemEducacao.AutoSize = true;
            populacaoSemEducacao.Location = new Point(178, 77);
            populacaoSemEducacao.Name = "populacaoSemEducacao";
            populacaoSemEducacao.Size = new Size(13, 15);
            populacaoSemEducacao.TabIndex = 73;
            populacaoSemEducacao.Text = "0";
            // 
            // TotalProfessores
            // 
            TotalProfessores.AutoSize = true;
            TotalProfessores.Location = new Point(144, 77);
            TotalProfessores.Name = "TotalProfessores";
            TotalProfessores.Size = new Size(13, 15);
            TotalProfessores.TabIndex = 74;
            TotalProfessores.Text = "0";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(3, 47);
            label21.Name = "label21";
            label21.Size = new Size(152, 15);
            label21.TabIndex = 75;
            label21.Text = "POPULAÇÃO EMPREGADA:";
            // 
            // PopulacaoEmpregada
            // 
            PopulacaoEmpregada.AutoSize = true;
            PopulacaoEmpregada.Location = new Point(161, 47);
            PopulacaoEmpregada.Name = "PopulacaoEmpregada";
            PopulacaoEmpregada.Size = new Size(13, 15);
            PopulacaoEmpregada.TabIndex = 76;
            PopulacaoEmpregada.Text = "0";
            // 
            // TotalHospitais
            // 
            TotalHospitais.AutoSize = true;
            TotalHospitais.Location = new Point(142, 114);
            TotalHospitais.Name = "TotalHospitais";
            TotalHospitais.Size = new Size(13, 15);
            TotalHospitais.TabIndex = 77;
            TotalHospitais.Text = "0";
            TotalHospitais.Click += TotalHospitais_Click;
            // 
            // PopulacaoSemAcessoHospital
            // 
            PopulacaoSemAcessoHospital.AutoSize = true;
            PopulacaoSemAcessoHospital.Location = new Point(224, 152);
            PopulacaoSemAcessoHospital.Name = "PopulacaoSemAcessoHospital";
            PopulacaoSemAcessoHospital.Size = new Size(13, 15);
            PopulacaoSemAcessoHospital.TabIndex = 78;
            PopulacaoSemAcessoHospital.Text = "0";
            // 
            // TotalMedicos
            // 
            TotalMedicos.AutoSize = true;
            TotalMedicos.Location = new Point(119, 62);
            TotalMedicos.Name = "TotalMedicos";
            TotalMedicos.Size = new Size(13, 15);
            TotalMedicos.TabIndex = 79;
            TotalMedicos.Text = "0";
            // 
            // TerritoriosPais
            // 
            TerritoriosPais.AutoSize = true;
            TerritoriosPais.Location = new Point(200, 260);
            TerritoriosPais.Name = "TerritoriosPais";
            TerritoriosPais.Size = new Size(25, 15);
            TerritoriosPais.TabIndex = 80;
            TerritoriosPais.Text = "600";
            TerritoriosPais.Click += TerritoriosPais_Click;
            // 
            // labelpredio
            // 
            labelpredio.AutoSize = true;
            labelpredio.Location = new Point(205, 69);
            labelpredio.Name = "labelpredio";
            labelpredio.Size = new Size(13, 15);
            labelpredio.TabIndex = 81;
            labelpredio.Text = "0";
            labelpredio.Click += labelpredio_Click_1;
            // 
            // TotalFazendas
            // 
            TotalFazendas.AutoSize = true;
            TotalFazendas.Location = new Point(142, 191);
            TotalFazendas.Name = "TotalFazendas";
            TotalFazendas.Size = new Size(13, 15);
            TotalFazendas.TabIndex = 82;
            TotalFazendas.Text = "0";
            TotalFazendas.Click += TotalFazendas_Click;
            // 
            // TotalAgricultores
            // 
            TotalAgricultores.AutoSize = true;
            TotalAgricultores.Location = new Point(149, 92);
            TotalAgricultores.Name = "TotalAgricultores";
            TotalAgricultores.Size = new Size(13, 15);
            TotalAgricultores.TabIndex = 83;
            TotalAgricultores.Text = "0";
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Location = new Point(3, 107);
            label51.Name = "label51";
            label51.Size = new Size(249, 15);
            label51.TabIndex = 84;
            label51.Text = "POPULAÇÃO EM RISCO/SITUAÇÃO DE FOME:";
            // 
            // PovoComFome
            // 
            PovoComFome.AutoSize = true;
            PovoComFome.Location = new Point(256, 107);
            PovoComFome.Name = "PovoComFome";
            PovoComFome.Size = new Size(13, 15);
            PovoComFome.TabIndex = 85;
            PovoComFome.Text = "0";
            // 
            // TotalCentrosdeEnergia
            // 
            TotalCentrosdeEnergia.AutoSize = true;
            TotalCentrosdeEnergia.Location = new Point(300, 176);
            TotalCentrosdeEnergia.Name = "TotalCentrosdeEnergia";
            TotalCentrosdeEnergia.Size = new Size(13, 15);
            TotalCentrosdeEnergia.TabIndex = 86;
            TotalCentrosdeEnergia.Text = "0";
            TotalCentrosdeEnergia.Click += TotalCentrosdeEnergia_Click;
            // 
            // TotalEletrecistas
            // 
            TotalEletrecistas.AutoSize = true;
            TotalEletrecistas.Location = new Point(124, 122);
            TotalEletrecistas.Name = "TotalEletrecistas";
            TotalEletrecistas.Size = new Size(13, 15);
            TotalEletrecistas.TabIndex = 87;
            TotalEletrecistas.Text = "0";
            TotalEletrecistas.Click += TotalEletrecistas_Click;
            // 
            // label53
            // 
            label53.BackColor = Color.Red;
            label53.Location = new Point(0, 0);
            label53.Name = "label53";
            label53.Size = new Size(251, 29);
            label53.TabIndex = 89;
            label53.Text = "Empregados de empresas Estatais e Privadas";
            label53.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PovoSemEnergia
            // 
            PovoSemEnergia.AutoSize = true;
            PovoSemEnergia.Location = new Point(216, 122);
            PovoSemEnergia.Name = "PovoSemEnergia";
            PovoSemEnergia.Size = new Size(13, 15);
            PovoSemEnergia.TabIndex = 90;
            PovoSemEnergia.Text = "0";
            // 
            // label52
            // 
            label52.BackColor = Color.Red;
            label52.Location = new Point(18, 236);
            label52.Name = "label52";
            label52.Size = new Size(356, 23);
            label52.TabIndex = 91;
            label52.Text = "INFORMAÇÕES ADICIONAIS";
            label52.Click += label52_Click;
            // 
            // TotalEncanadores
            // 
            TotalEncanadores.AutoSize = true;
            TotalEncanadores.Location = new Point(132, 107);
            TotalEncanadores.Name = "TotalEncanadores";
            TotalEncanadores.Size = new Size(13, 15);
            TotalEncanadores.TabIndex = 92;
            TotalEncanadores.Text = "0";
            // 
            // TotalReservatoriosAgua
            // 
            TotalReservatoriosAgua.AutoSize = true;
            TotalReservatoriosAgua.Location = new Point(222, 160);
            TotalReservatoriosAgua.Name = "TotalReservatoriosAgua";
            TotalReservatoriosAgua.Size = new Size(13, 15);
            TotalReservatoriosAgua.TabIndex = 93;
            TotalReservatoriosAgua.Text = "0";
            TotalReservatoriosAgua.Click += TotalReservatoriosAgua_Click;
            // 
            // PovoSemSaneamento
            // 
            PovoSemSaneamento.AutoSize = true;
            PovoSemSaneamento.Location = new Point(237, 137);
            PovoSemSaneamento.Name = "PovoSemSaneamento";
            PovoSemSaneamento.Size = new Size(13, 15);
            PovoSemSaneamento.TabIndex = 94;
            PovoSemSaneamento.Text = "0";
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Location = new Point(18, 348);
            label54.Name = "label54";
            label54.Size = new Size(183, 15);
            label54.TabIndex = 95;
            label54.Text = "ESPAÇO DISPONIVEL SOLDADOS:";
            label54.Click += label54_Click;
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.Location = new Point(18, 363);
            label55.Name = "label55";
            label55.Size = new Size(176, 15);
            label55.TabIndex = 96;
            label55.Text = "ESPAÇO DISPONIVEL POLICIAIS:";
            label55.Click += label55_Click;
            // 
            // EspacoDisponivelSoldados
            // 
            EspacoDisponivelSoldados.AutoSize = true;
            EspacoDisponivelSoldados.Location = new Point(207, 349);
            EspacoDisponivelSoldados.Name = "EspacoDisponivelSoldados";
            EspacoDisponivelSoldados.Size = new Size(13, 15);
            EspacoDisponivelSoldados.TabIndex = 97;
            EspacoDisponivelSoldados.Text = "0";
            EspacoDisponivelSoldados.Click += EspacoDisponivelSoldados_Click;
            // 
            // TotalSoldados
            // 
            TotalSoldados.AutoSize = true;
            TotalSoldados.Location = new Point(128, 47);
            TotalSoldados.Name = "TotalSoldados";
            TotalSoldados.Size = new Size(13, 15);
            TotalSoldados.TabIndex = 98;
            TotalSoldados.Text = "0";
            // 
            // TotalQuarteis
            // 
            TotalQuarteis.AutoSize = true;
            TotalQuarteis.Location = new Point(136, 143);
            TotalQuarteis.Name = "TotalQuarteis";
            TotalQuarteis.Size = new Size(13, 15);
            TotalQuarteis.TabIndex = 99;
            TotalQuarteis.Text = "0";
            TotalQuarteis.Click += TotalQuarteis_Click;
            // 
            // EspacoDisponivelPoliciais
            // 
            EspacoDisponivelPoliciais.AutoSize = true;
            EspacoDisponivelPoliciais.Location = new Point(200, 364);
            EspacoDisponivelPoliciais.Name = "EspacoDisponivelPoliciais";
            EspacoDisponivelPoliciais.Size = new Size(13, 15);
            EspacoDisponivelPoliciais.TabIndex = 100;
            EspacoDisponivelPoliciais.Text = "0";
            EspacoDisponivelPoliciais.Click += EspacoDisponivelPoliciais_Click;
            // 
            // TotalPoliciais
            // 
            TotalPoliciais.AutoSize = true;
            TotalPoliciais.Location = new Point(118, 32);
            TotalPoliciais.Name = "TotalPoliciais";
            TotalPoliciais.Size = new Size(13, 15);
            TotalPoliciais.TabIndex = 101;
            TotalPoliciais.Text = "0";
            // 
            // TotalDelegacias
            // 
            TotalDelegacias.AutoSize = true;
            TotalDelegacias.Location = new Point(149, 129);
            TotalDelegacias.Name = "TotalDelegacias";
            TotalDelegacias.Size = new Size(13, 15);
            TotalDelegacias.TabIndex = 102;
            TotalDelegacias.Text = "0";
            TotalDelegacias.Click += TotalDelegacias_Click;
            // 
            // TotalEscolasPrivadas
            // 
            TotalEscolasPrivadas.AutoSize = true;
            TotalEscolasPrivadas.BackColor = Color.FromArgb(128, 128, 255);
            TotalEscolasPrivadas.Location = new Point(254, 99);
            TotalEscolasPrivadas.Name = "TotalEscolasPrivadas";
            TotalEscolasPrivadas.Size = new Size(13, 15);
            TotalEscolasPrivadas.TabIndex = 103;
            TotalEscolasPrivadas.Text = "0";
            TotalEscolasPrivadas.Click += TotalEscolasPrivadas_Click;
            // 
            // TotaldeEscolas
            // 
            TotaldeEscolas.AutoSize = true;
            TotaldeEscolas.BackColor = Color.Yellow;
            TotaldeEscolas.Location = new Point(291, 99);
            TotaldeEscolas.Name = "TotaldeEscolas";
            TotaldeEscolas.Size = new Size(13, 15);
            TotaldeEscolas.TabIndex = 104;
            TotaldeEscolas.Text = "0";
            TotaldeEscolas.Click += TotaldeEscolas_Click;
            // 
            // TotalHospitaisPrivados
            // 
            TotalHospitaisPrivados.AutoSize = true;
            TotalHospitaisPrivados.BackColor = Color.FromArgb(128, 128, 255);
            TotalHospitaisPrivados.Location = new Point(179, 114);
            TotalHospitaisPrivados.Name = "TotalHospitaisPrivados";
            TotalHospitaisPrivados.Size = new Size(13, 15);
            TotalHospitaisPrivados.TabIndex = 105;
            TotalHospitaisPrivados.Text = "0";
            TotalHospitaisPrivados.Click += TotalHospitaisPrivados_Click;
            // 
            // TotaldeHospitais
            // 
            TotaldeHospitais.AutoSize = true;
            TotaldeHospitais.BackColor = Color.Yellow;
            TotaldeHospitais.Location = new Point(222, 114);
            TotaldeHospitais.Name = "TotaldeHospitais";
            TotaldeHospitais.Size = new Size(13, 15);
            TotaldeHospitais.TabIndex = 106;
            TotaldeHospitais.Text = "0";
            TotaldeHospitais.Click += TotaldeHospitais_Click;
            // 
            // TotalFazendasPrivadas
            // 
            TotalFazendasPrivadas.AutoSize = true;
            TotalFazendasPrivadas.BackColor = Color.FromArgb(128, 128, 255);
            TotalFazendasPrivadas.Location = new Point(179, 191);
            TotalFazendasPrivadas.Name = "TotalFazendasPrivadas";
            TotalFazendasPrivadas.Size = new Size(13, 15);
            TotalFazendasPrivadas.TabIndex = 107;
            TotalFazendasPrivadas.Text = "0";
            TotalFazendasPrivadas.Click += TotalFazendasPrivadas_Click;
            // 
            // TotaldeFazendas
            // 
            TotaldeFazendas.AutoSize = true;
            TotaldeFazendas.BackColor = Color.Yellow;
            TotaldeFazendas.Location = new Point(222, 190);
            TotaldeFazendas.Name = "TotaldeFazendas";
            TotaldeFazendas.Size = new Size(13, 15);
            TotaldeFazendas.TabIndex = 108;
            TotaldeFazendas.Text = "0";
            TotaldeFazendas.Click += TotaldeFazendas_Click;
            // 
            // CreditoNacional
            // 
            CreditoNacional.Location = new Point(131, 141);
            CreditoNacional.Name = "CreditoNacional";
            CreditoNacional.Size = new Size(49, 23);
            CreditoNacional.TabIndex = 109;
            CreditoNacional.TextChanged += CreditoNacional_TextChanged;
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.Location = new Point(4, 145);
            label56.Name = "label56";
            label56.Size = new Size(99, 15);
            label56.TabIndex = 110;
            label56.Text = "Crédito Nacional:";
            label56.Click += label56_Click;
            // 
            // TotalCredito
            // 
            TotalCredito.AutoSize = true;
            TotalCredito.Location = new Point(369, 132);
            TotalCredito.Name = "TotalCredito";
            TotalCredito.Size = new Size(13, 15);
            TotalCredito.TabIndex = 111;
            TotalCredito.Text = "0";
            TotalCredito.Click += TotalCredito_Click;
            // 
            // MaisCredito
            // 
            MaisCredito.Location = new Point(102, 143);
            MaisCredito.Name = "MaisCredito";
            MaisCredito.Size = new Size(23, 20);
            MaisCredito.TabIndex = 112;
            MaisCredito.Text = "+";
            MaisCredito.UseVisualStyleBackColor = true;
            MaisCredito.Click += MaisCredito_Click;
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.Location = new Point(5, 138);
            label57.Name = "label57";
            label57.Size = new Size(121, 15);
            label57.TabIndex = 114;
            label57.Text = "TOTAL EMPRESARIOS:";
            // 
            // TotalEmpresarios
            // 
            TotalEmpresarios.AutoSize = true;
            TotalEmpresarios.BackColor = Color.FromArgb(128, 128, 255);
            TotalEmpresarios.Location = new Point(130, 138);
            TotalEmpresarios.Name = "TotalEmpresarios";
            TotalEmpresarios.Size = new Size(13, 15);
            TotalEmpresarios.TabIndex = 115;
            TotalEmpresarios.Text = "0";
            // 
            // TotalProfessoresPrivados
            // 
            TotalProfessoresPrivados.AutoSize = true;
            TotalProfessoresPrivados.BackColor = Color.FromArgb(128, 128, 255);
            TotalProfessoresPrivados.Location = new Point(172, 77);
            TotalProfessoresPrivados.Name = "TotalProfessoresPrivados";
            TotalProfessoresPrivados.Size = new Size(13, 15);
            TotalProfessoresPrivados.TabIndex = 116;
            TotalProfessoresPrivados.Text = "0";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(168, 272);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(49, 23);
            textBox1.TabIndex = 117;
            // 
            // TaxaSelic
            // 
            TaxaSelic.Location = new Point(131, 115);
            TaxaSelic.Name = "TaxaSelic";
            TaxaSelic.Size = new Size(49, 23);
            TaxaSelic.TabIndex = 118;
            // 
            // label58
            // 
            label58.AutoSize = true;
            label58.Location = new Point(4, 118);
            label58.Name = "label58";
            label58.Size = new Size(60, 15);
            label58.TabIndex = 119;
            label58.Text = "Taxa Selic:";
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.Location = new Point(18, 83);
            label59.Name = "label59";
            label59.Size = new Size(149, 15);
            label59.TabIndex = 120;
            label59.Text = "TOTAL BANCOS PRIVADOS:";
            label59.Click += label59_Click;
            // 
            // TotalBancosPrivados
            // 
            TotalBancosPrivados.AutoSize = true;
            TotalBancosPrivados.BackColor = Color.FromArgb(128, 128, 255);
            TotalBancosPrivados.Location = new Point(173, 84);
            TotalBancosPrivados.Name = "TotalBancosPrivados";
            TotalBancosPrivados.Size = new Size(13, 15);
            TotalBancosPrivados.TabIndex = 121;
            TotalBancosPrivados.Text = "0";
            TotalBancosPrivados.Click += TotalBancosPrivados_Click;
            // 
            // EmprestimosPorBanco
            // 
            EmprestimosPorBanco.AutoSize = true;
            EmprestimosPorBanco.Location = new Point(349, 115);
            EmprestimosPorBanco.Name = "EmprestimosPorBanco";
            EmprestimosPorBanco.Size = new Size(13, 15);
            EmprestimosPorBanco.TabIndex = 122;
            EmprestimosPorBanco.Text = "0";
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.Location = new Point(207, 34);
            label60.Name = "label60";
            label60.Size = new Size(93, 15);
            label60.TabIndex = 123;
            label60.Text = "Titulos Públicos:";
            // 
            // TitulosPublicos
            // 
            TitulosPublicos.AutoSize = true;
            TitulosPublicos.Location = new Point(304, 34);
            TitulosPublicos.Name = "TitulosPublicos";
            TitulosPublicos.Size = new Size(13, 15);
            TitulosPublicos.TabIndex = 124;
            TitulosPublicos.Text = "0";
            // 
            // TitulosMoney
            // 
            TitulosMoney.AutoSize = true;
            TitulosMoney.Location = new Point(391, 37);
            TitulosMoney.Name = "TitulosMoney";
            TitulosMoney.Size = new Size(13, 15);
            TitulosMoney.TabIndex = 125;
            TitulosMoney.Text = "0";
            // 
            // BuyTitulos
            // 
            BuyTitulos.Location = new Point(375, 31);
            BuyTitulos.Name = "BuyTitulos";
            BuyTitulos.Size = new Size(92, 26);
            BuyTitulos.TabIndex = 127;
            BuyTitulos.Text = "Buy Titulos";
            BuyTitulos.UseVisualStyleBackColor = true;
            BuyTitulos.Click += BuyTitulos_Click;
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.Location = new Point(207, 58);
            label61.Name = "label61";
            label61.Size = new Size(143, 15);
            label61.TabIndex = 128;
            label61.Text = "Preço de venda de titulos:";
            // 
            // label62
            // 
            label62.AutoSize = true;
            label62.Location = new Point(207, 72);
            label62.Name = "label62";
            label62.Size = new Size(152, 15);
            label62.TabIndex = 129;
            label62.Text = "Preço de compra de titulos:";
            // 
            // PrecoVendaTitulos
            // 
            PrecoVendaTitulos.AutoSize = true;
            PrecoVendaTitulos.Location = new Point(356, 58);
            PrecoVendaTitulos.Name = "PrecoVendaTitulos";
            PrecoVendaTitulos.Size = new Size(13, 15);
            PrecoVendaTitulos.TabIndex = 130;
            PrecoVendaTitulos.Text = "0";
            // 
            // PrecoCompraTitulos
            // 
            PrecoCompraTitulos.AutoSize = true;
            PrecoCompraTitulos.Location = new Point(359, 73);
            PrecoCompraTitulos.Name = "PrecoCompraTitulos";
            PrecoCompraTitulos.Size = new Size(13, 15);
            PrecoCompraTitulos.TabIndex = 131;
            PrecoCompraTitulos.Text = "0";
            // 
            // label64
            // 
            label64.AutoSize = true;
            label64.Location = new Point(3, 438);
            label64.Name = "label64";
            label64.Size = new Size(141, 15);
            label64.TabIndex = 134;
            label64.Text = "Salário Minímo Esperado:";
            // 
            // SalarioMinimoEsperado
            // 
            SalarioMinimoEsperado.AutoSize = true;
            SalarioMinimoEsperado.Location = new Point(149, 438);
            SalarioMinimoEsperado.Name = "SalarioMinimoEsperado";
            SalarioMinimoEsperado.Size = new Size(13, 15);
            SalarioMinimoEsperado.TabIndex = 135;
            SalarioMinimoEsperado.Text = "0";
            // 
            // TotalMedicosPrivados
            // 
            TotalMedicosPrivados.AutoSize = true;
            TotalMedicosPrivados.BackColor = Color.FromArgb(128, 128, 255);
            TotalMedicosPrivados.Location = new Point(144, 62);
            TotalMedicosPrivados.Name = "TotalMedicosPrivados";
            TotalMedicosPrivados.Size = new Size(13, 15);
            TotalMedicosPrivados.TabIndex = 136;
            TotalMedicosPrivados.Text = "0";
            // 
            // TotalAgricultoresPrivados
            // 
            TotalAgricultoresPrivados.AutoSize = true;
            TotalAgricultoresPrivados.BackColor = Color.FromArgb(128, 128, 255);
            TotalAgricultoresPrivados.Location = new Point(172, 92);
            TotalAgricultoresPrivados.Name = "TotalAgricultoresPrivados";
            TotalAgricultoresPrivados.Size = new Size(13, 15);
            TotalAgricultoresPrivados.TabIndex = 137;
            TotalAgricultoresPrivados.Text = "0";
            // 
            // AdministracaoAvancada
            // 
            AdministracaoAvancada.Location = new Point(207, 90);
            AdministracaoAvancada.Name = "AdministracaoAvancada";
            AdministracaoAvancada.Size = new Size(253, 23);
            AdministracaoAvancada.TabIndex = 138;
            AdministracaoAvancada.Text = "Acessar Administração Avançada do País";
            AdministracaoAvancada.UseVisualStyleBackColor = true;
            AdministracaoAvancada.Click += AdministracaoAvancada_Click;
            // 
            // label65
            // 
            label65.AutoSize = true;
            label65.Location = new Point(18, 206);
            label65.Name = "label65";
            label65.Size = new Size(141, 15);
            label65.TabIndex = 139;
            label65.Text = "TOTAL INDUSTRIA FERRO:";
            label65.Click += label65_Click;
            // 
            // TotalIndustriaFerro
            // 
            TotalIndustriaFerro.AutoSize = true;
            TotalIndustriaFerro.Location = new Point(161, 207);
            TotalIndustriaFerro.Name = "TotalIndustriaFerro";
            TotalIndustriaFerro.Size = new Size(13, 15);
            TotalIndustriaFerro.TabIndex = 140;
            TotalIndustriaFerro.Text = "0";
            TotalIndustriaFerro.Click += TotalIndustriaFerro_Click;
            // 
            // label66
            // 
            label66.AutoSize = true;
            label66.Location = new Point(3, 153);
            label66.Name = "label66";
            label66.Size = new Size(180, 15);
            label66.TabIndex = 141;
            label66.Text = "TOTAL MINERADORES DE FERRO:";
            // 
            // TotalMineradoresFerro
            // 
            TotalMineradoresFerro.AutoSize = true;
            TotalMineradoresFerro.Location = new Point(185, 153);
            TotalMineradoresFerro.Name = "TotalMineradoresFerro";
            TotalMineradoresFerro.Size = new Size(13, 15);
            TotalMineradoresFerro.TabIndex = 142;
            TotalMineradoresFerro.Text = "0";
            // 
            // label67
            // 
            label67.AutoSize = true;
            label67.Location = new Point(5, 168);
            label67.Name = "label67";
            label67.Size = new Size(194, 15);
            label67.TabIndex = 143;
            label67.Text = "TOTAL TÉCNICO EM COMBUSTIVEL:";
            // 
            // TotalTecnicoCombustivel
            // 
            TotalTecnicoCombustivel.AutoSize = true;
            TotalTecnicoCombustivel.Location = new Point(203, 168);
            TotalTecnicoCombustivel.Name = "TotalTecnicoCombustivel";
            TotalTecnicoCombustivel.Size = new Size(13, 15);
            TotalTecnicoCombustivel.TabIndex = 144;
            TotalTecnicoCombustivel.Text = "0";
            // 
            // label68
            // 
            label68.AutoSize = true;
            label68.Location = new Point(20, 221);
            label68.Name = "label68";
            label68.Size = new Size(200, 15);
            label68.TabIndex = 145;
            label68.Text = "TOTAL INDUSTRIA DE COMBUSTIVEL:";
            label68.Click += label68_Click;
            // 
            // TotalIndustriaCombustivel
            // 
            TotalIndustriaCombustivel.AutoSize = true;
            TotalIndustriaCombustivel.Location = new Point(223, 222);
            TotalIndustriaCombustivel.Name = "TotalIndustriaCombustivel";
            TotalIndustriaCombustivel.Size = new Size(13, 15);
            TotalIndustriaCombustivel.TabIndex = 146;
            TotalIndustriaCombustivel.Text = "0";
            TotalIndustriaCombustivel.Click += TotalIndustriaCombustivel_Click;
            // 
            // TotalMineradoresFerroPrivado
            // 
            TotalMineradoresFerroPrivado.AutoSize = true;
            TotalMineradoresFerroPrivado.BackColor = Color.FromArgb(128, 128, 255);
            TotalMineradoresFerroPrivado.Location = new Point(212, 153);
            TotalMineradoresFerroPrivado.Name = "TotalMineradoresFerroPrivado";
            TotalMineradoresFerroPrivado.Size = new Size(13, 15);
            TotalMineradoresFerroPrivado.TabIndex = 147;
            TotalMineradoresFerroPrivado.Text = "0";
            // 
            // TotalTecnicoCombustivelPrivado
            // 
            TotalTecnicoCombustivelPrivado.AutoSize = true;
            TotalTecnicoCombustivelPrivado.BackColor = Color.FromArgb(128, 128, 255);
            TotalTecnicoCombustivelPrivado.Location = new Point(231, 168);
            TotalTecnicoCombustivelPrivado.Name = "TotalTecnicoCombustivelPrivado";
            TotalTecnicoCombustivelPrivado.Size = new Size(13, 15);
            TotalTecnicoCombustivelPrivado.TabIndex = 148;
            TotalTecnicoCombustivelPrivado.Text = "0";
            // 
            // TotalIndustriaFerroPrivado
            // 
            TotalIndustriaFerroPrivado.AutoSize = true;
            TotalIndustriaFerroPrivado.BackColor = Color.FromArgb(128, 128, 255);
            TotalIndustriaFerroPrivado.Location = new Point(191, 207);
            TotalIndustriaFerroPrivado.Name = "TotalIndustriaFerroPrivado";
            TotalIndustriaFerroPrivado.Size = new Size(13, 15);
            TotalIndustriaFerroPrivado.TabIndex = 149;
            TotalIndustriaFerroPrivado.Text = "0";
            TotalIndustriaFerroPrivado.Click += TotalIndustriaFerroPrivado_Click;
            // 
            // TotalIndustriaCombustivelPrivada
            // 
            TotalIndustriaCombustivelPrivada.AutoSize = true;
            TotalIndustriaCombustivelPrivada.BackColor = Color.FromArgb(128, 128, 255);
            TotalIndustriaCombustivelPrivada.Location = new Point(250, 222);
            TotalIndustriaCombustivelPrivada.Name = "TotalIndustriaCombustivelPrivada";
            TotalIndustriaCombustivelPrivada.Size = new Size(13, 15);
            TotalIndustriaCombustivelPrivada.TabIndex = 150;
            TotalIndustriaCombustivelPrivada.Text = "0";
            TotalIndustriaCombustivelPrivada.Click += TotalIndustriaCombustivelPrivada_Click;
            // 
            // TotaldeTecnicoCombustivel
            // 
            TotaldeTecnicoCombustivel.AutoSize = true;
            TotaldeTecnicoCombustivel.BackColor = Color.Yellow;
            TotaldeTecnicoCombustivel.Location = new Point(264, 168);
            TotaldeTecnicoCombustivel.Name = "TotaldeTecnicoCombustivel";
            TotaldeTecnicoCombustivel.Size = new Size(13, 15);
            TotaldeTecnicoCombustivel.TabIndex = 151;
            TotaldeTecnicoCombustivel.Text = "0";
            // 
            // TotaldeIndustriaCombustivel
            // 
            TotaldeIndustriaCombustivel.AutoSize = true;
            TotaldeIndustriaCombustivel.BackColor = Color.Yellow;
            TotaldeIndustriaCombustivel.Location = new Point(288, 222);
            TotaldeIndustriaCombustivel.Name = "TotaldeIndustriaCombustivel";
            TotaldeIndustriaCombustivel.Size = new Size(13, 15);
            TotaldeIndustriaCombustivel.TabIndex = 152;
            TotaldeIndustriaCombustivel.Text = "0";
            TotaldeIndustriaCombustivel.Click += TotaldeIndustriaCombustivel_Click;
            // 
            // TotaldeIndustriaFerro
            // 
            TotaldeIndustriaFerro.AutoSize = true;
            TotaldeIndustriaFerro.BackColor = Color.Yellow;
            TotaldeIndustriaFerro.Location = new Point(226, 207);
            TotaldeIndustriaFerro.Name = "TotaldeIndustriaFerro";
            TotaldeIndustriaFerro.Size = new Size(13, 15);
            TotaldeIndustriaFerro.TabIndex = 153;
            TotaldeIndustriaFerro.Text = "0";
            TotaldeIndustriaFerro.Click += TotaldeIndustriaFerro_Click;
            // 
            // MenosInstituicaoEnsinoPrivada
            // 
            MenosInstituicaoEnsinoPrivada.Location = new Point(5, 101);
            MenosInstituicaoEnsinoPrivada.Name = "MenosInstituicaoEnsinoPrivada";
            MenosInstituicaoEnsinoPrivada.Size = new Size(10, 10);
            MenosInstituicaoEnsinoPrivada.TabIndex = 154;
            MenosInstituicaoEnsinoPrivada.Text = "button2";
            MenosInstituicaoEnsinoPrivada.UseVisualStyleBackColor = true;
            MenosInstituicaoEnsinoPrivada.Click += MenosInstituicaoEnsinoPrivada_Click;
            // 
            // MenosIndustriaCombustivelPrivada
            // 
            MenosIndustriaCombustivelPrivada.Location = new Point(5, 223);
            MenosIndustriaCombustivelPrivada.Name = "MenosIndustriaCombustivelPrivada";
            MenosIndustriaCombustivelPrivada.Size = new Size(10, 10);
            MenosIndustriaCombustivelPrivada.TabIndex = 155;
            MenosIndustriaCombustivelPrivada.Text = "button6";
            MenosIndustriaCombustivelPrivada.UseVisualStyleBackColor = true;
            MenosIndustriaCombustivelPrivada.Click += MenosIndustriaCombustivelPrivada_Click;
            // 
            // MenosIndustriaFerroPrivada
            // 
            MenosIndustriaFerroPrivada.Location = new Point(5, 208);
            MenosIndustriaFerroPrivada.Name = "MenosIndustriaFerroPrivada";
            MenosIndustriaFerroPrivada.Size = new Size(10, 10);
            MenosIndustriaFerroPrivada.TabIndex = 156;
            MenosIndustriaFerroPrivada.Text = "button7";
            MenosIndustriaFerroPrivada.UseVisualStyleBackColor = true;
            MenosIndustriaFerroPrivada.Click += MenosIndustriaFerroPrivada_Click;
            // 
            // MenosFazendaPrivada
            // 
            MenosFazendaPrivada.Location = new Point(5, 194);
            MenosFazendaPrivada.Name = "MenosFazendaPrivada";
            MenosFazendaPrivada.Size = new Size(10, 10);
            MenosFazendaPrivada.TabIndex = 157;
            MenosFazendaPrivada.Text = "button8";
            MenosFazendaPrivada.UseVisualStyleBackColor = true;
            MenosFazendaPrivada.Click += MenosFazendaPrivada_Click;
            // 
            // MenosHospitalPrivado
            // 
            MenosHospitalPrivado.Location = new Point(5, 116);
            MenosHospitalPrivado.Name = "MenosHospitalPrivado";
            MenosHospitalPrivado.Size = new Size(10, 10);
            MenosHospitalPrivado.TabIndex = 160;
            MenosHospitalPrivado.Text = "button10";
            MenosHospitalPrivado.UseVisualStyleBackColor = true;
            MenosHospitalPrivado.Click += MenosHospitalPrivado_Click;
            // 
            // TotaldeMineradoresFerro
            // 
            TotaldeMineradoresFerro.AutoSize = true;
            TotaldeMineradoresFerro.BackColor = Color.Yellow;
            TotaldeMineradoresFerro.Location = new Point(245, 153);
            TotaldeMineradoresFerro.Name = "TotaldeMineradoresFerro";
            TotaldeMineradoresFerro.Size = new Size(13, 15);
            TotaldeMineradoresFerro.TabIndex = 161;
            TotaldeMineradoresFerro.Text = "0";
            // 
            // TotaldeMedicos
            // 
            TotaldeMedicos.AutoSize = true;
            TotaldeMedicos.BackColor = Color.Yellow;
            TotaldeMedicos.Location = new Point(172, 62);
            TotaldeMedicos.Name = "TotaldeMedicos";
            TotaldeMedicos.Size = new Size(13, 15);
            TotaldeMedicos.TabIndex = 162;
            TotaldeMedicos.Text = "0";
            // 
            // TotaldeAgricultores
            // 
            TotaldeAgricultores.AutoSize = true;
            TotaldeAgricultores.BackColor = Color.Yellow;
            TotaldeAgricultores.Location = new Point(207, 92);
            TotaldeAgricultores.Name = "TotaldeAgricultores";
            TotaldeAgricultores.Size = new Size(13, 15);
            TotaldeAgricultores.TabIndex = 163;
            TotaldeAgricultores.Text = "0";
            // 
            // TotaldeProfessores
            // 
            TotaldeProfessores.AutoSize = true;
            TotaldeProfessores.BackColor = Color.Yellow;
            TotaldeProfessores.Location = new Point(207, 77);
            TotaldeProfessores.Name = "TotaldeProfessores";
            TotaldeProfessores.Size = new Size(13, 15);
            TotaldeProfessores.TabIndex = 164;
            TotaldeProfessores.Text = "0";
            // 
            // TotalResidencias
            // 
            TotalResidencias.AutoSize = true;
            TotalResidencias.Location = new Point(148, 39);
            TotalResidencias.Name = "TotalResidencias";
            TotalResidencias.Size = new Size(13, 15);
            TotalResidencias.TabIndex = 165;
            TotalResidencias.Text = "0";
            TotalResidencias.Click += TotalResidencias_Click;
            // 
            // TotalEdificios
            // 
            TotalEdificios.AutoSize = true;
            TotalEdificios.Location = new Point(134, 24);
            TotalEdificios.Name = "TotalEdificios";
            TotalEdificios.Size = new Size(13, 15);
            TotalEdificios.TabIndex = 166;
            TotalEdificios.Text = "0";
            TotalEdificios.Click += TotalEdificios_Click;
            // 
            // label63
            // 
            label63.AutoSize = true;
            label63.BackColor = Color.Red;
            label63.Location = new Point(521, 58);
            label63.Name = "label63";
            label63.Size = new Size(113, 15);
            label63.TabIndex = 167;
            label63.Text = "RECURSOS ESTATAIS";
            // 
            // label69
            // 
            label69.AutoSize = true;
            label69.Location = new Point(520, 77);
            label69.Name = "label69";
            label69.Size = new Size(45, 15);
            label69.TabIndex = 168;
            label69.Text = "FERRO:";
            // 
            // label70
            // 
            label70.AutoSize = true;
            label70.Location = new Point(519, 92);
            label70.Name = "label70";
            label70.Size = new Size(87, 15);
            label70.TabIndex = 169;
            label70.Text = "COMBUSTIVEL:";
            // 
            // label71
            // 
            label71.AutoSize = true;
            label71.Location = new Point(520, 107);
            label71.Name = "label71";
            label71.Size = new Size(67, 15);
            label71.TabIndex = 170;
            label71.Text = "ALIMENTO:";
            // 
            // label72
            // 
            label72.AutoSize = true;
            label72.Location = new Point(519, 122);
            label72.Name = "label72";
            label72.Size = new Size(73, 15);
            label72.TabIndex = 171;
            label72.Text = "EDUCAÇÃO:";
            // 
            // label73
            // 
            label73.AutoSize = true;
            label73.Location = new Point(520, 137);
            label73.Name = "label73";
            label73.Size = new Size(46, 15);
            label73.TabIndex = 172;
            label73.Text = "SAÚDE:";
            // 
            // label74
            // 
            label74.AutoSize = true;
            label74.BackColor = Color.Red;
            label74.Location = new Point(516, 152);
            label74.Name = "label74";
            label74.Size = new Size(137, 15);
            label74.TabIndex = 173;
            label74.Text = "DE EMPRESAS PRIVADAS";
            // 
            // label75
            // 
            label75.AutoSize = true;
            label75.Location = new Point(517, 227);
            label75.Name = "label75";
            label75.Size = new Size(46, 15);
            label75.TabIndex = 178;
            label75.Text = "SAÚDE:";
            // 
            // label76
            // 
            label76.AutoSize = true;
            label76.Location = new Point(516, 212);
            label76.Name = "label76";
            label76.Size = new Size(73, 15);
            label76.TabIndex = 177;
            label76.Text = "EDUCAÇÃO:";
            // 
            // label77
            // 
            label77.AutoSize = true;
            label77.Location = new Point(517, 197);
            label77.Name = "label77";
            label77.Size = new Size(67, 15);
            label77.TabIndex = 176;
            label77.Text = "ALIMENTO:";
            // 
            // label78
            // 
            label78.AutoSize = true;
            label78.Location = new Point(516, 182);
            label78.Name = "label78";
            label78.Size = new Size(87, 15);
            label78.TabIndex = 175;
            label78.Text = "COMBUSTIVEL:";
            // 
            // label79
            // 
            label79.AutoSize = true;
            label79.Location = new Point(517, 167);
            label79.Name = "label79";
            label79.Size = new Size(45, 15);
            label79.TabIndex = 174;
            label79.Text = "FERRO:";
            // 
            // Ferro
            // 
            Ferro.AutoSize = true;
            Ferro.Location = new Point(571, 77);
            Ferro.Name = "Ferro";
            Ferro.Size = new Size(13, 15);
            Ferro.TabIndex = 179;
            Ferro.Text = "0";
            // 
            // Combustivel
            // 
            Combustivel.AutoSize = true;
            Combustivel.Location = new Point(612, 92);
            Combustivel.Name = "Combustivel";
            Combustivel.Size = new Size(13, 15);
            Combustivel.TabIndex = 180;
            Combustivel.Text = "0";
            // 
            // Alimento
            // 
            Alimento.AutoSize = true;
            Alimento.Location = new Point(593, 107);
            Alimento.Name = "Alimento";
            Alimento.Size = new Size(13, 15);
            Alimento.TabIndex = 181;
            Alimento.Text = "0";
            // 
            // Educacao
            // 
            Educacao.AutoSize = true;
            Educacao.Location = new Point(598, 122);
            Educacao.Name = "Educacao";
            Educacao.Size = new Size(13, 15);
            Educacao.TabIndex = 182;
            Educacao.Text = "0";
            // 
            // Saude
            // 
            Saude.AutoSize = true;
            Saude.Location = new Point(571, 137);
            Saude.Name = "Saude";
            Saude.Size = new Size(13, 15);
            Saude.TabIndex = 183;
            Saude.Text = "0";
            // 
            // FerroPrivado
            // 
            FerroPrivado.AutoSize = true;
            FerroPrivado.Location = new Point(568, 167);
            FerroPrivado.Name = "FerroPrivado";
            FerroPrivado.Size = new Size(13, 15);
            FerroPrivado.TabIndex = 184;
            FerroPrivado.Text = "0";
            // 
            // CombustivelPrivado
            // 
            CombustivelPrivado.AutoSize = true;
            CombustivelPrivado.Location = new Point(608, 181);
            CombustivelPrivado.Name = "CombustivelPrivado";
            CombustivelPrivado.Size = new Size(13, 15);
            CombustivelPrivado.TabIndex = 185;
            CombustivelPrivado.Text = "0";
            // 
            // AlimentoPrivado
            // 
            AlimentoPrivado.AutoSize = true;
            AlimentoPrivado.Location = new Point(590, 197);
            AlimentoPrivado.Name = "AlimentoPrivado";
            AlimentoPrivado.Size = new Size(13, 15);
            AlimentoPrivado.TabIndex = 186;
            AlimentoPrivado.Text = "0";
            // 
            // EducacaoPrivado
            // 
            EducacaoPrivado.AutoSize = true;
            EducacaoPrivado.Location = new Point(595, 212);
            EducacaoPrivado.Name = "EducacaoPrivado";
            EducacaoPrivado.Size = new Size(13, 15);
            EducacaoPrivado.TabIndex = 187;
            EducacaoPrivado.Text = "0";
            // 
            // SaudePrivado
            // 
            SaudePrivado.AutoSize = true;
            SaudePrivado.Location = new Point(571, 227);
            SaudePrivado.Name = "SaudePrivado";
            SaudePrivado.Size = new Size(13, 15);
            SaudePrivado.TabIndex = 188;
            SaudePrivado.Text = "0";
            // 
            // label80
            // 
            label80.AutoSize = true;
            label80.Location = new Point(0, 280);
            label80.Name = "label80";
            label80.Size = new Size(152, 15);
            label80.TabIndex = 189;
            label80.Text = "CESTA DE BENS E SERVIÇOS";
            // 
            // label81
            // 
            label81.AutoSize = true;
            label81.Location = new Point(-1, 303);
            label81.Name = "label81";
            label81.Size = new Size(199, 15);
            label81.TabIndex = 190;
            label81.Text = "Consumo total de Pontos Educação:";
            // 
            // ConsumoPontosEducacao
            // 
            ConsumoPontosEducacao.AutoSize = true;
            ConsumoPontosEducacao.Location = new Point(204, 303);
            ConsumoPontosEducacao.Name = "ConsumoPontosEducacao";
            ConsumoPontosEducacao.Size = new Size(13, 15);
            ConsumoPontosEducacao.TabIndex = 191;
            ConsumoPontosEducacao.Text = "0";
            // 
            // label82
            // 
            label82.BackColor = Color.DimGray;
            label82.Location = new Point(-1, 499);
            label82.Name = "label82";
            label82.Size = new Size(163, 15);
            label82.TabIndex = 192;
            label82.Text = "IN: Inflação  DF: Deflação";
            // 
            // label83
            // 
            label83.AutoSize = true;
            label83.Location = new Point(250, 303);
            label83.Name = "label83";
            label83.Size = new Size(37, 15);
            label83.TabIndex = 193;
            label83.Text = "INPD:";
            // 
            // label84
            // 
            label84.BackColor = Color.DimGray;
            label84.Location = new Point(-4, 514);
            label84.Name = "label84";
            label84.Size = new Size(162, 61);
            label84.TabIndex = 194;
            label84.Text = "INPD: Inflação por Demanda   DFPD: Deflação por Demanda";
            // 
            // InflacaoPontosEducacao
            // 
            InflacaoPontosEducacao.AutoSize = true;
            InflacaoPontosEducacao.Location = new Point(293, 303);
            InflacaoPontosEducacao.Name = "InflacaoPontosEducacao";
            InflacaoPontosEducacao.Size = new Size(13, 15);
            InflacaoPontosEducacao.TabIndex = 195;
            InflacaoPontosEducacao.Text = "0";
            // 
            // DeflacaoPontosEducacao
            // 
            DeflacaoPontosEducacao.AutoSize = true;
            DeflacaoPontosEducacao.Location = new Point(376, 303);
            DeflacaoPontosEducacao.Name = "DeflacaoPontosEducacao";
            DeflacaoPontosEducacao.Size = new Size(13, 15);
            DeflacaoPontosEducacao.TabIndex = 197;
            DeflacaoPontosEducacao.Text = "0";
            // 
            // label87
            // 
            label87.AutoSize = true;
            label87.Location = new Point(333, 303);
            label87.Name = "label87";
            label87.Size = new Size(39, 15);
            label87.TabIndex = 196;
            label87.Text = "DFPD:";
            // 
            // DeflacaoPontosSaude
            // 
            DeflacaoPontosSaude.AutoSize = true;
            DeflacaoPontosSaude.Location = new Point(376, 318);
            DeflacaoPontosSaude.Name = "DeflacaoPontosSaude";
            DeflacaoPontosSaude.Size = new Size(13, 15);
            DeflacaoPontosSaude.TabIndex = 203;
            DeflacaoPontosSaude.Text = "0";
            // 
            // label86
            // 
            label86.AutoSize = true;
            label86.Location = new Point(333, 318);
            label86.Name = "label86";
            label86.Size = new Size(39, 15);
            label86.TabIndex = 202;
            label86.Text = "DFPD:";
            // 
            // InflacaoPontosSaude
            // 
            InflacaoPontosSaude.AutoSize = true;
            InflacaoPontosSaude.Location = new Point(293, 318);
            InflacaoPontosSaude.Name = "InflacaoPontosSaude";
            InflacaoPontosSaude.Size = new Size(13, 15);
            InflacaoPontosSaude.TabIndex = 201;
            InflacaoPontosSaude.Text = "0";
            // 
            // label89
            // 
            label89.AutoSize = true;
            label89.Location = new Point(250, 318);
            label89.Name = "label89";
            label89.Size = new Size(37, 15);
            label89.TabIndex = 200;
            label89.Text = "INPD:";
            // 
            // ConsumoPontosSaude
            // 
            ConsumoPontosSaude.AutoSize = true;
            ConsumoPontosSaude.Location = new Point(204, 318);
            ConsumoPontosSaude.Name = "ConsumoPontosSaude";
            ConsumoPontosSaude.Size = new Size(13, 15);
            ConsumoPontosSaude.TabIndex = 199;
            ConsumoPontosSaude.Text = "0";
            // 
            // label91
            // 
            label91.AutoSize = true;
            label91.Location = new Point(-1, 318);
            label91.Name = "label91";
            label91.Size = new Size(180, 15);
            label91.TabIndex = 198;
            label91.Text = "Consumo total de Pontos Saúde:";
            // 
            // DeflacaoPontosAlimento
            // 
            DeflacaoPontosAlimento.AutoSize = true;
            DeflacaoPontosAlimento.Location = new Point(376, 333);
            DeflacaoPontosAlimento.Name = "DeflacaoPontosAlimento";
            DeflacaoPontosAlimento.Size = new Size(13, 15);
            DeflacaoPontosAlimento.TabIndex = 211;
            DeflacaoPontosAlimento.Text = "0";
            // 
            // label88
            // 
            label88.AutoSize = true;
            label88.Location = new Point(333, 333);
            label88.Name = "label88";
            label88.Size = new Size(39, 15);
            label88.TabIndex = 210;
            label88.Text = "DFPD:";
            // 
            // InflacaoPontosAlimento
            // 
            InflacaoPontosAlimento.AutoSize = true;
            InflacaoPontosAlimento.Location = new Point(293, 333);
            InflacaoPontosAlimento.Name = "InflacaoPontosAlimento";
            InflacaoPontosAlimento.Size = new Size(13, 15);
            InflacaoPontosAlimento.TabIndex = 209;
            InflacaoPontosAlimento.Text = "0";
            // 
            // label92
            // 
            label92.AutoSize = true;
            label92.Location = new Point(250, 333);
            label92.Name = "label92";
            label92.Size = new Size(37, 15);
            label92.TabIndex = 208;
            label92.Text = "INPD:";
            // 
            // ConsumoPontosAlimentos
            // 
            ConsumoPontosAlimentos.AutoSize = true;
            ConsumoPontosAlimentos.Location = new Point(204, 333);
            ConsumoPontosAlimentos.Name = "ConsumoPontosAlimentos";
            ConsumoPontosAlimentos.Size = new Size(13, 15);
            ConsumoPontosAlimentos.TabIndex = 207;
            ConsumoPontosAlimentos.Text = "0";
            // 
            // label94
            // 
            label94.AutoSize = true;
            label94.Location = new Point(-1, 333);
            label94.Name = "label94";
            label94.Size = new Size(162, 15);
            label94.TabIndex = 206;
            label94.Text = "Consumo total de Alimentos:";
            // 
            // MenosConsumoPrivadoEducacao
            // 
            MenosConsumoPrivadoEducacao.BackColor = SystemColors.MenuHighlight;
            MenosConsumoPrivadoEducacao.ForeColor = Color.FromArgb(128, 128, 255);
            MenosConsumoPrivadoEducacao.Location = new Point(412, 305);
            MenosConsumoPrivadoEducacao.Name = "MenosConsumoPrivadoEducacao";
            MenosConsumoPrivadoEducacao.Size = new Size(10, 10);
            MenosConsumoPrivadoEducacao.TabIndex = 212;
            MenosConsumoPrivadoEducacao.Text = "button10";
            MenosConsumoPrivadoEducacao.UseVisualStyleBackColor = false;
            MenosConsumoPrivadoEducacao.Click += MenosConsumoPrivadoEducacao_Click;
            // 
            // MenosConsumoEstatalEducacao
            // 
            MenosConsumoEstatalEducacao.Location = new Point(428, 305);
            MenosConsumoEstatalEducacao.Name = "MenosConsumoEstatalEducacao";
            MenosConsumoEstatalEducacao.Size = new Size(10, 10);
            MenosConsumoEstatalEducacao.TabIndex = 213;
            MenosConsumoEstatalEducacao.Text = "button10";
            MenosConsumoEstatalEducacao.UseVisualStyleBackColor = true;
            MenosConsumoEstatalEducacao.Click += MenosConsumoEstatalEducacao_Click;
            // 
            // MenosConsumoPrivadoSaude
            // 
            MenosConsumoPrivadoSaude.BackColor = SystemColors.MenuHighlight;
            MenosConsumoPrivadoSaude.ForeColor = Color.FromArgb(128, 128, 255);
            MenosConsumoPrivadoSaude.Location = new Point(412, 321);
            MenosConsumoPrivadoSaude.Name = "MenosConsumoPrivadoSaude";
            MenosConsumoPrivadoSaude.Size = new Size(10, 10);
            MenosConsumoPrivadoSaude.TabIndex = 214;
            MenosConsumoPrivadoSaude.Text = "button10";
            MenosConsumoPrivadoSaude.UseVisualStyleBackColor = false;
            MenosConsumoPrivadoSaude.Click += MenosConsumoPrivadoSaude_Click;
            // 
            // MenosConsumoAlimentoEstatal
            // 
            MenosConsumoAlimentoEstatal.Location = new Point(428, 336);
            MenosConsumoAlimentoEstatal.Name = "MenosConsumoAlimentoEstatal";
            MenosConsumoAlimentoEstatal.Size = new Size(10, 10);
            MenosConsumoAlimentoEstatal.TabIndex = 217;
            MenosConsumoAlimentoEstatal.Text = "button10";
            MenosConsumoAlimentoEstatal.UseVisualStyleBackColor = true;
            MenosConsumoAlimentoEstatal.Click += MenosConsumoAlimentoEstatal_Click;
            // 
            // MenosConsumoPrivadoAlimentos
            // 
            MenosConsumoPrivadoAlimentos.BackColor = SystemColors.MenuHighlight;
            MenosConsumoPrivadoAlimentos.ForeColor = Color.FromArgb(128, 128, 255);
            MenosConsumoPrivadoAlimentos.Location = new Point(412, 336);
            MenosConsumoPrivadoAlimentos.Name = "MenosConsumoPrivadoAlimentos";
            MenosConsumoPrivadoAlimentos.Size = new Size(10, 10);
            MenosConsumoPrivadoAlimentos.TabIndex = 216;
            MenosConsumoPrivadoAlimentos.Text = "button10";
            MenosConsumoPrivadoAlimentos.UseVisualStyleBackColor = false;
            MenosConsumoPrivadoAlimentos.Click += MenosConsumoPrivadoAlimentos_Click;
            // 
            // MenosConsumoPrivadoCombustivel
            // 
            MenosConsumoPrivadoCombustivel.BackColor = SystemColors.MenuHighlight;
            MenosConsumoPrivadoCombustivel.ForeColor = Color.FromArgb(128, 128, 255);
            MenosConsumoPrivadoCombustivel.Location = new Point(412, 351);
            MenosConsumoPrivadoCombustivel.Name = "MenosConsumoPrivadoCombustivel";
            MenosConsumoPrivadoCombustivel.Size = new Size(10, 10);
            MenosConsumoPrivadoCombustivel.TabIndex = 224;
            MenosConsumoPrivadoCombustivel.Text = "button12";
            MenosConsumoPrivadoCombustivel.UseVisualStyleBackColor = false;
            MenosConsumoPrivadoCombustivel.Click += MenosConsumoPrivadoCombustivel_Click;
            // 
            // DeflacaoPontosCombustivel
            // 
            DeflacaoPontosCombustivel.AutoSize = true;
            DeflacaoPontosCombustivel.Location = new Point(376, 348);
            DeflacaoPontosCombustivel.Name = "DeflacaoPontosCombustivel";
            DeflacaoPontosCombustivel.Size = new Size(13, 15);
            DeflacaoPontosCombustivel.TabIndex = 223;
            DeflacaoPontosCombustivel.Text = "0";
            // 
            // label90
            // 
            label90.AutoSize = true;
            label90.Location = new Point(333, 348);
            label90.Name = "label90";
            label90.Size = new Size(39, 15);
            label90.TabIndex = 222;
            label90.Text = "DFPD:";
            // 
            // InflacaoPontosCombustivel
            // 
            InflacaoPontosCombustivel.AutoSize = true;
            InflacaoPontosCombustivel.Location = new Point(294, 348);
            InflacaoPontosCombustivel.Name = "InflacaoPontosCombustivel";
            InflacaoPontosCombustivel.Size = new Size(13, 15);
            InflacaoPontosCombustivel.TabIndex = 221;
            InflacaoPontosCombustivel.Text = "0";
            // 
            // label95
            // 
            label95.AutoSize = true;
            label95.Location = new Point(250, 348);
            label95.Name = "label95";
            label95.Size = new Size(37, 15);
            label95.TabIndex = 220;
            label95.Text = "INPD:";
            // 
            // ConsumoPontosCombustivel
            // 
            ConsumoPontosCombustivel.AutoSize = true;
            ConsumoPontosCombustivel.Location = new Point(204, 348);
            ConsumoPontosCombustivel.Name = "ConsumoPontosCombustivel";
            ConsumoPontosCombustivel.Size = new Size(13, 15);
            ConsumoPontosCombustivel.TabIndex = 219;
            ConsumoPontosCombustivel.Text = "0";
            // 
            // label97
            // 
            label97.AutoSize = true;
            label97.Location = new Point(-1, 348);
            label97.Name = "label97";
            label97.Size = new Size(175, 15);
            label97.TabIndex = 218;
            label97.Text = "Consumo total de Combustivel:";
            // 
            // MenosConsumoFerroEstatal
            // 
            MenosConsumoFerroEstatal.Location = new Point(428, 366);
            MenosConsumoFerroEstatal.Name = "MenosConsumoFerroEstatal";
            MenosConsumoFerroEstatal.Size = new Size(10, 10);
            MenosConsumoFerroEstatal.TabIndex = 233;
            MenosConsumoFerroEstatal.Text = "button10";
            MenosConsumoFerroEstatal.UseVisualStyleBackColor = true;
            MenosConsumoFerroEstatal.Click += MenosConsumoFerroEstatal_Click;
            // 
            // MenosConsumoFerroPrivado
            // 
            MenosConsumoFerroPrivado.BackColor = SystemColors.MenuHighlight;
            MenosConsumoFerroPrivado.ForeColor = Color.FromArgb(128, 128, 255);
            MenosConsumoFerroPrivado.Location = new Point(412, 366);
            MenosConsumoFerroPrivado.Name = "MenosConsumoFerroPrivado";
            MenosConsumoFerroPrivado.Size = new Size(10, 10);
            MenosConsumoFerroPrivado.TabIndex = 232;
            MenosConsumoFerroPrivado.Text = "button14";
            MenosConsumoFerroPrivado.UseVisualStyleBackColor = false;
            MenosConsumoFerroPrivado.Click += MenosConsumoFerroPrivado_Click;
            // 
            // DeflacaoPontosFerro
            // 
            DeflacaoPontosFerro.AutoSize = true;
            DeflacaoPontosFerro.Location = new Point(376, 363);
            DeflacaoPontosFerro.Name = "DeflacaoPontosFerro";
            DeflacaoPontosFerro.Size = new Size(13, 15);
            DeflacaoPontosFerro.TabIndex = 231;
            DeflacaoPontosFerro.Text = "0";
            // 
            // label93
            // 
            label93.AutoSize = true;
            label93.Location = new Point(333, 363);
            label93.Name = "label93";
            label93.Size = new Size(39, 15);
            label93.TabIndex = 230;
            label93.Text = "DFPD:";
            // 
            // InflacaoPontosFerro
            // 
            InflacaoPontosFerro.AutoSize = true;
            InflacaoPontosFerro.Location = new Point(294, 363);
            InflacaoPontosFerro.Name = "InflacaoPontosFerro";
            InflacaoPontosFerro.Size = new Size(13, 15);
            InflacaoPontosFerro.TabIndex = 229;
            InflacaoPontosFerro.Text = "0";
            // 
            // label98
            // 
            label98.AutoSize = true;
            label98.Location = new Point(250, 363);
            label98.Name = "label98";
            label98.Size = new Size(37, 15);
            label98.TabIndex = 228;
            label98.Text = "INPD:";
            // 
            // ConsumoPontosFerro
            // 
            ConsumoPontosFerro.AutoSize = true;
            ConsumoPontosFerro.Location = new Point(204, 363);
            ConsumoPontosFerro.Name = "ConsumoPontosFerro";
            ConsumoPontosFerro.Size = new Size(13, 15);
            ConsumoPontosFerro.TabIndex = 227;
            ConsumoPontosFerro.Text = "0";
            // 
            // label100
            // 
            label100.AutoSize = true;
            label100.Location = new Point(-1, 363);
            label100.Name = "label100";
            label100.Size = new Size(135, 15);
            label100.TabIndex = 226;
            label100.Text = "Consumo total de Ferro:";
            // 
            // SubtracaoConsumo
            // 
            SubtracaoConsumo.Location = new Point(304, 277);
            SubtracaoConsumo.Name = "SubtracaoConsumo";
            SubtracaoConsumo.Size = new Size(63, 23);
            SubtracaoConsumo.TabIndex = 234;
            SubtracaoConsumo.TextChanged += SubtracaoConsumo_TextChanged;
            // 
            // PainelDeControle
            // 
            PainelDeControle.Controls.Add(tabPage1);
            PainelDeControle.Controls.Add(tabPage2);
            PainelDeControle.Controls.Add(tabPage3);
            PainelDeControle.Controls.Add(tabPage4);
            PainelDeControle.Location = new Point(1, 3);
            PainelDeControle.Name = "PainelDeControle";
            PainelDeControle.SelectedIndex = 0;
            PainelDeControle.Size = new Size(670, 603);
            PainelDeControle.TabIndex = 236;
            PainelDeControle.Tag = "Saude";
            // 
            // tabPage1
            // 
            tabPage1.AccessibleName = "";
            tabPage1.BackColor = Color.Silver;
            tabPage1.Controls.Add(label78);
            tabPage1.Controls.Add(label70);
            tabPage1.Controls.Add(label75);
            tabPage1.Controls.Add(Painel);
            tabPage1.Controls.Add(label76);
            tabPage1.Controls.Add(Ferro);
            tabPage1.Controls.Add(label77);
            tabPage1.Controls.Add(demandaagregada);
            tabPage1.Controls.Add(label79);
            tabPage1.Controls.Add(Combustivel);
            tabPage1.Controls.Add(label74);
            tabPage1.Controls.Add(FerroPrivado);
            tabPage1.Controls.Add(label119);
            tabPage1.Controls.Add(CombustivelPrivado);
            tabPage1.Controls.Add(Alimento);
            tabPage1.Controls.Add(AlimentoPrivado);
            tabPage1.Controls.Add(TaxaDesemprego);
            tabPage1.Controls.Add(EducacaoPrivado);
            tabPage1.Controls.Add(Educacao);
            tabPage1.Controls.Add(SaudePrivado);
            tabPage1.Controls.Add(label117);
            tabPage1.Controls.Add(Saude);
            tabPage1.Controls.Add(SalarioMinimoNecessario);
            tabPage1.Controls.Add(label73);
            tabPage1.Controls.Add(label116);
            tabPage1.Controls.Add(label72);
            tabPage1.Controls.Add(MenosTodosEstatal);
            tabPage1.Controls.Add(label71);
            tabPage1.Controls.Add(MenosConsumoTodos);
            tabPage1.Controls.Add(label69);
            tabPage1.Controls.Add(DEFLACAOAGREGADAPORCENTAGEM);
            tabPage1.Controls.Add(label63);
            tabPage1.Controls.Add(INFLACAAGREGADAPORCENTAGEM);
            tabPage1.Controls.Add(label109);
            tabPage1.Controls.Add(label102);
            tabPage1.Controls.Add(MenosConsumoCombustivelEstatal);
            tabPage1.Controls.Add(MnosConsumoSaudeEstatal);
            tabPage1.Controls.Add(PoderDeCompra);
            tabPage1.Controls.Add(PIBNOMINALPORCENTAGEM);
            tabPage1.Controls.Add(label113);
            tabPage1.Controls.Add(PIBREALPORCENTAGEM);
            tabPage1.Controls.Add(label111);
            tabPage1.Controls.Add(PIBREAL);
            tabPage1.Controls.Add(label112);
            tabPage1.Controls.Add(ProdutoInternoBruto);
            tabPage1.Controls.Add(label110);
            tabPage1.Controls.Add(label108);
            tabPage1.Controls.Add(DEFLACAOAGREGADA);
            tabPage1.Controls.Add(label107);
            tabPage1.Controls.Add(SalarioMedioNacional);
            tabPage1.Controls.Add(label104);
            tabPage1.Controls.Add(label106);
            tabPage1.Controls.Add(DeflacaoDeCustos);
            tabPage1.Controls.Add(label105);
            tabPage1.Controls.Add(InflacaoDeCustos);
            tabPage1.Controls.Add(label103);
            tabPage1.Controls.Add(INFLACAOAGREGADA);
            tabPage1.Controls.Add(label101);
            tabPage1.Controls.Add(label99);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(label84);
            tabPage1.Controls.Add(label82);
            tabPage1.Controls.Add(SubtracaoConsumo);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(MenosConsumoFerroEstatal);
            tabPage1.Controls.Add(MenosConsumoFerroPrivado);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(DeflacaoPontosFerro);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label93);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(InflacaoPontosFerro);
            tabPage1.Controls.Add(label98);
            tabPage1.Controls.Add(ConsumoPontosFerro);
            tabPage1.Controls.Add(button5);
            tabPage1.Controls.Add(label100);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(MenosConsumoPrivadoCombustivel);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(DeflacaoPontosCombustivel);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(label90);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(InflacaoPontosCombustivel);
            tabPage1.Controls.Add(label44);
            tabPage1.Controls.Add(label95);
            tabPage1.Controls.Add(INDF);
            tabPage1.Controls.Add(ConsumoPontosCombustivel);
            tabPage1.Controls.Add(label46);
            tabPage1.Controls.Add(label97);
            tabPage1.Controls.Add(label47);
            tabPage1.Controls.Add(MenosConsumoAlimentoEstatal);
            tabPage1.Controls.Add(IN);
            tabPage1.Controls.Add(MenosConsumoPrivadoAlimentos);
            tabPage1.Controls.Add(DF);
            tabPage1.Controls.Add(label43);
            tabPage1.Controls.Add(MenosConsumoPrivadoSaude);
            tabPage1.Controls.Add(QDP);
            tabPage1.Controls.Add(MenosConsumoEstatalEducacao);
            tabPage1.Controls.Add(MenosConsumoPrivadoEducacao);
            tabPage1.Controls.Add(DeflacaoPontosAlimento);
            tabPage1.Controls.Add(label88);
            tabPage1.Controls.Add(InflacaoPontosAlimento);
            tabPage1.Controls.Add(label92);
            tabPage1.Controls.Add(ConsumoPontosAlimentos);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label94);
            tabPage1.Controls.Add(DeflacaoPontosSaude);
            tabPage1.Controls.Add(label86);
            tabPage1.Controls.Add(InflacaoPontosSaude);
            tabPage1.Controls.Add(label89);
            tabPage1.Controls.Add(ConsumoPontosSaude);
            tabPage1.Controls.Add(label91);
            tabPage1.Controls.Add(DeflacaoPontosEducacao);
            tabPage1.Controls.Add(label87);
            tabPage1.Controls.Add(InflacaoPontosEducacao);
            tabPage1.Controls.Add(label83);
            tabPage1.Controls.Add(label64);
            tabPage1.Controls.Add(SalarioMinimoEsperado);
            tabPage1.Controls.Add(ConsumoPontosEducacao);
            tabPage1.Controls.Add(label81);
            tabPage1.Controls.Add(label80);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(662, 575);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "PAINEL DE CONTROLE";
            tabPage1.Click += tabPage1_Click;
            // 
            // Painel
            // 
            Painel.Controls.Add(tabPage6);
            Painel.Controls.Add(tabPage5);
            Painel.Controls.Add(tabPage7);
            Painel.Location = new Point(3, 56);
            Painel.Name = "Painel";
            Painel.SelectedIndex = 0;
            Painel.Size = new Size(492, 201);
            Painel.TabIndex = 277;
            // 
            // tabPage6
            // 
            tabPage6.BackColor = Color.GreenYellow;
            tabPage6.Controls.Add(button4);
            tabPage6.Controls.Add(label58);
            tabPage6.Controls.Add(TaxaSelic);
            tabPage6.Controls.Add(MaisCredito);
            tabPage6.Controls.Add(label56);
            tabPage6.Controls.Add(CreditoNacional);
            tabPage6.Controls.Add(ELIMINAR);
            tabPage6.Controls.Add(label6);
            tabPage6.Controls.Add(Taxa);
            tabPage6.Controls.Add(button3);
            tabPage6.Controls.Add(button1);
            tabPage6.Controls.Add(Administração);
            tabPage6.Controls.Add(label60);
            tabPage6.Controls.Add(TitulosPublicos);
            tabPage6.Controls.Add(BuyTitulos);
            tabPage6.Controls.Add(label62);
            tabPage6.Controls.Add(label115);
            tabPage6.Controls.Add(PrecoCompraTitulos);
            tabPage6.Controls.Add(label114);
            tabPage6.Controls.Add(PrecoVendaTitulos);
            tabPage6.Controls.Add(label61);
            tabPage6.Controls.Add(TitulosMoney);
            tabPage6.Controls.Add(AdministracaoAvancada);
            tabPage6.Controls.Add(EmprestimosPorBanco);
            tabPage6.Controls.Add(TotalCredito);
            tabPage6.Location = new Point(4, 24);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(484, 173);
            tabPage6.TabIndex = 1;
            tabPage6.Text = "Banco Central";
            // 
            // label115
            // 
            label115.AutoSize = true;
            label115.Location = new Point(208, 132);
            label115.Name = "label115";
            label115.Size = new Size(157, 15);
            label115.TabIndex = 260;
            label115.Text = "Crédito Nacional Disponível:";
            // 
            // label114
            // 
            label114.AutoSize = true;
            label114.Location = new Point(207, 115);
            label114.Name = "label114";
            label114.Size = new Size(136, 15);
            label114.TabIndex = 259;
            label114.Text = "Empréstimos por Banco:";
            // 
            // tabPage5
            // 
            tabPage5.BackColor = Color.GreenYellow;
            tabPage5.Controls.Add(TaxaFerro);
            tabPage5.Controls.Add(label128);
            tabPage5.Controls.Add(TaxaCombustivel);
            tabPage5.Controls.Add(label127);
            tabPage5.Controls.Add(TaxaAgricultura);
            tabPage5.Controls.Add(label122);
            tabPage5.Controls.Add(TaxaSaude);
            tabPage5.Controls.Add(TaxaEducacao);
            tabPage5.Controls.Add(label121);
            tabPage5.Controls.Add(label120);
            tabPage5.Controls.Add(label118);
            tabPage5.Location = new Point(4, 24);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(484, 173);
            tabPage5.TabIndex = 0;
            tabPage5.Text = "Impostos";
            tabPage5.Click += tabPage5_Click;
            // 
            // TaxaFerro
            // 
            TaxaFerro.Location = new Point(122, 144);
            TaxaFerro.Name = "TaxaFerro";
            TaxaFerro.Size = new Size(41, 23);
            TaxaFerro.TabIndex = 18;
            // 
            // label128
            // 
            label128.AutoSize = true;
            label128.Location = new Point(3, 147);
            label128.Name = "label128";
            label128.Size = new Size(116, 15);
            label128.TabIndex = 17;
            label128.Text = "Imposto sobre Ferro:";
            // 
            // TaxaCombustivel
            // 
            TaxaCombustivel.Location = new Point(159, 115);
            TaxaCombustivel.Name = "TaxaCombustivel";
            TaxaCombustivel.Size = new Size(41, 23);
            TaxaCombustivel.TabIndex = 16;
            // 
            // label127
            // 
            label127.AutoSize = true;
            label127.Location = new Point(0, 117);
            label127.Name = "label127";
            label127.Size = new Size(156, 15);
            label127.TabIndex = 15;
            label127.Text = "Imposto sobre Combustivel:";
            // 
            // TaxaAgricultura
            // 
            TaxaAgricultura.Location = new Point(149, 86);
            TaxaAgricultura.Name = "TaxaAgricultura";
            TaxaAgricultura.Size = new Size(41, 23);
            TaxaAgricultura.TabIndex = 9;
            // 
            // label122
            // 
            label122.AutoSize = true;
            label122.Location = new Point(0, 87);
            label122.Name = "label122";
            label122.Size = new Size(148, 15);
            label122.TabIndex = 8;
            label122.Text = "Imposto sobre Agricultura:";
            // 
            // TaxaSaude
            // 
            TaxaSaude.Location = new Point(130, 57);
            TaxaSaude.Name = "TaxaSaude";
            TaxaSaude.Size = new Size(41, 23);
            TaxaSaude.TabIndex = 5;
            // 
            // TaxaEducacao
            // 
            TaxaEducacao.Location = new Point(149, 28);
            TaxaEducacao.Name = "TaxaEducacao";
            TaxaEducacao.Size = new Size(41, 23);
            TaxaEducacao.TabIndex = 4;
            // 
            // label121
            // 
            label121.AutoSize = true;
            label121.Location = new Point(0, 61);
            label121.Name = "label121";
            label121.Size = new Size(130, 15);
            label121.TabIndex = 3;
            label121.Text = "Imposto sobre a Saude:";
            // 
            // label120
            // 
            label120.AutoSize = true;
            label120.Location = new Point(-1, 31);
            label120.Name = "label120";
            label120.Size = new Size(149, 15);
            label120.TabIndex = 1;
            label120.Text = "Imposto sobre a Educação:";
            // 
            // label118
            // 
            label118.AutoSize = true;
            label118.Location = new Point(0, 3);
            label118.Name = "label118";
            label118.Size = new Size(122, 15);
            label118.TabIndex = 0;
            label118.Text = "IMPOSTOS INDIRETOS";
            // 
            // tabPage7
            // 
            tabPage7.BackColor = Color.GreenYellow;
            tabPage7.Controls.Add(label131);
            tabPage7.Controls.Add(label132);
            tabPage7.Controls.Add(SetorAgriculturaEstatal);
            tabPage7.Controls.Add(SetorFerroEstatal);
            tabPage7.Controls.Add(label135);
            tabPage7.Controls.Add(label136);
            tabPage7.Controls.Add(label137);
            tabPage7.Controls.Add(SetorSaudeEstatal);
            tabPage7.Controls.Add(SetorEducacaoEstatal);
            tabPage7.Controls.Add(SetorCombustivelEstatal);
            tabPage7.Controls.Add(label141);
            tabPage7.Controls.Add(label130);
            tabPage7.Controls.Add(label123);
            tabPage7.Controls.Add(SetorAgriculturaPrivado);
            tabPage7.Controls.Add(SetorFerroPrivado);
            tabPage7.Controls.Add(label126);
            tabPage7.Controls.Add(label124);
            tabPage7.Controls.Add(label129);
            tabPage7.Controls.Add(SetorSaudePrivado);
            tabPage7.Controls.Add(SetorEducacaoPrivado);
            tabPage7.Controls.Add(SetorCombustivelPrivado);
            tabPage7.Controls.Add(label125);
            tabPage7.Location = new Point(4, 24);
            tabPage7.Name = "tabPage7";
            tabPage7.Size = new Size(484, 173);
            tabPage7.TabIndex = 2;
            tabPage7.Text = "Mercado";
            // 
            // label131
            // 
            label131.AutoSize = true;
            label131.Location = new Point(323, 152);
            label131.Name = "label131";
            label131.Size = new Size(67, 15);
            label131.TabIndex = 33;
            label131.Text = "Setor Ferro:";
            // 
            // label132
            // 
            label132.Location = new Point(243, 0);
            label132.Name = "label132";
            label132.Size = new Size(245, 33);
            label132.TabIndex = 25;
            label132.Text = "DINHEIRO MOVIMENTADO POR CADA SETOR ESTATAL";
            label132.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SetorAgriculturaEstatal
            // 
            SetorAgriculturaEstatal.AutoSize = true;
            SetorAgriculturaEstatal.Location = new Point(425, 95);
            SetorAgriculturaEstatal.Name = "SetorAgriculturaEstatal";
            SetorAgriculturaEstatal.Size = new Size(13, 15);
            SetorAgriculturaEstatal.TabIndex = 28;
            SetorAgriculturaEstatal.Text = "0";
            // 
            // SetorFerroEstatal
            // 
            SetorFerroEstatal.AutoSize = true;
            SetorFerroEstatal.Location = new Point(436, 152);
            SetorFerroEstatal.Name = "SetorFerroEstatal";
            SetorFerroEstatal.Size = new Size(13, 15);
            SetorFerroEstatal.TabIndex = 32;
            SetorFerroEstatal.Text = "0";
            // 
            // label135
            // 
            label135.AutoSize = true;
            label135.Location = new Point(321, 95);
            label135.Name = "label135";
            label135.Size = new Size(99, 15);
            label135.TabIndex = 29;
            label135.Text = "Setor Agricultura:";
            // 
            // label136
            // 
            label136.AutoSize = true;
            label136.Location = new Point(320, 38);
            label136.Name = "label136";
            label136.Size = new Size(91, 15);
            label136.TabIndex = 26;
            label136.Text = "Setor Educação:";
            // 
            // label137
            // 
            label137.AutoSize = true;
            label137.Location = new Point(323, 123);
            label137.Name = "label137";
            label137.Size = new Size(107, 15);
            label137.TabIndex = 31;
            label137.Text = "Setor Combustivel:";
            // 
            // SetorSaudeEstatal
            // 
            SetorSaudeEstatal.AutoSize = true;
            SetorSaudeEstatal.Location = new Point(425, 67);
            SetorSaudeEstatal.Name = "SetorSaudeEstatal";
            SetorSaudeEstatal.Size = new Size(13, 15);
            SetorSaudeEstatal.TabIndex = 24;
            SetorSaudeEstatal.Text = "0";
            // 
            // SetorEducacaoEstatal
            // 
            SetorEducacaoEstatal.AutoSize = true;
            SetorEducacaoEstatal.Location = new Point(425, 38);
            SetorEducacaoEstatal.Name = "SetorEducacaoEstatal";
            SetorEducacaoEstatal.Size = new Size(13, 15);
            SetorEducacaoEstatal.TabIndex = 23;
            SetorEducacaoEstatal.Text = "0";
            // 
            // SetorCombustivelEstatal
            // 
            SetorCombustivelEstatal.AutoSize = true;
            SetorCombustivelEstatal.Location = new Point(436, 123);
            SetorCombustivelEstatal.Name = "SetorCombustivelEstatal";
            SetorCombustivelEstatal.Size = new Size(13, 15);
            SetorCombustivelEstatal.TabIndex = 30;
            SetorCombustivelEstatal.Text = "0";
            // 
            // label141
            // 
            label141.AutoSize = true;
            label141.Location = new Point(321, 67);
            label141.Name = "label141";
            label141.Size = new Size(72, 15);
            label141.TabIndex = 27;
            label141.Text = "Setor Saude:";
            // 
            // label130
            // 
            label130.AutoSize = true;
            label130.Location = new Point(69, 152);
            label130.Name = "label130";
            label130.Size = new Size(67, 15);
            label130.TabIndex = 22;
            label130.Text = "Setor Ferro:";
            // 
            // label123
            // 
            label123.Location = new Point(-11, 0);
            label123.Name = "label123";
            label123.Size = new Size(237, 33);
            label123.TabIndex = 10;
            label123.Text = "DINHEIRO MOVIMENTADO POR CADA SETOR PRIVADO";
            label123.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SetorAgriculturaPrivado
            // 
            SetorAgriculturaPrivado.AutoSize = true;
            SetorAgriculturaPrivado.Location = new Point(171, 95);
            SetorAgriculturaPrivado.Name = "SetorAgriculturaPrivado";
            SetorAgriculturaPrivado.Size = new Size(13, 15);
            SetorAgriculturaPrivado.TabIndex = 13;
            SetorAgriculturaPrivado.Text = "0";
            // 
            // SetorFerroPrivado
            // 
            SetorFerroPrivado.AutoSize = true;
            SetorFerroPrivado.Location = new Point(182, 152);
            SetorFerroPrivado.Name = "SetorFerroPrivado";
            SetorFerroPrivado.Size = new Size(13, 15);
            SetorFerroPrivado.TabIndex = 21;
            SetorFerroPrivado.Text = "0";
            // 
            // label126
            // 
            label126.AutoSize = true;
            label126.Location = new Point(67, 95);
            label126.Name = "label126";
            label126.Size = new Size(99, 15);
            label126.TabIndex = 14;
            label126.Text = "Setor Agricultura:";
            // 
            // label124
            // 
            label124.AutoSize = true;
            label124.Location = new Point(66, 38);
            label124.Name = "label124";
            label124.Size = new Size(91, 15);
            label124.TabIndex = 11;
            label124.Text = "Setor Educação:";
            // 
            // label129
            // 
            label129.AutoSize = true;
            label129.Location = new Point(69, 123);
            label129.Name = "label129";
            label129.Size = new Size(107, 15);
            label129.TabIndex = 20;
            label129.Text = "Setor Combustivel:";
            // 
            // SetorSaudePrivado
            // 
            SetorSaudePrivado.AutoSize = true;
            SetorSaudePrivado.Location = new Point(171, 67);
            SetorSaudePrivado.Name = "SetorSaudePrivado";
            SetorSaudePrivado.Size = new Size(13, 15);
            SetorSaudePrivado.TabIndex = 7;
            SetorSaudePrivado.Text = "0";
            // 
            // SetorEducacaoPrivado
            // 
            SetorEducacaoPrivado.AutoSize = true;
            SetorEducacaoPrivado.Location = new Point(171, 38);
            SetorEducacaoPrivado.Name = "SetorEducacaoPrivado";
            SetorEducacaoPrivado.Size = new Size(13, 15);
            SetorEducacaoPrivado.TabIndex = 6;
            SetorEducacaoPrivado.Text = "0";
            // 
            // SetorCombustivelPrivado
            // 
            SetorCombustivelPrivado.AutoSize = true;
            SetorCombustivelPrivado.Location = new Point(182, 123);
            SetorCombustivelPrivado.Name = "SetorCombustivelPrivado";
            SetorCombustivelPrivado.Size = new Size(13, 15);
            SetorCombustivelPrivado.TabIndex = 19;
            SetorCombustivelPrivado.Text = "0";
            SetorCombustivelPrivado.Click += label130_Click;
            // 
            // label125
            // 
            label125.AutoSize = true;
            label125.Location = new Point(67, 67);
            label125.Name = "label125";
            label125.Size = new Size(72, 15);
            label125.TabIndex = 12;
            label125.Text = "Setor Saude:";
            // 
            // demandaagregada
            // 
            demandaagregada.AutoSize = true;
            demandaagregada.Location = new Point(381, 454);
            demandaagregada.Name = "demandaagregada";
            demandaagregada.Size = new Size(13, 15);
            demandaagregada.TabIndex = 276;
            demandaagregada.Text = "0";
            // 
            // label119
            // 
            label119.AutoSize = true;
            label119.Location = new Point(267, 454);
            label119.Name = "label119";
            label119.Size = new Size(115, 15);
            label119.TabIndex = 275;
            label119.Text = "Demanda Agregada:";
            // 
            // TaxaDesemprego
            // 
            TaxaDesemprego.AutoSize = true;
            TaxaDesemprego.Location = new Point(126, 468);
            TaxaDesemprego.Name = "TaxaDesemprego";
            TaxaDesemprego.Size = new Size(13, 15);
            TaxaDesemprego.TabIndex = 274;
            TaxaDesemprego.Text = "0";
            // 
            // label117
            // 
            label117.AutoSize = true;
            label117.Location = new Point(3, 468);
            label117.Name = "label117";
            label117.Size = new Size(122, 15);
            label117.TabIndex = 273;
            label117.Text = "Taxa de Desemprego: ";
            // 
            // SalarioMinimoNecessario
            // 
            SalarioMinimoNecessario.AutoSize = true;
            SalarioMinimoNecessario.Location = new Point(157, 453);
            SalarioMinimoNecessario.Name = "SalarioMinimoNecessario";
            SalarioMinimoNecessario.Size = new Size(13, 15);
            SalarioMinimoNecessario.TabIndex = 272;
            SalarioMinimoNecessario.Text = "0";
            // 
            // label116
            // 
            label116.AutoSize = true;
            label116.Location = new Point(3, 453);
            label116.Name = "label116";
            label116.Size = new Size(150, 15);
            label116.TabIndex = 271;
            label116.Text = "Salário Minímo Necessário:";
            // 
            // MenosTodosEstatal
            // 
            MenosTodosEstatal.AutoSize = true;
            MenosTodosEstatal.BackColor = Color.Transparent;
            MenosTodosEstatal.Location = new Point(426, 285);
            MenosTodosEstatal.Name = "MenosTodosEstatal";
            MenosTodosEstatal.Size = new Size(15, 14);
            MenosTodosEstatal.TabIndex = 270;
            MenosTodosEstatal.UseVisualStyleBackColor = false;
            MenosTodosEstatal.CheckedChanged += MenosTodosEstatal_CheckedChanged;
            // 
            // MenosConsumoTodos
            // 
            MenosConsumoTodos.AutoSize = true;
            MenosConsumoTodos.BackColor = Color.Transparent;
            MenosConsumoTodos.Location = new Point(410, 285);
            MenosConsumoTodos.Name = "MenosConsumoTodos";
            MenosConsumoTodos.Size = new Size(15, 14);
            MenosConsumoTodos.TabIndex = 269;
            MenosConsumoTodos.UseVisualStyleBackColor = false;
            // 
            // DEFLACAOAGREGADAPORCENTAGEM
            // 
            DEFLACAOAGREGADAPORCENTAGEM.AutoSize = true;
            DEFLACAOAGREGADAPORCENTAGEM.Location = new Point(622, 423);
            DEFLACAOAGREGADAPORCENTAGEM.Name = "DEFLACAOAGREGADAPORCENTAGEM";
            DEFLACAOAGREGADAPORCENTAGEM.Size = new Size(13, 15);
            DEFLACAOAGREGADAPORCENTAGEM.TabIndex = 268;
            DEFLACAOAGREGADAPORCENTAGEM.Text = "0";
            DEFLACAOAGREGADAPORCENTAGEM.Click += DEFLACAOAGREGADAPORCENTAGEM_Click;
            // 
            // INFLACAAGREGADAPORCENTAGEM
            // 
            INFLACAAGREGADAPORCENTAGEM.AutoSize = true;
            INFLACAAGREGADAPORCENTAGEM.Location = new Point(621, 407);
            INFLACAAGREGADAPORCENTAGEM.Name = "INFLACAAGREGADAPORCENTAGEM";
            INFLACAAGREGADAPORCENTAGEM.Size = new Size(13, 15);
            INFLACAAGREGADAPORCENTAGEM.TabIndex = 267;
            INFLACAAGREGADAPORCENTAGEM.Text = "0";
            // 
            // label109
            // 
            label109.AutoSize = true;
            label109.Location = new Point(471, 423);
            label109.Name = "label109";
            label109.Size = new Size(148, 15);
            label109.TabIndex = 266;
            label109.Text = "DEFLAÇÃO AGREGADA(p):";
            label109.Click += label109_Click;
            // 
            // label102
            // 
            label102.AutoSize = true;
            label102.Location = new Point(470, 406);
            label102.Name = "label102";
            label102.Size = new Size(149, 15);
            label102.TabIndex = 265;
            label102.Text = "INFLAÇÃO AGREGADA(p): ";
            label102.Click += label102_Click;
            // 
            // MenosConsumoCombustivelEstatal
            // 
            MenosConsumoCombustivelEstatal.Location = new Point(428, 351);
            MenosConsumoCombustivelEstatal.Name = "MenosConsumoCombustivelEstatal";
            MenosConsumoCombustivelEstatal.Size = new Size(10, 10);
            MenosConsumoCombustivelEstatal.TabIndex = 264;
            MenosConsumoCombustivelEstatal.Text = "button10";
            MenosConsumoCombustivelEstatal.UseVisualStyleBackColor = true;
            MenosConsumoCombustivelEstatal.Click += MenosConsumoCombustivelEstatal_Click;
            // 
            // MnosConsumoSaudeEstatal
            // 
            MnosConsumoSaudeEstatal.Location = new Point(428, 321);
            MnosConsumoSaudeEstatal.Name = "MnosConsumoSaudeEstatal";
            MnosConsumoSaudeEstatal.Size = new Size(10, 10);
            MnosConsumoSaudeEstatal.TabIndex = 263;
            MnosConsumoSaudeEstatal.Text = "button10";
            MnosConsumoSaudeEstatal.UseVisualStyleBackColor = true;
            MnosConsumoSaudeEstatal.Click += MnosConsumoSaudeEstatal_Click;
            // 
            // PoderDeCompra
            // 
            PoderDeCompra.AutoSize = true;
            PoderDeCompra.Location = new Point(194, 392);
            PoderDeCompra.Name = "PoderDeCompra";
            PoderDeCompra.Size = new Size(13, 15);
            PoderDeCompra.TabIndex = 261;
            PoderDeCompra.Text = "0";
            // 
            // PIBNOMINALPORCENTAGEM
            // 
            PIBNOMINALPORCENTAGEM.AutoSize = true;
            PIBNOMINALPORCENTAGEM.Location = new Point(622, 453);
            PIBNOMINALPORCENTAGEM.Name = "PIBNOMINALPORCENTAGEM";
            PIBNOMINALPORCENTAGEM.Size = new Size(13, 15);
            PIBNOMINALPORCENTAGEM.TabIndex = 258;
            PIBNOMINALPORCENTAGEM.Text = "0";
            // 
            // label113
            // 
            label113.AutoSize = true;
            label113.Location = new Point(470, 453);
            label113.Name = "label113";
            label113.Size = new Size(85, 15);
            label113.TabIndex = 257;
            label113.Text = "PIB NOMINAL:";
            // 
            // PIBREALPORCENTAGEM
            // 
            PIBREALPORCENTAGEM.AutoSize = true;
            PIBREALPORCENTAGEM.Location = new Point(622, 483);
            PIBREALPORCENTAGEM.Name = "PIBREALPORCENTAGEM";
            PIBREALPORCENTAGEM.Size = new Size(13, 15);
            PIBREALPORCENTAGEM.TabIndex = 256;
            PIBREALPORCENTAGEM.Text = "0";
            // 
            // label111
            // 
            label111.AutoSize = true;
            label111.Location = new Point(470, 483);
            label111.Name = "label111";
            label111.Size = new Size(57, 15);
            label111.TabIndex = 255;
            label111.Text = "PIB REAL:";
            // 
            // PIBREAL
            // 
            PIBREAL.AutoSize = true;
            PIBREAL.Location = new Point(622, 468);
            PIBREAL.Name = "PIBREAL";
            PIBREAL.Size = new Size(13, 15);
            PIBREAL.TabIndex = 254;
            PIBREAL.Text = "0";
            // 
            // label112
            // 
            label112.AutoSize = true;
            label112.Location = new Point(470, 468);
            label112.Name = "label112";
            label112.Size = new Size(60, 15);
            label112.TabIndex = 253;
            label112.Text = "PIB REAL: ";
            // 
            // ProdutoInternoBruto
            // 
            ProdutoInternoBruto.AutoSize = true;
            ProdutoInternoBruto.Location = new Point(622, 438);
            ProdutoInternoBruto.Name = "ProdutoInternoBruto";
            ProdutoInternoBruto.Size = new Size(13, 15);
            ProdutoInternoBruto.TabIndex = 252;
            ProdutoInternoBruto.Text = "0";
            // 
            // label110
            // 
            label110.AutoSize = true;
            label110.Location = new Point(470, 438);
            label110.Name = "label110";
            label110.Size = new Size(88, 15);
            label110.TabIndex = 251;
            label110.Text = "PIB NOMINAL: ";
            // 
            // label108
            // 
            label108.AutoSize = true;
            label108.Location = new Point(3, 392);
            label108.Name = "label108";
            label108.Size = new Size(185, 15);
            label108.TabIndex = 249;
            label108.Text = "Poder de compra do consumidor:";
            // 
            // DEFLACAOAGREGADA
            // 
            DEFLACAOAGREGADA.AutoSize = true;
            DEFLACAOAGREGADA.Location = new Point(621, 392);
            DEFLACAOAGREGADA.Name = "DEFLACAOAGREGADA";
            DEFLACAOAGREGADA.Size = new Size(13, 15);
            DEFLACAOAGREGADA.TabIndex = 248;
            DEFLACAOAGREGADA.Text = "0";
            // 
            // label107
            // 
            label107.AutoSize = true;
            label107.Location = new Point(470, 391);
            label107.Name = "label107";
            label107.Size = new Size(133, 15);
            label107.TabIndex = 246;
            label107.Text = "DEFLAÇÃO AGREGADA:";
            // 
            // SalarioMedioNacional
            // 
            SalarioMedioNacional.AutoSize = true;
            SalarioMedioNacional.Location = new Point(136, 407);
            SalarioMedioNacional.Name = "SalarioMedioNacional";
            SalarioMedioNacional.Size = new Size(13, 15);
            SalarioMedioNacional.TabIndex = 245;
            SalarioMedioNacional.Text = "0";
            // 
            // label104
            // 
            label104.AutoSize = true;
            label104.Location = new Point(3, 407);
            label104.Name = "label104";
            label104.Size = new Size(132, 15);
            label104.TabIndex = 244;
            label104.Text = "Salário Médio Nacional:";
            // 
            // label106
            // 
            label106.AutoSize = true;
            label106.Location = new Point(250, 280);
            label106.Name = "label106";
            label106.Size = new Size(55, 15);
            label106.TabIndex = 243;
            label106.Text = "PONTOS:";
            // 
            // DeflacaoDeCustos
            // 
            DeflacaoDeCustos.AutoSize = true;
            DeflacaoDeCustos.Location = new Point(382, 407);
            DeflacaoDeCustos.Name = "DeflacaoDeCustos";
            DeflacaoDeCustos.Size = new Size(13, 15);
            DeflacaoDeCustos.TabIndex = 242;
            DeflacaoDeCustos.Text = "0";
            // 
            // label105
            // 
            label105.AutoSize = true;
            label105.Location = new Point(267, 407);
            label105.Name = "label105";
            label105.Size = new Size(114, 15);
            label105.TabIndex = 241;
            label105.Text = "Deflação de Custos: ";
            // 
            // InflacaoDeCustos
            // 
            InflacaoDeCustos.AutoSize = true;
            InflacaoDeCustos.Location = new Point(381, 392);
            InflacaoDeCustos.Name = "InflacaoDeCustos";
            InflacaoDeCustos.Size = new Size(13, 15);
            InflacaoDeCustos.TabIndex = 240;
            InflacaoDeCustos.Text = "0";
            // 
            // label103
            // 
            label103.AutoSize = true;
            label103.Location = new Point(266, 392);
            label103.Name = "label103";
            label103.Size = new Size(110, 15);
            label103.TabIndex = 239;
            label103.Text = "Inflação de Custos: ";
            // 
            // INFLACAOAGREGADA
            // 
            INFLACAOAGREGADA.AutoSize = true;
            INFLACAOAGREGADA.Location = new Point(621, 376);
            INFLACAOAGREGADA.Name = "INFLACAOAGREGADA";
            INFLACAOAGREGADA.Size = new Size(13, 15);
            INFLACAOAGREGADA.TabIndex = 238;
            INFLACAOAGREGADA.Text = "0";
            // 
            // label101
            // 
            label101.AutoSize = true;
            label101.Location = new Point(470, 376);
            label101.Name = "label101";
            label101.Size = new Size(131, 15);
            label101.TabIndex = 237;
            label101.Text = "INFLAÇÃO AGREGADA:";
            // 
            // label99
            // 
            label99.BackColor = Color.DimGray;
            label99.Location = new Point(145, 498);
            label99.Name = "label99";
            label99.Size = new Size(521, 77);
            label99.TabIndex = 236;
            label99.Text = resources.GetString("label99.Text");
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.Silver;
            tabPage2.Controls.Add(label11);
            tabPage2.Controls.Add(label12);
            tabPage2.Controls.Add(label13);
            tabPage2.Controls.Add(label14);
            tabPage2.Controls.Add(label15);
            tabPage2.Controls.Add(label27);
            tabPage2.Controls.Add(label29);
            tabPage2.Controls.Add(Povo);
            tabPage2.Controls.Add(label48);
            tabPage2.Controls.Add(labelPopulacaoSemResidencia);
            tabPage2.Controls.Add(PopulacaoDesempregada);
            tabPage2.Controls.Add(label50);
            tabPage2.Controls.Add(populacaoSemEducacao);
            tabPage2.Controls.Add(label21);
            tabPage2.Controls.Add(PopulacaoEmpregada);
            tabPage2.Controls.Add(PopulacaoSemAcessoHospital);
            tabPage2.Controls.Add(PovoSemSaneamento);
            tabPage2.Controls.Add(label51);
            tabPage2.Controls.Add(PovoSemEnergia);
            tabPage2.Controls.Add(PovoComFome);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(662, 575);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "POPULACAO";
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.Silver;
            tabPage3.Controls.Add(label96);
            tabPage3.Controls.Add(label53);
            tabPage3.Controls.Add(TotaldeTecnicoCombustivel);
            tabPage3.Controls.Add(label36);
            tabPage3.Controls.Add(TotalTecnicoCombustivelPrivado);
            tabPage3.Controls.Add(TotalEletrecistas);
            tabPage3.Controls.Add(TotalMineradoresFerroPrivado);
            tabPage3.Controls.Add(label33);
            tabPage3.Controls.Add(TotalAgricultores);
            tabPage3.Controls.Add(label34);
            tabPage3.Controls.Add(TotalEncanadores);
            tabPage3.Controls.Add(TotalTecnicoCombustivel);
            tabPage3.Controls.Add(TotaldeProfessores);
            tabPage3.Controls.Add(label35);
            tabPage3.Controls.Add(TotalMedicos);
            tabPage3.Controls.Add(label67);
            tabPage3.Controls.Add(TotalSoldados);
            tabPage3.Controls.Add(TotalMineradoresFerro);
            tabPage3.Controls.Add(TotaldeAgricultores);
            tabPage3.Controls.Add(label37);
            tabPage3.Controls.Add(TotalProfessores);
            tabPage3.Controls.Add(label66);
            tabPage3.Controls.Add(TotalPoliciais);
            tabPage3.Controls.Add(label38);
            tabPage3.Controls.Add(TotaldeMedicos);
            tabPage3.Controls.Add(TotalAgricultoresPrivados);
            tabPage3.Controls.Add(label57);
            tabPage3.Controls.Add(TotalMedicosPrivados);
            tabPage3.Controls.Add(TotalEmpresarios);
            tabPage3.Controls.Add(label42);
            tabPage3.Controls.Add(TotaldeMineradoresFerro);
            tabPage3.Controls.Add(TotalProfessoresPrivados);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(662, 575);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "EMPREGADOS";
            // 
            // label96
            // 
            label96.Location = new Point(531, 3);
            label96.Name = "label96";
            label96.Size = new Size(139, 118);
            label96.TabIndex = 165;
            label96.Text = "Os números de cor roxa simbolizam os profissionais de empresas privadas, os números amarelos são a soma dos profissionais estatais + privados.";
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.Silver;
            tabPage4.Controls.Add(label85);
            tabPage4.Controls.Add(label52);
            tabPage4.Controls.Add(MenosHospitalPrivado);
            tabPage4.Controls.Add(MenosFazendaPrivada);
            tabPage4.Controls.Add(TotalIndustriaFerro);
            tabPage4.Controls.Add(MenosIndustriaFerroPrivada);
            tabPage4.Controls.Add(AcessarIndice);
            tabPage4.Controls.Add(MenosIndustriaCombustivelPrivada);
            tabPage4.Controls.Add(label68);
            tabPage4.Controls.Add(MenosInstituicaoEnsinoPrivada);
            tabPage4.Controls.Add(TotalEdificios);
            tabPage4.Controls.Add(label39);
            tabPage4.Controls.Add(TotalCentrosdeEnergia);
            tabPage4.Controls.Add(TotalIndustriaCombustivel);
            tabPage4.Controls.Add(label65);
            tabPage4.Controls.Add(TotalResidencias);
            tabPage4.Controls.Add(label32);
            tabPage4.Controls.Add(TotalFazendas);
            tabPage4.Controls.Add(label40);
            tabPage4.Controls.Add(TotalReservatoriosAgua);
            tabPage4.Controls.Add(label31);
            tabPage4.Controls.Add(label16);
            tabPage4.Controls.Add(label41);
            tabPage4.Controls.Add(labelpredio);
            tabPage4.Controls.Add(label30);
            tabPage4.Controls.Add(label17);
            tabPage4.Controls.Add(TotalBancosPrivados);
            tabPage4.Controls.Add(TerritoriosPais);
            tabPage4.Controls.Add(TotalIndustriaFerroPrivado);
            tabPage4.Controls.Add(label18);
            tabPage4.Controls.Add(label59);
            tabPage4.Controls.Add(label54);
            tabPage4.Controls.Add(label480);
            tabPage4.Controls.Add(label19);
            tabPage4.Controls.Add(TotalIndustriaCombustivelPrivada);
            tabPage4.Controls.Add(label55);
            tabPage4.Controls.Add(TerrasDisponiveis);
            tabPage4.Controls.Add(TotaldeFazendas);
            tabPage4.Controls.Add(EspacoDisponivelSoldados);
            tabPage4.Controls.Add(label49);
            tabPage4.Controls.Add(label20);
            tabPage4.Controls.Add(TotaldeIndustriaCombustivel);
            tabPage4.Controls.Add(TotalHospitais);
            tabPage4.Controls.Add(TotalFazendasPrivadas);
            tabPage4.Controls.Add(label26);
            tabPage4.Controls.Add(TotalQuarteis);
            tabPage4.Controls.Add(TerrasOcupadas);
            tabPage4.Controls.Add(label22);
            tabPage4.Controls.Add(TotaldeIndustriaFerro);
            tabPage4.Controls.Add(EspacoDisponivelPoliciais);
            tabPage4.Controls.Add(TotaldeHospitais);
            tabPage4.Controls.Add(label25);
            tabPage4.Controls.Add(TotalDelegacias);
            tabPage4.Controls.Add(TotalHospitaisPrivados);
            tabPage4.Controls.Add(label23);
            tabPage4.Controls.Add(TotaldeEscolas);
            tabPage4.Controls.Add(TotalEscolas);
            tabPage4.Controls.Add(label24);
            tabPage4.Controls.Add(TotalEscolasPrivadas);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(662, 575);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "EDIFICIOS";
            // 
            // label85
            // 
            label85.Location = new Point(544, 3);
            label85.Name = "label85";
            label85.Size = new Size(126, 172);
            label85.TabIndex = 167;
            label85.Text = resources.GetString("label85.Text");
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 128, 128);
            ClientSize = new Size(1122, 639);
            Controls.Add(PainelDeControle);
            Controls.Add(label45);
            Controls.Add(label28);
            Name = "Form1";
            Text = " ";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)fileSystemWatcher1).EndInit();
            PainelDeControle.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            Painel.ResumeLayout(false);
            tabPage6.ResumeLayout(false);
            tabPage6.PerformLayout();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            tabPage7.ResumeLayout(false);
            tabPage7.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Button button4;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button3;
        private TextBox Taxa;
        private Button button5;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private Label label42;
        private Label Povo;
        private Label label44;
        private Label INDF;
        private Label label46;
        private Label label47;
        private Label IN;
        private Label DF;
        private Label label43;
        private Label QDP;
        private Label label45;
        private Button ELIMINAR;
        private Button Administração;
        private Label label480;
        private Label label48;
        private Label labelPopulacaoSemResidencia;
        private FileSystemWatcher fileSystemWatcher1;
        private Label TerrasDisponiveis;
        private Label TerrasOcupadas;
        private Label label49;
        private Label PopulacaoDesempregada;
        private Button AcessarIndice;
        private Label label50;
        private Label TotalEscolas;
        private Label populacaoSemEducacao;
        private Label TotalProfessores;
        private Label PopulacaoEmpregada;
        private Label label21;
        private Label TotalHospitais;
        private Label PopulacaoSemAcessoHospital;
        private Label TotalMedicos;
        private Label TerritoriosPais;
        private Label labelpredio;
        private Label label51;
        private Label TotalAgricultores;
        private Label TotalFazendas;
        private Label PovoComFome;
        private Label TotalEletrecistas;
        private Label TotalCentrosdeEnergia;
        private Label label53;
        private Label PovoSemEnergia;
        private Label label52;
        private Label TotalReservatoriosAgua;
        private Label TotalEncanadores;
        private Label PovoSemSaneamento;
        private Label TotalSoldados;
        private Label EspacoDisponivelSoldados;
        private Label label55;
        private Label label54;
        private Label TotalQuarteis;
        private Label TotalDelegacias;
        private Label TotalPoliciais;
        private Label EspacoDisponivelPoliciais;
        private Label TotaldeHospitais;
        private Label TotalHospitaisPrivados;
        private Label TotaldeEscolas;
        private Label TotalEscolasPrivadas;
        private Label TotaldeFazendas;
        private Label TotalFazendasPrivadas;
        private Label label56;
        private TextBox CreditoNacional;
        private Label TotalCredito;
        private Button MaisCredito;
        private Label TotalEmpresarios;
        private Label label57;
        private Label TotalProfessoresPrivados;
        private Label label58;
        private TextBox TaxaSelic;
        private TextBox textBox1;
        private Label TotalBancosPrivados;
        private Label label59;
        private Label EmprestimosPorBanco;
        private Label TitulosPublicos;
        private Label label60;
        private Label TitulosMoney;
        private Button BuyTitulos;
        private Label PrecoCompraTitulos;
        private Label PrecoVendaTitulos;
        private Label label62;
        private Label label61;
        private Label SalarioMinimoEsperado;
        private Label label64;
        private Label TotalMedicosPrivados;
        private Label TotalAgricultoresPrivados;
        private Button AdministracaoAvancada;
        private Label TotalIndustriaFerro;
        private Label label65;
        private Label TotalMineradoresFerro;
        private Label label66;
        private Label label67;
        private Label label68;
        private Label TotalTecnicoCombustivel;
        private Label TotalIndustriaCombustivel;
        private Label TotalTecnicoCombustivelPrivado;
        private Label TotalMineradoresFerroPrivado;
        private Label TotalIndustriaCombustivelPrivada;
        private Label TotalIndustriaFerroPrivado;
        private Label TotaldeTecnicoCombustivel;
        private Label TotaldeIndustriaCombustivel;
        private Label TotaldeIndustriaFerro;
        private Button MenosFazendaPrivada;
        private Button MenosIndustriaFerroPrivada;
        private Button MenosIndustriaCombustivelPrivada;
        private Button MenosInstituicaoEnsinoPrivada;
        private Button MenosHospitalPrivado;
        private Label TotaldeMineradoresFerro;
        private Label TotalEdificios;
        private Label TotalResidencias;
        private Label TotaldeProfessores;
        private Label TotaldeAgricultores;
        private Label TotaldeMedicos;
        private Label label71;
        private Label label70;
        private Label label69;
        private Label label63;
        private Label label74;
        private Label label73;
        private Label label72;
        private Label CombustivelPrivado;
        private Label FerroPrivado;
        private Label Saude;
        private Label Educacao;
        private Label Alimento;
        private Label Combustivel;
        private Label Ferro;
        private Label label75;
        private Label label76;
        private Label label77;
        private Label label78;
        private Label label79;
        private Label SaudePrivado;
        private Label EducacaoPrivado;
        private Label AlimentoPrivado;
        private Label ConsumoPontosEducacao;
        private Label label81;
        private Label label80;
        private Label label83;
        private Label label82;
        private Label label84;
        private Label DeflacaoPontosEducacao;
        private Label label87;
        private Label InflacaoPontosEducacao;
        private Label DeflacaoPontosSaude;
        private Label label86;
        private Label InflacaoPontosSaude;
        private Label label89;
        private Label ConsumoPontosSaude;
        private Label label91;
        private Label DeflacaoPontosAlimento;
        private Label label88;
        private Label InflacaoPontosAlimento;
        private Label label92;
        private Label ConsumoPontosAlimentos;
        private Label label94;
        private Button MenosConsumoPrivadoSaude;
        private Button MenosConsumoEstatalEducacao;
        private Button MenosConsumoPrivadoEducacao;
        private Button MenosConsumoAlimentoEstatal;
        private Button MenosConsumoPrivadoAlimentos;
        private Button MenosConsumoPrivadoCombustivel;
        private Label DeflacaoPontosCombustivel;
        private Label label90;
        private Label InflacaoPontosCombustivel;
        private Label label95;
        private Label ConsumoPontosCombustivel;
        private Label label97;
        private Button MenosConsumoFerroEstatal;
        private Button MenosConsumoFerroPrivado;
        private Label DeflacaoPontosFerro;
        private Label label93;
        private Label InflacaoPontosFerro;
        private Label label98;
        private Label ConsumoPontosFerro;
        private Label label100;
        private TextBox SubtracaoConsumo;
        private TabControl PainelDeControle;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private Label label96;
        private Label label85;
        private Label label99;
        private Label INFLACAOAGREGADA;
        private Label label101;
        private Label InflacaoDeCustos;
        private Label label103;
        private Label label106;
        private Label DeflacaoDeCustos;
        private Label label105;
        private Label SalarioMedioNacional;
        private Label label104;
        private FolderBrowserDialog folderBrowserDialog1;
        private Label DEFLACAOAGREGADA;
        private Label label107;
        private Label label108;
        private Label ProdutoInternoBruto;
        private Label label110;
        private Label PIBREAL;
        private Label label112;
        private Label PIBREALPORCENTAGEM;
        private Label label111;
        private Label PIBNOMINALPORCENTAGEM;
        private Label label113;
        private Label label115;
        private Label label114;
        private Label PoderDeCompra;
        private Button MnosConsumoSaudeEstatal;
        private Button MenosConsumoCombustivelEstatal;
        private Label DEFLACAOAGREGADAPORCENTAGEM;
        private Label INFLACAAGREGADAPORCENTAGEM;
        private Label label109;
        private Label label102;
        private CheckBox MenosConsumoTodos;
        private CheckBox MenosTodosEstatal;
        private Label label116;
        private Label SalarioMinimoNecessario;
        private Label TaxaDesemprego;
        private Label label117;
        private Label label119;
        private Label demandaagregada;
        private TabControl Painel;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private Label label121;
        private Label label120;
        private Label label118;
        private TextBox TaxaEducacao;
        private TextBox TaxaSaude;
        private Label SetorSaudePrivado;
        private Label SetorEducacaoPrivado;
        private Label label122;
        private Label label126;
        private Label SetorAgriculturaPrivado;
        private Label label125;
        private Label label124;
        private Label label123;
        private TextBox TaxaAgricultura;
        private Label label129;
        private Label SetorCombustivelPrivado;
        private TextBox TaxaFerro;
        private Label label128;
        private TextBox TaxaCombustivel;
        private Label label127;
        private Label label130;
        private Label SetorFerroPrivado;
        private TabPage tabPage7;
        private Label label131;
        private Label label132;
        private Label SetorAgriculturaEstatal;
        private Label SetorFerroEstatal;
        private Label label135;
        private Label label136;
        private Label label137;
        private Label SetorSaudeEstatal;
        private Label SetorEducacaoEstatal;
        private Label SetorCombustivelEstatal;
        private Label label141;
    }
}