﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Derick
{
    public partial class Form3 : Form
    {


        private Form1 form1;
        private Form2 form2;

        public Form3(Form1 form1, string TotalReservatorioAgua, string TotalCentrosEnergia, string TotalFazendas, string Totalhospitais, string Totalescolas, string Populacaototal)
        {
            InitializeComponent();

            this.form1 = form1;

            int Escolasnecessarias = (int.Parse(Totalescolas) * 40) - (int.Parse(Populacaototal));
            if (Escolasnecessarias > 1) { Escolasnecessarias = 0; };//Parou aqui, continuar aqui
            int EscolasNecessario = Escolasnecessarias / 40;
            int EscolasNecessario1 = Math.Abs(EscolasNecessario);
            EscolasNecessarias.Text = EscolasNecessario1.ToString();

            int Hospitaisnecessarios = (int.Parse(Totalhospitais) * 60) - (int.Parse(Populacaototal));
            if (Hospitaisnecessarios > 1) { Hospitaisnecessarios = 0; };//Parou aqui, continuar aqui
            int HospitaisNecessario = Hospitaisnecessarios / 60;
            int HospitaisNecessarios1 = Math.Abs(HospitaisNecessario);
            HospitaisNecessarios.Text = HospitaisNecessarios1.ToString();

            int Fazendanecessarios = (int.Parse(Totalhospitais) * 50) - (int.Parse(Populacaototal));
            if (Fazendanecessarios > 1) { Fazendanecessarios = 0; };//Parou aqui, continuar aqui
            int Fazendanecessario = Fazendanecessarios / 50;
            int FazendaNecessarios1 = Math.Abs(Fazendanecessario);
            FazendasNecessarias.Text = FazendaNecessarios1.ToString();

            int CentroenergiaNecessario = (int.Parse(TotalCentrosEnergia) * 40) - (int.Parse(Populacaototal));
            if (CentroenergiaNecessario > 1) { CentroenergiaNecessario = 0; };
            int CentroenergiaNecessarios = CentroenergiaNecessario / 40;
            int CentroEnergiaNecessario1 = Math.Abs(CentroenergiaNecessarios);
            CentrosEnergiaNecessarios.Text = CentroEnergiaNecessario1.ToString();

            int ReservatorioAguaNecessario = (int.Parse(TotalReservatorioAgua) * 40) - (int.Parse(Populacaototal));
            if (ReservatorioAguaNecessario > 1) { ReservatorioAguaNecessario = 0; };
            int ReservatorioAguaNecessarios = ReservatorioAguaNecessario / 40;
            int ReservatorioAguaNecessario1 = Math.Abs(ReservatorioAguaNecessarios);
            ReservatorioAguanecessario.Text = ReservatorioAguaNecessario1.ToString();

            // form1.InstituicaodeEnsinoPrivada(EscolasNecessarias.Text);

        }






        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
