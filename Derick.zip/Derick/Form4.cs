﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Derick
{

    public partial class Form4 : Form
    {
        double SalarioMinimoEsperado;
        private Form1 form1;
        public Form4(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;

            SalarioMinimoEsperado = this.form1.SalarioEsperado;

            SalarioMinimoprofessores.Text = this.form1.SalarioMinimoProfessores.ToString();
            SalarioMinimoagricultores.Text = this.form1.SalarioMinimoAgricultores.ToString();
            SalarioMinimomedicos.Text = this.form1.SalarioMinimoMedicos.ToString();
            SalarioMinimoMineradorFerro.Text = this.form1.SalarioMinimoMineradorFerro.ToString();
            SalarioMinimoTecnicoCombustivel.Text = this.form1.SalarioMinimoTecnicoCombustivel.ToString();

            SalarioMinimoprofessoresEstatal.Text = this.form1.SalarioMinimoProfessoresEstatal.ToString();
            SalarioMinimoagricultoresEstatal.Text = this.form1.SalarioMinimoAgricultoresEstatal.ToString();
            SalarioMinimomedicosEstatal.Text = this.form1.SalarioMinimoMedicosEstatal.ToString();
            SalarioMinimopoliciaisEstatal.Text = this.form1.SalarioMinimoPoliciaisEstatal.ToString();
            SalarioMinimosoldadosEstatal.Text = this.form1.SalarioMinimoSoldadosEstatal.ToString();
            SalarioMinimoeletrecistasEstatal.Text = this.form1.SalarioMinimoEletrecistasEstatal.ToString();
            SalarioMinimoencanadoresEstatal.Text = this.form1.SalarioMinimoEncanadoresEstatal.ToString();
            SalarioMinimoMineradorFerroEstatal.Text = this.form1.SalarioMinimoMineradorFerroEstatal.ToString();
            SalarioMinimoTecnicoCombustivelEstatal.Text = this.form1.SalarioMinimoTecnicoCombustivelEstatal.ToString();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void AtualizarInformacoes_Click(object sender, EventArgs e)
        {
            if (SalarioMinimoprofessores.Text == "")
            {
                SalarioMinimoprofessores.Text = "0";
            }

            if (SalarioMinimoagricultores.Text == "")
            {
                SalarioMinimoagricultores.Text = "0";
            }

            if (SalarioMinimomedicos.Text == "")
            {
                SalarioMinimomedicos.Text = "0";
            }

            if (SalarioMinimoMineradorFerro.Text == "")
            {
                SalarioMinimoMineradorFerro.Text = "0";
            }

            if (SalarioMinimoTecnicoCombustivel.Text == "")
            {
                SalarioMinimoTecnicoCombustivel.Text = "0";
            }


            int salariominimo = int.Parse(SalarioMinimoprofessores.Text);
            form1.SalarioMinimoprofessores(salariominimo);
            int salariominimo1 = int.Parse(SalarioMinimoagricultores.Text);
            form1.SalarioMinimoagricultores(salariominimo1);
            int salariominimo2 = int.Parse(SalarioMinimomedicos.Text);
            form1.SalarioMinimomedicos(salariominimo2);
            int salariominimo3 = int.Parse(SalarioMinimoMineradorFerro.Text);
            form1.SalarioMinimoMineradoresFerro(salariominimo3);
            int salariominimo4 = int.Parse(SalarioMinimoTecnicoCombustivel.Text);
            form1.SalarioMinimoTecnicocombustivel(salariominimo4);



            int salariominimo11 = int.Parse(SalarioMinimoprofessoresEstatal.Text);
            form1.SalarioMinimoprofessoresEstatal(salariominimo11);
            int salariominimo12 = int.Parse(SalarioMinimoagricultoresEstatal.Text);
            form1.SalarioMinimoagricultoresEstatal(salariominimo12);
            int salariominimo13 = int.Parse(SalarioMinimomedicosEstatal.Text);
            form1.SalarioMinimomedicosEstatal(salariominimo13);
            int salariominimo14 = int.Parse(SalarioMinimopoliciaisEstatal.Text);
            form1.SalarioMinimopoliciaisEstatal(salariominimo14);
            int salariominimo15 = int.Parse(SalarioMinimosoldadosEstatal.Text);
            form1.SalarioMinimosoldadosEstatal(salariominimo15);
            int salariominimo16 = int.Parse(SalarioMinimoeletrecistasEstatal.Text);
            form1.SalarioMinimoeletrecistasEstatal(salariominimo16);
            int salariominimo17 = int.Parse(SalarioMinimoencanadoresEstatal.Text);
            form1.SalarioMinimoencanadoresEstatal(salariominimo17);
            int salariominimo18 = int.Parse(SalarioMinimoMineradorFerroEstatal.Text);
            form1.SalarioMinimoMineradoresFerroEstatal(salariominimo18);
            int salariominimo19 = int.Parse(SalarioMinimoTecnicoCombustivelEstatal.Text);
            form1.SalarioMinimoTecnicocombustivelEstatal(salariominimo19);


        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void SalarioEsperado_Click(object sender, EventArgs e)
        {
            SalarioMinimoprofessores.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoagricultores.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimomedicos.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoMineradorFerro.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoTecnicoCombustivel.Text = SalarioMinimoEsperado.ToString();


            SalarioMinimoprofessoresEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoagricultoresEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimomedicosEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimopoliciaisEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimosoldadosEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoeletrecistasEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoencanadoresEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoMineradorFerroEstatal.Text = SalarioMinimoEsperado.ToString();
            SalarioMinimoTecnicoCombustivelEstatal.Text = SalarioMinimoEsperado.ToString();
        }
    }
}
