﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Derick
{
    public partial class Form2 : Form
    {
        private Form1 form1;
        public int Professores;
        public int Medicos;
        public int Agricultores;
        public int PopulacaoDesempregada;
        public int Eletrecista;
        public int Encanador;
        public int MineradorFerro;
        public int EspacoDisponivelSoldado2;
        public int EspacoDisponivelPoliciais2;
        public int TecnicoCombustivel;


        public Form2(Form1 form1, string totalhospital, string totalindustriacombustivel, string tecnicocombustivel, string totalindustriaferro, string mineradorferro, string Totaldelegacias, string espacoDisponivelPoliciais, string espacoDisponivelSoldados, string Totalquarteis, string QuantiareservatorioAgua, string encanador, string quantiacentrosEnergia, string eletrecista, string quantiafazendas, string agricultores, string Quantiadecasas, string QuantidadeDePredios, string Terrasocupadas, string TerritoriosdoPais, string TotalEscolas, string PovoTotal, string professores, string populacaodesempregada, string medicos)
        {
            InitializeComponent();
            this.form1 = form1;
            this.form1.AtualizadordeTotais();

            d480.Text = this.form1.A.ToString();
            dinheirototal2.Text = this.form1.DinheiroTotal.ToString();
            dinheiroDoGoverno2.Text = this.form1.dinheiroDoGoverno.ToString();
            dinheiroDosCidadaos2.Text = this.form1.dinheiroDosCidadaos.ToString();

            int precocasa = int.Parse(dinheiroDosCidadaos2.Text) / 100;
            PrecoCasa.Text = precocasa.ToString();
            int precopredio = precocasa * 5;
            PrecoPredio.Text = precopredio.ToString();
            d480.Text = Quantiadecasas;
            LabelPredio.Text = QuantidadeDePredios;

            int QuantidadeDeTerritoriosDisponiveis1 = int.Parse(TerritoriosdoPais) - int.Parse(Terrasocupadas);
            TerrasDisponiveis2.Text = QuantidadeDeTerritoriosDisponiveis1.ToString();

            PopulacaoSemResidencia.Text = this.form1.PovoSemResidencia.ToString();
            QuantiadeEscola.Text = TotalEscolas;
            QuantiadeHospital.Text = totalhospital;
            QuantiadeFazenda.Text = quantiafazendas;
            QuantiadeCentrosEnergia.Text = quantiacentrosEnergia;
            QuantiadeReservatorioAgua.Text = QuantiareservatorioAgua;
            QuantiadeQuartel.Text = Totalquarteis;
            QuantiadeDelegacia.Text = Totaldelegacias;
            QuantiadeIndustriaFerro.Text = totalindustriaferro;
            QuantiadeIndustriaCombustivel.Text = totalindustriacombustivel;

            PopulacaoTotal.Text = PovoTotal;

            int PrecoDaEscola = int.Parse(dinheirototal2.Text) / 12;
            int PrecoHospitais = int.Parse(dinheirototal2.Text) / 16;
            int PrecoFazendas = int.Parse(dinheirototal2.Text) / 14;
            int PrecoCentroEnergia = int.Parse(dinheirototal2.Text) / 11;
            int PrecoReservatoriosAgua = int.Parse(dinheirototal2.Text) / 11;
            int Precoquartel = int.Parse(dinheirototal2.Text) / 5;
            int Precodelegacia = int.Parse(dinheirototal2.Text) / 6;
            int PrecoIndustriaferro = int.Parse(dinheirototal2.Text) / 7;
            int PrecoIndustriacombustivel = int.Parse(dinheirototal2.Text) / 7;
            PrecoEscola.Text = PrecoDaEscola.ToString();
            PrecoHospital.Text = PrecoHospitais.ToString();
            PrecoFazenda.Text = PrecoFazendas.ToString();
            PrecoCentrosEnergia.Text = PrecoCentroEnergia.ToString();
            PrecoReservatorioAgua.Text = PrecoReservatoriosAgua.ToString();
            PrecoQuartel.Text = Precoquartel.ToString();
            PrecoDelegacia.Text = Precodelegacia.ToString();
            PrecoIndustriaFerro.Text = PrecoIndustriaferro.ToString();
            PrecoIndustriaCombustivel.Text = PrecoIndustriacombustivel.ToString();

            Professores = int.Parse(professores);
            PopulacaoDesempregada = int.Parse(populacaodesempregada);
            Medicos = int.Parse(medicos);
            Agricultores = int.Parse(agricultores);
            Eletrecista = int.Parse(eletrecista);
            Encanador = int.Parse(encanador);
            MineradorFerro = int.Parse(mineradorferro);
            TecnicoCombustivel = int.Parse(tecnicocombustivel);

            EspacoDisponivelSoldado2 = int.Parse(espacoDisponivelSoldados);
            EspacoDisponivelPoliciais2 = int.Parse(espacoDisponivelPoliciais);


        }








        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void dinheirototal2_Click(object sender, EventArgs e)
        {

        }

        private void dinheiroDosCidadaos2_Click(object sender, EventArgs e)
        {

        }





        public void MaisUmaCasa_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int PopulacaosemResidencia = int.Parse(PopulacaoSemResidencia.Text);
            if (PopulacaosemResidencia < 5)
            {
                MessageBox.Show("Você não pode mais construir casas pois a quantia de pessoas sem residências é inferior a 5");
                return;
            };

            int AtualizarLabelForm2PovoSemResidencia = int.Parse(PopulacaoSemResidencia.Text) - 5;
            PopulacaoSemResidencia.Text = AtualizarLabelForm2PovoSemResidencia.ToString();

            int PrecoDaCasa = int.Parse(dinheiroDosCidadaos2.Text) / 100;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDaCasa)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(d480.Text) + 1;
            d480.Text = Mais.ToString();


            PrecoCasa.Text = PrecoDaCasa.ToString();
            int SubtrairPrecoCasa = Math.Abs(PrecoDaCasa - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoCasa.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();
            form1.metodonovocasa(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);

        }

        private void button2_Click(object sender, EventArgs e)
        { //Mais um prédio

            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int PopulacaosemResidencia = int.Parse(PopulacaoSemResidencia.Text);

            if (PopulacaosemResidencia < 13)
            {
                MessageBox.Show("Você não pode mais construir prédios pois a quantia de pessoas sem residências é inferior a 13");
                return;
            };

            int AtualizarLabelForm2PovoSemResidencia = int.Parse(PopulacaoSemResidencia.Text) - 13;
            PopulacaoSemResidencia.Text = AtualizarLabelForm2PovoSemResidencia.ToString();

            int PrecoDoPredio = int.Parse(PrecoCasa.Text) * 5;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDoPredio)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(LabelPredio.Text) + 1;
            LabelPredio.Text = Mais.ToString();


            PrecoPredio.Text = PrecoDoPredio.ToString();
            int SubtrairPrecoPredio = Math.Abs(PrecoDoPredio - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoPredio.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();
            form1.metodonovopredio(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);
        }






        private void label7_Click(object sender, EventArgs e)
        {
        }

        private void label8_Click(object sender, EventArgs e)
        {
        }

        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void label10_Click(object sender, EventArgs e)
        {
        }

        private void dinheiroDoGoverno2_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click_1(object sender, EventArgs e)
        {

        }

        private void MenosUmaCasa_Click(object sender, EventArgs e)
        {

            int D480 = int.Parse(d480.Text) - 1;
            d480.Text = D480.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);
            form1.MenosUmaCasa();



        }

        private void MenosUmPredio_Click(object sender, EventArgs e)
        {

            int labelPredio = int.Parse(LabelPredio.Text) - 1;
            LabelPredio.Text = labelPredio.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);
            form1.MenosUmPredio();


        }




        private void MaisEscolas_Click(object sender, EventArgs e)
        {


            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int QuantiaEscola = int.Parse(QuantiadeEscola.Text);
            int Populacaototal = int.Parse(PopulacaoTotal.Text);
            

            int PrecoDaEscola = int.Parse(dinheirototal2.Text) / 12;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDaEscola)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(QuantiadeEscola.Text) + 1;
            QuantiadeEscola.Text = Mais.ToString();

            PrecoEscola.Text = PrecoDaEscola.ToString();
            int SubtrairPrecoEscola = Math.Abs(PrecoDaEscola - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoEscola.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();


            form1.metodonovaInstituicaoDeEnsino(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);
            int povototal = int.Parse(PopulacaoTotal.Text);
            int quantidadedeEscolas = int.Parse(QuantiadeEscola.Text);


            if (PopulacaoDesempregada > 4)
            {
                Professores = Professores + 5;
                form1.professores(Professores);

                int menospessoasdesempregadas = -5;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -5;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }

            form1.AtualizadordeTotais();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void MenosEscolas_Click(object sender, EventArgs e)
        {

            int totalescola = int.Parse(QuantiadeEscola.Text);
            if (totalescola < 1) { return; }
            int quantiadeescola = int.Parse(QuantiadeEscola.Text) - 1;
            QuantiadeEscola.Text = quantiadeescola.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);
            form1.MenosUmaEscola();

            if (PopulacaoDesempregada > -1)
            {
                Professores = Professores - 5;
                form1.professores(Professores);
                int menospessoasdesempregadas = +5;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +5;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }

            form1.AtualizadordeTotais();


        }

        private void MaisHospital_Click(object sender, EventArgs e)
        {
            form1.AtualizadordeTotais();
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int QuantiaHospital = int.Parse(QuantiadeHospital.Text);
            int Populacaototal = int.Parse(PopulacaoTotal.Text);
           



            int PrecoDoHospital = int.Parse(dinheirototal2.Text) / 16;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDoHospital)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(QuantiadeHospital.Text) + 1;
            QuantiadeHospital.Text = Mais.ToString();

            PrecoHospital.Text = PrecoDoHospital.ToString();
            int SubtrairPrecoHospital = Math.Abs(PrecoDoHospital - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoHospital.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();


            form1.metodonovoHospital(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoDesempregada > 8)
            {
                Medicos = Medicos + 9;
                form1.medicos(Medicos);

                int menospessoasdesempregadas = -9;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -9;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }

            form1.AtualizadordeTotais();
        }

        private void MenosHospital_Click(object sender, EventArgs e)
        {
            int totalhospital = int.Parse(QuantiadeHospital.Text);
            if (totalhospital < 1) { return; }
            int quantiadehospitais = int.Parse(QuantiadeHospital.Text) - 1;
            QuantiadeHospital.Text = quantiadehospitais.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            form1.MenosUmHospital();

            if (PopulacaoDesempregada > -1)
            {
                Medicos = Medicos - 9;
                form1.medicos(Medicos);
                int menospessoasdesempregadas = +9;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +9;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }

            form1.AtualizadordeTotais();
        }

        private void MaisFazendas_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int QuantiaFazenda = int.Parse(QuantiadeFazenda.Text);
            int Populacaototal = int.Parse(PopulacaoTotal.Text);
           



            int PrecoDaFazenda = int.Parse(dinheirototal2.Text) / 14;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDaFazenda)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(QuantiadeFazenda.Text) + 1;
            QuantiadeFazenda.Text = Mais.ToString();

            PrecoFazenda.Text = PrecoDaFazenda.ToString();
            int SubtrairPrecoFazenda = Math.Abs(PrecoDaFazenda - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoFazenda.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();


            form1.metodonovaFazenda(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);


            if (PopulacaoDesempregada > 7)
            {
                Agricultores = Agricultores + 8;
                form1.Agricultores(Agricultores);

                int menospessoasdesempregadas = -8;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -8;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }

            form1.AtualizadordeTotais();
        }

        private void MenosFazendas_Click(object sender, EventArgs e)
        {
            int totalfazenda = int.Parse(QuantiadeFazenda.Text);
            if (totalfazenda < 1) { return; }
            int quantiadefazenda = int.Parse(QuantiadeFazenda.Text) - 1;
            QuantiadeFazenda.Text = quantiadefazenda.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            form1.MenosUmaFazenda();


            if (PopulacaoDesempregada > -1)
            {
                Agricultores = Agricultores - 8;
                form1.Agricultores(Agricultores);
                int menospessoasdesempregadas = +8;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +8;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }

            form1.AtualizadordeTotais();
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void PrecoEscola_Click(object sender, EventArgs e)
        {

        }

        private void MaisCentrosEnergia_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis
                < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int QuantiaCentrosEnergia = int.Parse(QuantiadeCentrosEnergia.Text);
            int Populacaototal = int.Parse(PopulacaoTotal.Text);
           



            int PrecoDeCentrosEnergia = int.Parse(dinheirototal2.Text) / 11;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDeCentrosEnergia)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(QuantiadeCentrosEnergia.Text) + 1;
            QuantiadeCentrosEnergia.Text = Mais.ToString();

            PrecoCentrosEnergia.Text = PrecoDeCentrosEnergia.ToString();
            int SubtrairPrecoCentrosEnergia = Math.Abs(PrecoDeCentrosEnergia - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoCentrosEnergia.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();


            form1.metodonovoCentrodeEnergia(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoDesempregada > 1)
            {
                Eletrecista = Eletrecista + 2;
                form1.eletrecista(Eletrecista);

                int menospessoasdesempregadas = -2;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -2;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }

            form1.AtualizadordeTotais();

        }

        private void MenosCentrosEnergia_Click(object sender, EventArgs e)
        {

            int totalcentroenergia = int.Parse(QuantiadeCentrosEnergia.Text);
            if (totalcentroenergia < 1) { return; }
            int quantiadecentrosenergia = int.Parse(QuantiadeCentrosEnergia.Text) - 1;
            QuantiadeCentrosEnergia.Text = quantiadecentrosenergia.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            form1.MenosUmCentroEnergia();

            if (PopulacaoDesempregada > -1)
            {
                Eletrecista = Eletrecista - 2;
                form1.eletrecista(Eletrecista);
                int menospessoasdesempregadas = +2;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +2;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }
            form1.AtualizadordeTotais();
        }

        private void MaisReservatorioAgua_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis
                < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int QuantiareservatorioAgua = int.Parse(QuantiadeReservatorioAgua.Text);
            int Populacaototal = int.Parse(PopulacaoTotal.Text);
            



            int PrecoDeReservatorioAgua = int.Parse(dinheirototal2.Text) / 11;

            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDeReservatorioAgua)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };
            int Mais = int.Parse(QuantiadeReservatorioAgua.Text) + 1;
            QuantiadeReservatorioAgua.Text = Mais.ToString();

            PrecoReservatorioAgua.Text = PrecoDeReservatorioAgua.ToString();
            int SubtrairPrecoReservatorioAgua = Math.Abs(PrecoDeReservatorioAgua - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoReservatorioAgua.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();


            form1.metodonovoReservatorioAgua(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            int terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = terrasdisponiveis.ToString();
            form1.Terrasdisponiveis(terrasdisponiveis);

            if (PopulacaoDesempregada > 1)
            {
                Encanador = Encanador + 2;
                form1.encanador(Encanador);

                int menospessoasdesempregadas = -2;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -2;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }
            form1.AtualizadordeTotais();
        }

        private void MenosReservatorioAgua_Click(object sender, EventArgs e)
        {

            int totalReservatorioAgua = int.Parse(QuantiadeReservatorioAgua.Text);
            if (totalReservatorioAgua < 1) { return; }
            int quantiadereservatorioagua = int.Parse(QuantiadeReservatorioAgua.Text) - 1;
            QuantiadeReservatorioAgua.Text = quantiadereservatorioagua.ToString();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            form1.MenosUmReservatorioAgua();


            if (PopulacaoDesempregada > -1)
            {
                Encanador = Encanador - 2;
                form1.encanador(Encanador);
                int menospessoasdesempregadas = +2;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +2;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }

            form1.AtualizadordeTotais();
        }

        private void MaisQuartel_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int PrecoDeQuartel = int.Parse(dinheirototal2.Text) / 5;
            if (int.Parse(dinheiroDoGoverno2.Text) < PrecoDeQuartel)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            int Mais = int.Parse(QuantiadeQuartel.Text) + 1;
            QuantiadeQuartel.Text = Mais.ToString();

            PrecoQuartel.Text = PrecoDeQuartel.ToString();
            int SubtrairPrecoQuartel = Math.Abs(PrecoDeQuartel - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoQuartel.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();

            form1.NovoQuartel(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);
            EspacoDisponivelSoldado2 = EspacoDisponivelSoldado2 + 50;

            form1.AtualizadordeTotais();
        }

        private void MenosQuartel_Click(object sender, EventArgs e)
        {
            int totalquartel = int.Parse(QuantiadeQuartel.Text);
            if (totalquartel < 1) { return; }

            if (EspacoDisponivelSoldado2 > 49)
            {
                int quantiaQuartel = int.Parse(QuantiadeQuartel.Text) - 1;
                QuantiadeQuartel.Text = quantiaQuartel.ToString();
                form1.MenosUmQuartel();
                EspacoDisponivelSoldado2 = EspacoDisponivelSoldado2 - 50;
                int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
                TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
                form1.Terrasdisponiveis(MaisUmaTerraDisponivel);


            }
            else
            {
                MessageBox.Show("Você não pode destruir o quartel pois a quantia de espaço disponível de soldados é inferior a 50"); return;
            }

            form1.AtualizadordeTotais();
        }

        private void MaisDelegacia_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int Precodelegacia = int.Parse(dinheirototal2.Text) / 6;
            if (int.Parse(dinheiroDoGoverno2.Text) < Precodelegacia)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            int Mais = int.Parse(QuantiadeDelegacia.Text) + 1;
            QuantiadeDelegacia.Text = Mais.ToString();

            PrecoDelegacia.Text = Precodelegacia.ToString();
            int SubtrairPrecoDelegacia = Math.Abs(Precodelegacia - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoDelegacia.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();

            form1.NovaDelegacia(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);
            EspacoDisponivelPoliciais2 = EspacoDisponivelPoliciais2 + 50;

            form1.AtualizadordeTotais();
        }

        private void MenosDelegacia_Click(object sender, EventArgs e)
        {
            int totaldelegacia = int.Parse(QuantiadeDelegacia.Text);
            if (totaldelegacia < 1) { return; }
            if (EspacoDisponivelPoliciais2 > 49)
            {
                int quantiaDelegacia = int.Parse(QuantiadeDelegacia.Text) - 1;
                QuantiadeDelegacia.Text = quantiaDelegacia.ToString();
                form1.MenosUmaDelegacia();
                EspacoDisponivelPoliciais2 = EspacoDisponivelPoliciais2 - 50;
                int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
                TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
                form1.Terrasdisponiveis(MaisUmaTerraDisponivel);


            }
            else
            {
                MessageBox.Show("Você não pode destruir a Delegacia pois a quantia de espaço disponível de policiais é inferior a 50"); return;
            }

            form1.AtualizadordeTotais();
        }

        private void MaisIndustriaFerro_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int PrecodeIndustriaferro = int.Parse(dinheirototal2.Text) / 7;
            if (int.Parse(dinheiroDoGoverno2.Text) < PrecodeIndustriaferro)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            int Mais = int.Parse(QuantiadeIndustriaFerro.Text) + 1;
            QuantiadeIndustriaFerro.Text = Mais.ToString();

            PrecoIndustriaFerro.Text = PrecodeIndustriaferro.ToString();
            int SubtrairPrecoIndustriaFerro = Math.Abs(PrecodeIndustriaferro - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoIndustriaFerro.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();

            form1.NovaIndustriaFerro(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            if (PopulacaoDesempregada > 4)
            {
                MineradorFerro = MineradorFerro + 5;
                form1.mineradorferro(MineradorFerro);

                int menospessoasdesempregadas = -5;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -5;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }

            form1.AtualizadordeTotais();
        }



        private void MenosIndustriaFerro_Click_1(object sender, EventArgs e)
        {
            int totalIndustriaferro = int.Parse(QuantiadeIndustriaFerro.Text);
            if (totalIndustriaferro < 1) { return; }

            int quantiadeIndustriaFerro = int.Parse(QuantiadeIndustriaFerro.Text) - 1;
            QuantiadeIndustriaFerro.Text = quantiadeIndustriaFerro.ToString();
            form1.MenosUmaIndustriaFerro();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            if (PopulacaoDesempregada > -1)
            {
                MineradorFerro = MineradorFerro - 5;
                form1.mineradorferro(MineradorFerro);
                int menospessoasdesempregadas = +5;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +5;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }


            form1.AtualizadordeTotais();
        }



        private void MaisIndustriaCombustivel_Click(object sender, EventArgs e)
        {
            int Terrasdisponiveis = int.Parse(TerrasDisponiveis2.Text);
            if (Terrasdisponiveis < 1) { MessageBox.Show("Você não pode mais construir pois não há terras disponíveis"); return; }

            int PrecodeIndustriaCombustivel = int.Parse(dinheirototal2.Text) / 7;
            if (int.Parse(dinheiroDoGoverno2.Text) < PrecodeIndustriaCombustivel)
            {
                MessageBox.Show("Governo sem dinheiro suficiente");
                return;
            };

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) - 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            int Mais = int.Parse(QuantiadeIndustriaCombustivel.Text) + 1;
            QuantiadeIndustriaCombustivel.Text = Mais.ToString();

            PrecoIndustriaCombustivel.Text = PrecodeIndustriaCombustivel.ToString();
            int SubtrairPrecoIndustriaCombustivel = Math.Abs(PrecodeIndustriaCombustivel - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDoGoverno2.Text = SubtrairPrecoIndustriaCombustivel.ToString();
            int AtualizarMoneyCidadaos = Math.Abs(int.Parse(dinheirototal2.Text) - int.Parse(dinheiroDoGoverno2.Text));
            dinheiroDosCidadaos2.Text = AtualizarMoneyCidadaos.ToString();

            form1.NovaIndustriaCombustivel(Mais, dinheirototal2.Text, dinheiroDoGoverno2.Text, dinheiroDosCidadaos2.Text);

            if (PopulacaoDesempregada > 4)
            {
                TecnicoCombustivel = TecnicoCombustivel + 5;
                form1.Tecnicocombustivel(TecnicoCombustivel);

                int menospessoasdesempregadas = - 5; 
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = -5;
                form1.populacaodesempregada1(menospessoasdesempregadas);

            }
            form1.AtualizadordeTotais();
        }

        private void MenosIndustriaCombustivel_Click(object sender, EventArgs e)
        {
            int totalIndustriacombustivel = int.Parse(QuantiadeIndustriaCombustivel.Text);
            if (totalIndustriacombustivel < 1) { return; }

            int quantiadeIndustriaCombustivel = int.Parse(QuantiadeIndustriaCombustivel.Text) - 1;
            QuantiadeIndustriaCombustivel.Text = quantiadeIndustriaCombustivel.ToString();
            form1.MenosUmaIndustriaCombustivel();

            int MaisUmaTerraDisponivel = int.Parse(TerrasDisponiveis2.Text) + 1;
            TerrasDisponiveis2.Text = MaisUmaTerraDisponivel.ToString();
            form1.Terrasdisponiveis(MaisUmaTerraDisponivel);

            if (PopulacaoDesempregada > -1)
            {
                TecnicoCombustivel = TecnicoCombustivel - 5;
                form1.Tecnicocombustivel(TecnicoCombustivel);
                int menospessoasdesempregadas = +5;
                form1.populacaodesempregada(menospessoasdesempregadas);
            }
            else
            {
                int menospessoasdesempregadas = +5;
                form1.populacaodesempregada1(menospessoasdesempregadas);
            }
            
          
            form1.AtualizadordeTotais();
        }
    }


}
